
import * as request from 'request'

export class batchLogger {  
   
      constructor(private serviceUri: string){ }

      log(messages: Array<any>){
            if(!messages || !messages.length) {
                  console.log('No log messages provided.')
                  return
            }

            request({
                  url: this.serviceUri, 
                  method: 'POST',
                  json: true,
                  body: messages
            },
            (err, response, body)=> {       
                  err && console.log(err);
            })
      } 
      
}