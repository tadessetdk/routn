export interface IInsightApplication{
    alias: string;
    version: string;
    title: string;
    description: string;
    selected?: boolean;
}