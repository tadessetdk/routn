export interface IUiState{
    topTab: string;
}