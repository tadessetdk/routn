import { Action, ActionReducer } from '@ngrx/store';

import { 
            UPDATE_APPLICATION_PACKAGE, UPDATE_APPLICATION_PACKAGE_SUCCESS, UPDATE_APPLICATION_PACKAGE_FAIL,
            UpdateApplicationPackageCompleteAction
       } from './applicationPackage.actions';

export interface State{
    submitting?: boolean;
    submitSuccessful?: boolean;    
    errorMessage?: string;
    successMessage?: string;
}

const defaultValue: State = {
    submitSuccessful: true
};

export const reducer: ActionReducer<State> = (state: State = defaultValue, action: UpdateApplicationPackageCompleteAction): State => {
    switch(action.type){
        case UPDATE_APPLICATION_PACKAGE: 
            return { submitting: true }

        case UPDATE_APPLICATION_PACKAGE_SUCCESS:
            return  { submitting: false, submitSuccessful: true, successMessage: 'The application package has been uploaded.' } 

        case UPDATE_APPLICATION_PACKAGE_FAIL:  
            return { submitting: false, submitSuccessful: false, errorMessage: 'Could not upload the application package.' } 

        default:
            return state;
    }
};

export const isSubmitting = (state: State)=> state.submitting;
export const isSubmitSuccessful = (state: State)=> state.submitSuccessful;
export const getErrorMessage = (state: State)=> state.errorMessage;
export const getSuccessMessage = (state: State)=> state.successMessage;