export interface IApplicationPackage{
    manifest: File;
    package: File;
}