import { Component, AfterViewInit, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { SortInfo } from 'ge-web-ui-lib/store';
import { GET_INSIGHT_APPLICATIONS, SORT_INSIGHT_APPLICATIONS } from '../store/insightApplications/insightApplications.actions';
import { IInsightApplication } from '../store/insightApplications/insightApplications.models';
import * as fromRoot from '../store';
import { UPDATE_TOP_TAB } from '../store/ui/ui.actions';

@Component({
  selector: 'insightApplications-comp',
  templateUrl: './insightApplications.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InsightApplicationsComponent implements OnInit{
    applications$: Observable<IInsightApplication[]>;
    sortInfo$: Observable<SortInfo>;
    isLoading$: Observable<boolean>;
    userCanEdit$: Observable<boolean>;
    errorMessage$: Observable<string>;    
    
    constructor(private store: Store<fromRoot.IAppState>){
        store.dispatch({ type: UPDATE_TOP_TAB, payload: 'apps' });
        store.dispatch({ type: GET_INSIGHT_APPLICATIONS });
        this.isLoading$ = store.select(fromRoot.isLoadingInsightApplications);
        this.userCanEdit$ = store.select(fromRoot.canUserEdit);
        this.applications$ = store.select(fromRoot.getInsightApplications);
        this.sortInfo$ = store.select(fromRoot.getInsightApplicationsSortInfo);
        this.errorMessage$ = store.select(fromRoot.getInsightApplicationsErrorMessage);
    }

    ngOnInit(){ }

    sort(field: string){
        this.store.dispatch({ type: SORT_INSIGHT_APPLICATIONS, payload: field });
    }

    getSortByClass(sortInfo: SortInfo, field: string){
        return (sortInfo.field === field && 'sorted-by-column') || '';
    }

    getSortDirectionClass(sortInfo: SortInfo, field: string){
        return (sortInfo.field === field) && (sortInfo.asc && 'fa-sort-asc' || 'fa-sort-desc') || '';        
    }
}