import { Component, OnInit, ChangeDetectionStrategy, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import * as fromRoot from '../../store';
import { UPDATE_APPLICATION_PACKAGE } from '../../store/applicationPackage/applicationPackage.actions';
import { UPDATE_TOP_TAB } from '../../store/ui/ui.actions';
import { IApplicationPackage } from '../../store/applicationPackage/applicationPackage.models';
import { CanComponentDeactivate } from 'ge-web-ui-lib/guards';

@Component({
    selector: 'insight-apps-upload',
    templateUrl: './insightApplication.upload.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadInsightApplicationComponent implements OnInit, CanComponentDeactivate{   
    isSubmitting$: Observable<boolean>;
    isSubmitSuccessful$: Observable<boolean>;    
    errorMessage$: Observable<string>;    
    successMessage$: Observable<string>;    
    
    private manifest: File;
    private package: File;
    
    constructor(
        private formBuilder: FormBuilder, 
        private store: Store<fromRoot.IAppState>, 
        private router: Router){ 
            store.dispatch({ type: UPDATE_TOP_TAB, payload: 'apps' });
        }   

    ngOnInit(){        
        this.errorMessage$ = this.store.select(fromRoot.getApplicationPackageErrorMessage);
        this.successMessage$ = this.store.select(fromRoot.getApplicationPackageSuccessMessage);
        this.isSubmitting$ = this.store.select(fromRoot.isSubmittingApplicationPackage);
    }  

    canDeactivate(): Observable<boolean> {
        return Observable.of(true);
    }

    setManifest(e){
        this.manifest = e.target.files[0];
    }

    setPackage(e){
        this.package = e.target.files[0];
    }

    submitForm(){     
        if(!this.manifest || !this.package) return;   
        this.store.dispatch({ type: UPDATE_APPLICATION_PACKAGE, payload: { manifest: this.manifest, package: this.package } });       
        this.isSubmitSuccessful$ = 
            this.store.select(fromRoot.isSubmitApplicationPackageSuccessful)
            .map(isCompleted=> {
                isCompleted && (this.router.navigate(['/insightApplications']));
                return isCompleted;
            });
    }
}