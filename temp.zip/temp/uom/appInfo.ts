export const AppEnvSettingsKey = 'UOM_WEB_UI_ADMIN_SETTINGS';
export const AppVersion = '0.1.%BUILD_NUMBER%';
export const AppId = 'UOM-Admin';
export const IsAdminApp = true;