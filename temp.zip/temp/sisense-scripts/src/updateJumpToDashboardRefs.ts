import * as request from 'request'
import { AccessToken, SisenseApiUrl } from './appSettings'
import { getAllDashboards } from './getDashboardsFromAPI'
import { getWidgetsFromAPI } from './getWidgetsFromAPI'
import { publishDashboardAPI } from './publishDashboardAPI'

export function updateJumpToWidgetsScript(dashboards): Promise<any> {
      return Promise.all(dashboards.map(d => {
            d.widgets.filter(w=> w.plugins.some(p=> p.toLowerCase() === 'jumptodashboard'))
                        .map(w => updateWidgetScript(d.oid, w))
      }))
}

export function updateJumpToDashboardRefs(dashboards): Promise<any> {

      const filterWidgets = w=> w.plugins.some(p=> p.toLowerCase() === 'jumptodashboard') && 
                                                w.options && w.options.drillTarget && w.options.drillTarget.caption
      
      const allWidgetUpdates = (dsh)=> dsh.widgets
            .filter(w=> filterWidgets(w))
            .map(w => updateDrillTarget(dsh, w.title, w.options))

      const updateWidgets = dsh => new Promise((resolve, reject)=> Promise.all(allWidgetUpdates(dsh)).then(()=> resolve()))

      return new Promise((resolve, reject)=> Promise.all(dashboards.map(dsh => updateWidgets(dsh))).then(()=> resolve()))
}

function updateDrillTarget(sourceDashboard, widgetTitle, options): Promise<any> {
      return new Promise(async (resolve, reject)=> {
            console.log('jumptodashboard', sourceDashboard.title)
            const sourceDashboardIds = await getCurrentDashboardIds(sourceDashboard.title, sourceDashboard.datasource.title)
            return Promise.all(sourceDashboardIds.map(async sourceId=> {
                  let retry = 0
                  let ids = await getCurrentDashboardIds(options.drillTarget.caption, sourceDashboard.datasource.title);
                  if(ids.length === 0) {
                  retry = 1
                  ids = await getCurrentDashboardIds(options.drillTarget.caption, sourceDashboard.datasource.title, true);
                  }

                  if(ids.length === 0) {
                  retry = 2
                  ids = await getCurrentDashboardIds(options.drillTarget.caption, sourceDashboard.datasource.title, true, true);
                  }
                  
                  ids.length === 0 && (console.log(`${retry} - No matching target dashboard found for source=`, sourceDashboard.title, 'target=', options.drillTarget.caption, 'datasource=', sourceDashboard.datasource.title));
                  ids.length === 1 && (console.log(`${retry} - Exactly matching target dashboard found for source=`, sourceDashboard.title, 'target=', options.drillTarget.caption, 'datasource=', sourceDashboard.datasource.title));
                  ids.length > 1 && (console.log(`${retry} - Multiple target dashboards matching for source=`, sourceDashboard.title, 'target=', options.drillTarget.caption, 'datasource=', sourceDashboard.datasource.title));

                  const targetDashboardId = ids[0];
                  const widgetId = await getWidgetId(sourceId, widgetTitle);
                  options.drillTarget.oid = targetDashboardId;
                  return updateDrillTargetAPI(sourceId, widgetId, options)
            //  Promise.resolve();
            })).then(()=> resolve())
      })

}

async function getCurrentDashboardIds(title, dsTitle, startsWith?, donotCompareDatasource?) {
        const allDashboards = await getAllDashboards();
        let results = allDashboards.filter(d => {
            const titlesMatch = (startsWith && d.title.toLowerCase().startsWith(title.toLowerCase())) || (d.title.toLowerCase() === title.toLowerCase())
            return (donotCompareDatasource && titlesMatch) || (titlesMatch && d.datasource.title === dsTitle);
        })

        if(results.length > 1 && (startsWith || donotCompareDatasource)) {
            //results.forEach(d=> console.log('---source-dash', title, 'target', d.title, 'source-datasource', dsTitle, 'target', d.datasource.title))
            results = [results.find(d=> d.datasource.title.startsWith('AlarmInsights_Cube_'))]
            results.forEach(d=> console.log('---source-dash', title, 'target', d.title, 'source-datasource', dsTitle, 'target', d.datasource.title))
        }

        return results.map(d => d.oid);
}

async function getWidgetId(sourceDashboardId, title) {

      const widgets = await getWidgetsFromAPI(sourceDashboardId)
      const w1 = widgets.find(w=> w.title.toLowerCase() === title.toLowerCase())
      !w1 && (console.log('Not found dashboardID=', sourceDashboardId, 'widget title=', title))
      return w1 && w1.oid

}

function updateDrillTargetAPI(sourceDashboardId, widgetId, options): Promise<any> { 
      if(!sourceDashboardId || !widgetId || !options.drillTarget || !options.drillTarget.oid){
            console.log('updateDrillTargetAPI', `Invalid ${sourceDashboardId} or ${widgetId} or options.drillTarget.oid`)
            return Promise.resolve()
      }

      return new Promise((resolve, reject)=> {
            request({
                  url : `${SisenseApiUrl}/dashboards/${sourceDashboardId}/widgets/${widgetId}`,
                  method: 'PATCH',
                  json: true,
                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  body: { 
                        options: options
                  },
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if(err){
                        console.log(`failed to update drillTarget for dashboard/${sourceDashboardId}/widget/${widgetId} with target ${options.drillTarget.oid}`);
                        resolve(err) 
                  } else {
                        console.log(`successfully updated drillTarget for dashboard/${sourceDashboardId}/widget/${widgetId} with target ${options.drillTarget.oid}`);
                        publishDashboardAPI(sourceDashboardId)
                              .then(()=> resolve())
                  }
            })
      })
}

function updateWidgetScript(dashboardId, widget) {
      const script = getWidgetJumptoScript(dashboardId, widget) + getDashboardDestroyScript(dashboardId, widget)
      
      if(!script){
            return Promise.resolve()
      }

      updateWidgetScriptAPI(dashboardId, widget, script)
}

function getDashboardDestroyScript(dashboardId, widget): string { 
      const needCleanup = widget.script.indexOf(`dashboard.on('widgetready'`) !== -1 && 
                        widget.script.indexOf(`$('<div class="bi-enterprise-menu-list"></div>')`) !== -1 && 
                        widget.script.indexOf(`$('<div></div>').attr('class', 'bi-enterprise-menu')`) !== -1 && 
                        widget.script.indexOf(`menu.append(list)`) !== -1

      if(!needCleanup){
            return ''
      }

      const cleanupScript = `;dashboard.on('destroy',function(){$('.bi-enterprise-menu').remove()})`
      const isUptodate = widget.script.indexOf(cleanupScript) !== -1

      if(isUptodate){
            return ''
      }

      return cleanupScript
}

function getWidgetJumptoScript(dashboardId, widget):  string { 
      const matchScript = `drilledDashboardDisplayType:2, displayFilterPane:false, displayDashboardsPane:false, displayToolbarRow:false, displayHeaderRow:false`
      let isUptodate = widget.script.indexOf(matchScript) !== -1

      if(isUptodate){
            return ''
      }

      const jumpToScript = `;prism.jumpToDashboard(widget, {drilledDashboardPrefix:'@',drilledDashboardDisplayType:2, displayDashboardsPane:false, displayToolbarRow:false, displayHeaderRow:false,displayFilterPane:false });`
      isUptodate = widget.script.indexOf(jumpToScript) !== -1

      if(isUptodate){
            return ''
      }

      return jumpToScript
}

function updateWidgetScriptAPI(dashboardId, widget, script): Promise<any> {
      const updatedScript = `${widget.script};${script}`;

      return new Promise((resolve, reject)=> {
            request({
                  url : `${SisenseApiUrl}/dashboards/${dashboardId}/widgets/${widget.oid}`,
                  method: 'PATCH',
                  json: true,
                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  body: { 
                        script: updatedScript
                  },
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if(err){
                        console.log(`failed to update widget script dashboard/${dashboardId}/widget/${widget.oid}`);
                        resolve(err) 
                  } else {
                        console.log(`successfully updated widget script for dashboard/${dashboardId}/widget/${widget.oid}`);
                  }
            })
      })
}