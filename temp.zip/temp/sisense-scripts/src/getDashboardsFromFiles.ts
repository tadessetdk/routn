import * as fs from 'fs'
import * as path from 'path'

import { pluginsKeywordMap } from './pluginsKeyword'
import { getWidgetsWithPlugin } from './getWidgetsWithPlugin'

const rootPath = path.join(__dirname, '../CLIVE2017')

let allDashboards
let allDashboardsPromise

export async function getDashboardsFromFiles(): Promise<any> {
       if(allDashboards){
            return Promise.resolve(allDashboards)
       }

       if(allDashboardsPromise) {
            return allDashboardsPromise
       }

       allDashboardsPromise = new Promise((resolve, reject)=> {
            fs.readdir(rootPath, (err, folders)=> {
                  Promise.all(folders.map(fd=> readSubFolder(fd)))
                  .then(result=> {
                        fs.writeFile(path.join(rootPath, '/outputs/resultFromFile.json'), JSON.stringify(result))
                        allDashboards = concatDashboards(result)
                        resolve(allDashboards)
                  })
            })
       })

       return allDashboardsPromise
}

function readSubFolder(fd): Promise<any> {
      return new Promise((resolve, reject)=> {
            fs.readdir(path.join(rootPath, fd), (err, files)=> {
                  Promise.all(files.map(f=> findPlugins(path.join(rootPath, fd, f))))
                         .then(r=> resolve({ [fd]: r }))
            })
      })
}

function findPlugins(filePath): Promise<any> {
      return new Promise((resolve, reject)=> {
            fs.readFile(filePath, (err, dataStr: any)=> {
                  const data: any = JSON.parse(dataStr)
                  resolve(getWidgetsWithPlugin(data))
            })
      })
}

function concatDashboards(result) {
      let dashboards = []
      for (let i in result) {
            dashboards = dashboards.concat(result[i][Object.keys(result[i])[0]])
      }
      return dashboards
}