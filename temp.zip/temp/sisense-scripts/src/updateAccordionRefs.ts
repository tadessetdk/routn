import * as request from 'request'
import { AccessToken, SisenseApiUrl } from './appSettings'
import { getDashboardsFromFiles } from './getDashboardsFromFiles'
import { getAllDashboards } from './getDashboardsFromAPI'
import { getWidgetsFromAPI } from './getWidgetsFromAPI'
import { publishDashboardAPI } from './publishDashboardAPI'


const dashboardIdWithAccordion = '59139952d8dcedc027001776' //ECG WORKFLOW EFFICIENCY
const widgetIdsWithAccordion = ['59139952d8dcedc02700177f', '59139952d8dcedc02700177e', '59139952d8dcedc02700177d', '59139952d8dcedc027001780']
                              // var widgets = GET(http://localhost:8083/api/v1/dashboards/<dashboardIdWithAccordion>/widgets)
                              // widgets.filter(w=> w.script && w.script.toLowerCase().indexOf('accordion')!==-1).map(w=>w.oid)

// Get dashboards Ids of 
const oldScriptDashboardIdNameMap = {
      '580a78e1ca03c824c1000148': '_accrd_SPEED MUSE to DC',
      '580a78c3ca03c824c1000139': '_accrd_SPEED DC to Confirm',
      '580a78a5ca03c824c1000127': '_accrd_SPEED ACQ to Confirm',
      '580a78b6ca03c824c100012e': '_accrd_SPEED ACQ to MUSE'
}

export function updateAccordionRefs(dashboardsIn): Promise<any> {

      const dashboard = dashboardsIn.find(d=> d.oid === dashboardIdWithAccordion)

      const filterWidgets = w=> {
         return   widgetIdsWithAccordion.some(wId=> wId === w.oid) && w.plugins.some(p=> p.toLowerCase() === 'accordion') && w.script
      }
      
      const allWidgetUpdates = (dsh)=> dsh.widgets
            .filter(w=> filterWidgets(w))
            .map(w => updateAccordionScript(dsh.oid, w))

      const updateWidgets = dsh => new Promise((resolve, reject)=> Promise.all(allWidgetUpdates(dsh)).then(()=> resolve()))
      
      return updateWidgets(dashboard)

}

function updateAccordionScript(sourceDashboardId, widget): Promise<any> {
      
      const accordionScriptDashboardId = getDashboardIdFromScript(widget.script)
      const targetDashboardName = oldScriptDashboardIdNameMap[accordionScriptDashboardId]
      const updatedScript = getUpdatedAccordionScript(widget.script, targetDashboardName)
      return updateWidgetScriptAPI(sourceDashboardId, widget.oid, targetDashboardName, updatedScript)

}

// folder also need to be updated given the folder hierarchy remains the same across environments
//    -using old parentFpolderId get folder name
//    -then get current parentFolderId
//    -set parentFolderId to option

function updateWidgetScriptAPI(sourceDashboardId, widgetId, targetDashboardName, script): Promise<any> { 
      if(!sourceDashboardId || !widgetId || !script){
            return Promise.reject(`Invalid ${sourceDashboardId} or ${widgetId} or ${script}`)
      }

      return new Promise((resolve, reject)=> {
            request({
                  url : `${SisenseApiUrl}/dashboards/${sourceDashboardId}/widgets/${widgetId}`,
                  method: 'PATCH',
                  json: true,
                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  body: { 
                        script: script
                  },
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if(err){
                        console.log(`failed to update script for dashboard/${sourceDashboardId}/widget/${widgetId} with ${targetDashboardName}`)
                        resolve(err) 
                  } else {
                        console.log(`successfully updated script for dashboard/${sourceDashboardId}/widget/${widgetId} with ${targetDashboardName}`)
                        publishDashboardAPI(sourceDashboardId)
                              .then(()=> resolve())
                  }

                  resolve()
            })
      })
}

function getDashboardIdFromScript(script) {
      if(script.indexOf('dashboardUrl') === -1) return

      const url = getAccordionUrlFromScript(script)
      return url.slice(url.lastIndexOf('/') + 1)
}

function getUpdatedAccordionScript(script, targetDashboardName) {
      const url = getAccordionUrlFromScript(script)
      return script.replace('dashboardUrl: `' + url + '`', `dashboardName: '${targetDashboardName}'`)
}

function getAccordionUrlFromScript(script){
      return script.slice(script.indexOf('`') + 1, script.lastIndexOf('`'))
}