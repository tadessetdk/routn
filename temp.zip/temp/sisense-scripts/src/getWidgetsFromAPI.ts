import * as request from 'request'
import { AccessToken, SisenseApiUrl } from './appSettings'

let widgets = { };
let currentPromise = { };

export function getWidgetsFromAPI(dashboardId):Promise<any> {

      if(widgets[dashboardId]) return Promise.resolve(widgets[dashboardId])
      if(currentPromise[dashboardId]) return currentPromise[dashboardId]

      currentPromise[dashboardId] = new Promise((resolve, reject)=> {
            request({
                  url: `${SisenseApiUrl}/dashboards/${dashboardId}/widgets`,

                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if(err) {
                        reject(err)
                        return
                  }

                  widgets[dashboardId] = JSON.parse(body)
                  resolve(widgets[dashboardId])
            })
      })

      return currentPromise[dashboardId]

}