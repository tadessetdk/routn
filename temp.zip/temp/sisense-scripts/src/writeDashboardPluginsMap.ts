import * as fs from 'fs'
import * as path from 'path'

import { getUniqueArray } from './getUniqueArray'

export function writeDashboardPluginsMap(outputsPath, dashboards){
 
      let map = 
      dashboards.map(d =>
            ({ 
                  title: d.title,
                  dashboardId: d.oid,
                  plugins: getUniqueArray(d.widgets.reduce((p, w)=> w.plugins.concat(p), []))
            })
      )
      .filter(d=> d.plugins.length)
           
      fs.writeFile(path.join(outputsPath, 'dashboard-plugins-map.json'), JSON.stringify(map))

}

          