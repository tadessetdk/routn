import * as fs from 'fs'
import * as request from 'request'
import { AccessToken, SisenseApiUrl } from './appSettings'

export function exportDashboards(dashboards) {
      const folderPath = `${__dirname}/../outputs/dash_files`
      fs.mkdir(folderPath, err=> {
            Promise.all(dashboards.map(d=> exportDashFile(d, folderPath)))
                        .then(()=> {
                              console.log('all dashboard exported.')
                        })
      })
}

function exportDashFile(dashboard, folderPath){
      return new Promise((resolve, reject) => {
            request({
                  url: `${SisenseApiUrl}/dashboards/${dashboard.oid}/export/dash`,
                  method: 'GET',
                  json: true,
                  headers: {
                  Authorization: `Bearer ${AccessToken}`
                  },
                  rejectUnauthorized: false
            })
            .on('error', err=> {
                  console.log(`failed to export dash file for dashboard/${dashboard.oid}`)
                  reject(err)
            })
            .pipe(fs.createWriteStream(getFilePath(folderPath, dashboard)))
            .on('finish', () => resolve())
      })
}

function getFilePath(folderPath, dashboard){
      let name = dashboard.title.replace(/[^0-9a-z]/ig, '_')
      return `${folderPath}/${dashboard.oid}-${name}.dash`
}