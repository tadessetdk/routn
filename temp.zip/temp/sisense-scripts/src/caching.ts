// cache store for sisense xhr responses 
var cacheStore = function() {

    var dashboardApiPattern = /\/api\/dashboards\/[_\-0-9a-z]+$/i;
    var jaqlPattern = /\/api\/datasources\/.+\/jaql$/i;
    var viewPattern = /\/views\/[_\-0-9a-z]+\/.+/i;
    var resourcePattern = /\/resources\/[_\-0-9a-z]+\/.+/i;
    var sqlApiPattern = /\/api\/datasources\/[_\-0-9a-z]+\/sql\?.+/i;
    var CacheEntriesMaxCount = 1e3;
    var CacheKeyPrefix = "ssData_";
    var cacheEntryPosition = 0;
    var DASHBOARD = "DASHBOARD", JAQL = "JAQL", VIEW = "VIEW", RESOURCE = "RESOURCE", SQL_QUERY = "SQL_QUERY";
    var cacheKeys = [];
    var cStore = window.sessionStorage; 	
	
    var hashCode = function(s) {
        return s.split("").reduce(function(a, b) {
            a = (a << 5) - a + b.charCodeAt(0);
            return a & a;
        }, 0);
    };
	
    var getRequestType = function(url) {
        if (dashboardApiPattern.test(url)) return DASHBOARD;
        if (jaqlPattern.test(url)) return JAQL;
        if (viewPattern.test(url)) return VIEW;
        if (resourcePattern.test(url)) return RESOURCE;
        if (sqlApiPattern.test(url)) return SQL_QUERY;
    };
	
    var getRequestKey = function(url, strPayload) {
        var requestType = getRequestType(url);
        switch (requestType) {
          case JAQL:
            var payload = strPayload && JSON.parse(strPayload) || {};
            payload.queryGuid && delete payload.queryGuid;
            return "j" + hashCode(url + JSON.stringify(payload));

          case DASHBOARD:
            return "d" + hashCode(url);

          case VIEW:
            return "v" + hashCode(url);

          case RESOURCE:
            return "r" + hashCode(url);

          case SQL_QUERY:
            return "s" + hashCode(url);

          default:
            return null;
        }
    };
	
    var isJsonResponse = function(url) {
        return getRequestType(url) !== VIEW;
    };
	
    var cacheResponse = function(url, payload, response) {
        var key = getRequestKey(url, payload);
        if (key) {
            if (isJsonResponse(url) && JSON.parse(response).error) return;
            var cacheKey = CacheKeyPrefix + key;
            var exists = cStore[cacheKey];
            cStore[cacheKey] = response;
            !exists && updateCacheEntries(cacheKey);
        }
    };
	
    var updateCacheEntries = function(key) {
        const position = ++cacheEntryPosition % CacheEntriesMaxCount;
        const oldKey = cacheKeys[position];
        cacheKeys[position] = key;
        if (!!oldKey && cacheEntryPosition != position) {
            delete cStore[oldKey];
        }
    };
	
    var getCachedResponse = function(url, payload) {
        if (getRequestType(url)) {
            var key = getRequestKey(url, payload);
            var cacheKey = CacheKeyPrefix + key;
            return cStore[cacheKey];
        }
    };
	
    return {
        get: function(url, payload) {
            return getCachedResponse(url, payload);
        },
        set: function(url, payload, response) {
            return cacheResponse(url, payload, response);
        }
    };
	
}();


// use the cache store above in Sisense common.js as follows

/*

...

return function (r, u, s, l, m, M, c, d) {
      function E() {
            h && h(),
            p && p.abort()
      }
      function f(n, t, r, i, o) {
            A(y) && a.cancel(y),
            h = p = null,
            n(t, r, i, o),
            e.$$completeOutstandingRequest(S)
      }
      if (e.$$incOutstandingRequestCount(), u = u || e.url(), "jsonp" == gt(r)) {
            var g = "_" + (t.counter++).toString(36);
            t[g] = function (e) {
                  t[g].data = e,
                  t[g].called = !0
            };
            var h = i(u.replace("JSON_CALLBACK", "angular.callbacks." + g), g, function (e, n) {
                        f(l, e, t[g].data, "", n),
                        t[g] = S
                  })
      } else {
            
            var cResponse = cacheStore.get(u, s);
            if(cResponse !== undefined){
                  f(l, 200, cResponse, '', 'OK');
                  return;
            }
            
            var p = n();								
            p.open(r, u, !0),
            o(m, function (e, n) {
                  A(e) && p.setRequestHeader(n, e)
            }),
            p.onload = function () {
                  var e = p.statusText || "",
                  n = "response" in p ? p.response : p.responseText,
                  a = 1223 === p.status ? 204 : p.status;
                  0 === a && (a = n ? 200 : "file" == va(u).protocol ? 404 : 0);
                  (p.status === 200) && (cacheStore.set(u, s, n));
                  f(l, a, n, p.getAllResponseHeaders(), e);
            };
            var O = function () {
                  f(l, -1, null, null, "")
            };
            if (p.onerror = O, p.onabort = O, c && (p.withCredentials = !0), d)
                  try {
                        p.responseType = d
                  } catch (v) {
                        if ("json" !== d)
                              throw v
                  }
            p.send(T(s) ? null : s)
      }
      if (M > 0)
            var y = a(E, M);
      else
            I(M) && M.then(E)
}		


...


me.ajaxTransport(function (e) {
      var n;
      if (me.support.cors || Fn && !e.crossDomain)
            return {
                  send: function (a, t) {
                        var requestUrl = e.url;
                        var cResponse = cacheStore.get(requestUrl)
                        if(cResponse !== undefined){
                              t(200, 'OK', { text: cResponse }, '');
                              return;
                        }
                        
                        var r,									
                        i,
                        u = e.xhr();
                        if (u.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields)
                              for (r in e.xhrFields)
                                    u[r] = e.xhrFields[r];
                        e.mimeType && u.overrideMimeType && u.overrideMimeType(e.mimeType),
                        e.crossDomain || a["X-Requested-With"] || (a["X-Requested-With"] = "XMLHttpRequest");
                        for (r in a)
                              u.setRequestHeader(r, a[r]);
                        n = function (e) {
                              return function () {
                                    n && (delete wn[i], n = u.onload = u.onerror = null, "abort" === e ? u.abort() : "error" === e ? t(u.status || 404, u.statusText) : t(bn[u.status] || u.status, u.statusText, "string" == typeof u.responseText ? {
                                                text: u.responseText
                                          }
                                                      : o, u.getAllResponseHeaders()))
                              }
                        },
                        u.onload = (function (e1) {
                              cacheStore.set(requestUrl, '', u.responseText);
                              return n();
                        })(),
                        u.onerror = n("error"),
                        n = wn[i = Pn++] = n("abort"),
                        u.send(e.hasContent && e.data || null)
                  },
                  abort: function () {
                        n && n()
                  }
            }
});

...

*/