import { pluginsKeywordMap } from './pluginsKeyword'

export function getWidgetsWithPlugin(dashboard) {
      const widgets = dashboard.widgets
            .map(w=> ({ 
                  title: w.title,
                  oid: w.oid,
                  script: (<any>w).script || '',
                  options: w.options,
                  type: w.type,
                  subtype: w.subtype
            }))
      const dash = JSON.parse(JSON.stringify(dashboard))
      dash.widgets = getWidgetsPlugin(widgets)
      return dash
}

function getWidgetsPlugin(widgets) {
      const pluginsKeywordArray = Object.keys(pluginsKeywordMap)
                                          .map(k=> ({ key: k, value: pluginsKeywordMap[k] }))

      return widgets.map(w=> {    
            w.plugins = pluginsKeywordArray.filter(p=>
                  contains(w.script, p.value) || 
                  contains(w.type, p.value, true) || 
                  contains(w.subtype, p.value, true) ||
                  w.options.drillTarget && p.key === 'jumpToDashboard'
            ).map(p=> p.key)
            return w
      })
      .filter(w=> w.plugins.length)
}

function contains(input, pattern, exact?) {
      if(exact){
            return input && pattern && input.toLowerCase() === pattern.toLowerCase()
      }

      return input && pattern && input.toLowerCase().indexOf(pattern.toLowerCase()) !== -1
}