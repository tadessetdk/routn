import * as fs from 'fs'
import * as path from 'path'

import { getDashboardsFromFiles } from './getDashboardsFromFiles'
import { getDashboardsFromAPI, getAllDashboards } from './getDashboardsFromAPI'
import { updateJumpToDashboardRefs, updateJumpToWidgetsScript } from './updateJumpToDashboardRefs'
import { updateAccordionRefs } from './updateAccordionRefs'
import { writeDashboardPluginsMap } from './writeDashboardPluginsMap'
import { writePluginToDashboardsMap } from './writePluginToDashboardsMap'
import { generateDashboardsScripts } from './generateDashboardsScripts'
import { markDashboardNotInDB } from './markDashboardNotInDB'
import { exportDashboards } from './exportDashboards'
import { updateDashboardScripts } from './updateDashboardScripts'
import { publishAllDashboardsAPI } from './publishDashboardAPI'

const outputsPath = path.join(__dirname, '/../outputs/')

let logFile, oldConsoleLog = console.log.bind(console)

function createLogFile(){
      const fileName = __dirname + `/../outputs/debug_${Date.now()}.log`
      logFile = fs.createWriteStream(fileName, { flags : 'w' })
      console.log = (...args)=> {
            oldConsoleLog(args)
            fs.appendFile(fileName, args.join(', ') + '\n')
      }
}

function closeLogFile(){
      logFile.close()
      console.log = oldConsoleLog
}

function generateScripts(){
      fs.mkdir(outputsPath, async err=> {
            const dashboards = await getDashboardsFromAPI() 
            generateDashboardsScripts(dashboards)
                  .then(()=> {
                        console.log('completed generating scripts for all dashboards.')
                  })
      })
}

// generateScripts()

function updateDashboards(){
      fs.mkdir(outputsPath, async err=> {
            createLogFile()

            const dashboards = await getDashboardsFromAPI()  
            updateJumpToWidgetsScript(dashboards).then(()=> console.log('Completed updating widget scripts.'))
           
            // writeDashboardPluginsMap(outputsPath, dashboards)
            // writePluginToDashboardsMap(outputsPath, dashboards)
            // updateJumpToDashboardRefs(dashboards).then(()=> console.log('Completed updating plugins.'))
            // await updateAccordionRefs(dashboards)
      })     
}

// updateDashboards()

async function updateTitles(){
      const dashboards = await getAllDashboards() 
      await markDashboardNotInDB(dashboards)
}

//updateTitles();

function exportDashs(){
      fs.mkdir(outputsPath, async err=> {
            const dashboards = await getAllDashboards() 
            await exportDashboards(dashboards)
      })
}

//exportDashs()

async function updateScripts(){
      const dashboards = await getAllDashboards() 
      await updateDashboardScripts(dashboards)
}

// updateScripts()

async function publishDashboards(){
      const dashboards = await getAllDashboards() 
      await publishAllDashboardsAPI(dashboards)
}

// publishDashboards()