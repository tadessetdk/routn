import * as fs from 'fs'
import * as path from 'path'

import { getUniqueArray } from './getUniqueArray'

export function writePluginToDashboardsMap(outputsPath, dashboards){
 
      let map = {}
      dashboards.forEach(d => { 
            d.widgets.forEach(w=> {
                  w.plugins.forEach(p=> {
                        (map[p] && map[p].push(d.title)) || ( map[p] = [d.title])
                  })
            })
      })

      for(let i in map){
            map[i] = getUniqueArray(map[i]).map(d=> ({ dashboard: d.name, occurrence: d.count }))
      }

      fs.writeFile(path.join(outputsPath, 'plugin-dashboards-map.json'), JSON.stringify(map))

}
          