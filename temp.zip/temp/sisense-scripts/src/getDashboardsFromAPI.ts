import * as request from 'request'
import { AccessToken, SisenseApiUrl } from './appSettings'
import { getWidgetsFromAPI } from './getWidgetsFromAPI'
import { getWidgetsWithPlugin } from './getWidgetsWithPlugin'

let allDashboards: any;
let currentPromise: any;

export function getAllDashboards(){

      if(allDashboards) return Promise.resolve(allDashboards)
      if(currentPromise) return currentPromise

      currentPromise = new Promise((resolve, reject)=> {
            request({
                  url: `${SisenseApiUrl}/dashboards`,
                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if(err) {
                        reject(err)
                        return
                  }

                  allDashboards = JSON.parse(body)
                  resolve(allDashboards.filter(d=> !d.title.startsWith('NOT_IN_DB_')))

            })
      })
      return currentPromise

}

export async function getDashboardsFromAPI() {
       
       const dashboards = await getAllDashboards()
       return Promise.all(dashboards.map(async d=> {
             d.widgets = await getWidgetsFromAPI(d.oid)
             return getWidgetsWithPlugin(d)
       }))

}