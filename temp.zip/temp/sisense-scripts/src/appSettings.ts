const args = process.argv

const set1 = args[2].split('=')
const set2 = args[3].split('=')

const pars = { }
pars[set1[0]] = set1[1].replace('"', '').replace("'", '')
pars[set2[0]] = set2[1].replace('"', '').replace("'", '')

export const SisenseApiUrl = pars['url']
export const AccessToken = pars['token']

console.log('Updating dashboards...')