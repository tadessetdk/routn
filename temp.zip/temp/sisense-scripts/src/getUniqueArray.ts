
export function getUniqueArray(arr) {

      let map = { }
      arr.forEach(i=> { 
          (map[i] && map[i]++) || (map[i] = 1)
      })
      return Object.keys(map).map(k=> ({ name: k, count: map[k] }))

}