import * as request from 'request'
import { AccessToken, SisenseApiUrl } from './appSettings'

const SisenseApiUrlV0 = SisenseApiUrl.slice(0, -3)

export function publishAllDashboardsAPI(dashboards): Promise<any> { 
      return Promise.all(dashboards.map(d=> publishDashboardAPI(d.oid)))
                  .then(()=> console.log('done publishing dashboars.'))
}

export function publishDashboardAPI(dashboardId): Promise<any> { 
      return new Promise((resolve, reject)=> {
            request({
                  url : `${SisenseApiUrl}/dashboards/${dashboardId}/publish?force=true`,
                  method: 'POST',
                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  body: {},
                  json: true,
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if (response.statusCode != 204) {
                        console.log(`failed to publish dashboard ${dashboardId}`)
                  }
                  else {
                        console.log(`successfully published dashboard ${dashboardId}`)
                        updateDashboardShare(dashboardId)
                              .then(()=> resolve())
                  }
            })
      })
}

function updateDashboardShare(dashboardId) {
      return new Promise((resolve, reject)=> {
            getDashboardShare(dashboardId)
                  .then(shareTo=> {
                        request({
                              url : `${SisenseApiUrlV0}/shares/dashboard/${dashboardId}`,
                              method: 'POST',
                              headers: {
                                    Authorization: `Bearer ${AccessToken}`
                              },
                              body: shareTo,
                              json: true,
                              rejectUnauthorized: false
                        }, (err, response, body)=> {
                              if (response.statusCode != 200) {
                                    console.log(`failed to update shares for dashboard ${dashboardId}`)
                                    return reject()
                              }

                              console.log(`successfully updated shares for dashboard ${dashboardId}`)
                              resolve(body)
                        })
                  })
      })
}

function getDashboardShare(dashboardId) {
      return new Promise((resolve, reject)=> {
            request({
                  url : `${SisenseApiUrlV0}/shares/dashboard/${dashboardId}`,
                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if (response.statusCode != 200) {
                        console.log(`failed to get shares for dashboard ${dashboardId}`)
                        return reject()
                  }

                  const sharesTo = JSON.parse(body).sharesTo.map(sh=> {
                        let obj = {
                              shareId: sh.shareId,
                              type: sh.type,
                              subscribe: true
                        }

                        if(sh.type === 'group'){
                              obj = Object.assign(obj, { rule: sh.rule, everyone: sh.everyone })
                        }

                        return obj
                  })

                  resolve({
                        "sharesTo": sharesTo,
                        "sharesToNew": [],
                        "subscription": {
                              "isDataChange": true,
                              "type": "onUpdate",
                              "schedule": "* * * * * *",
                              "timezone": 0,
                              "tzName": "UTC",
                              "context": {
                                    "dashboardid": dashboardId
                              },
                              "active": true,
                              "executionPerDay": 1,
                              "reportType": {
                                    "inline": true
                              }
                        }
                  })
            })
      })
}