import * as request from 'request'
import { AccessToken, SisenseApiUrl } from './appSettings'
import { publishDashboardAPI } from './publishDashboardAPI'

const intervalScript = `setInterval(refreshDashboard, refreshIntervalMiliSec)`
const destroyScript = 
`var timerHandle;
dashboard.on('destroyed',function(dashboard){
   console.debug('destroyed dashboard', dashboard.oid, '-', dashboard.title);
   if(timerHandle){
      clearInterval(timerHandle);
      timerHandle = 0;
      console.debug('cleared timer for dashboard ', dashboard.oid, '-', dashboard.title);
   }
});
`
const wrapperScriptStart = '(function(){'
const wrapperScriptEnd = '}())'
const hasTimerScript = script=> script && script.trim() && !script.startsWith(wrapperScriptStart) && script.indexOf(intervalScript) !== -1;

export function updateDashboardScripts(dashboards): Promise<any> {
      return Promise.all(dashboards.filter(d=> hasTimerScript(d.script))
            .map(d => {
                  let script = d.script
                  script = script.replace(intervalScript, `timerHandle = ${intervalScript}`)
                  script = destroyScript + script
                  script = script = wrapperScriptStart + '\n' + script + '\n' + wrapperScriptEnd
                  updateScript(d.oid, script)
            })
      )
}

function updateScript(dashboardId, script): Promise<any> {

      return new Promise((resolve, reject)=> {
            request({
                  url : `${SisenseApiUrl}/dashboards/${dashboardId}`,
                  method: 'PATCH',
                  json: true,
                  headers: {
                        Authorization: `Bearer ${AccessToken}`
                  },
                  body: { 
                        script: script
                  },
                  rejectUnauthorized: false
            }, (err, response, body)=> {
                  if(err){
                        console.log(`failed to update dashboard script dashboard/${dashboardId}`);
                        resolve(err) 
                  } else {
                        console.log(`successfully updated dashboard script for dashboard/${dashboardId}`);
                        publishDashboardAPI(dashboardId).then(()=> resolve())
                  }
            })
      })
}