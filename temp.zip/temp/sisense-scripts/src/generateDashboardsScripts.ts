import * as fs from 'fs'

export function generateDashboardsScripts(dashboards) {
      return new Promise((resolve, reject)=> {
            const folderPath = `${__dirname}/../outputs/scripts`
            fs.mkdir(folderPath, err=> {
                   if(err){
                        console.log(err)
                        resolve()
                        return
                  }
                  
                  Promise.all(dashboards.filter(d=> d.script || (d.widgets && d.widgets.some(w=> w.script))).map(d=> writeDashboardScript(d, folderPath)))
                         .then(()=> resolve())
            })
      })
}

function writeDashboardScript(dashboard, folderPath) {
      return new Promise((resolve, reject)=> {
            const dashboardFolderPath = `${folderPath}/${dashboard.title.replace('/', '-')}-${dashboard.oid}`
            fs.mkdir(dashboardFolderPath, err=> {
                  if(err){
                        console.log(err)
                        resolve()
                        return
                  }

                  console.log(`generating script for dashboard ${dashboard.oid}...`)

                  let prs = []
                  if(dashboard.script) {
                        prs.push(new Promise((resolve1, reject1)=> {
                              fs.writeFile(`${dashboardFolderPath}/dashboard.js`, dashboard.script, err=> {
                                    err && console.log(err);
                                    resolve1()
                              })
                        }))
                  }

                  const widgetsFolder = `${dashboardFolderPath}/widgets`
                  prs.push(new Promise((resolve2, reject2)=> {
                        fs.mkdir(widgetsFolder, err1=> {
                              if(err){
                                    console.log(err)
                                    resolve2()
                                    return
                              }

                              Promise.all(dashboard.widgets.filter(w=> w.script).map(w=> writeWidgetScript(w, widgetsFolder)))
                                     .then(()=> resolve2())
                        })
                  }))

                  Promise.all(prs).then(()=>resolve())
            })
      })
}

function writeWidgetScript(widget, folderPath) {
      return new Promise((resolve, reject)=> {
            const type = (widget.type || widget.subtype || 'w').replace('/', '')
            fs.writeFile(`${folderPath}/${type}-${widget.title.replace('/', '-')}-${widget.oid}.js`, widget.script, err=> {
                  err && console.log(err);
                  resolve()
            })  
      })
}