//	Initialize the copyWidget object
prism.run(["$filter", function($filter) {	

	// 	Define variables
    var titleHeight = 32;

    //	Formatting options for each chart type
    var chartTypes = {
    	chart: {
    		selector: '.highcharts-container',
    	},
    	indicator: {
    		selector: '.highcharts-container',
    	},
    	map: {
    		selector: '.map-container',
    	},
    	pivot: {
    		selector:'.p-container',
    	},
    	tablewidget: {
    		selector: '.tablewidget-widget-content',
    		customFormatter: function(widgetElement, widgetContainer){
    			//	Apply default formatting
    			defaultFormatter(widgetElement,widgetContainer);

    			//	Set relative positioning    			
            	widgetContainer.css('position','relative');

            	//	Set the height of the table wrapper
            	var tableWrapper = $('.dataTables_scroll',widgetContainer);
            	tableWrapper.css('height','-webkit-calc(100% + ' + titleHeight + 'px)');
            	
            	//	Set the height of the table body
            	var scrollbody = $('.dataTables_scrollBody',widgetContainer);
            	scrollbody.height(scrollbody.height() + titleHeight);
            	
            	//	Adjust for the page numbers
            	var paging = $('.dataTables_paginate',widgetContainer);
            	paging.css('bottom',(titleHeight * -1) + 'px');
            	
            	//	Adjust for row numbers
            	var rows = $('.dataTables_info',widgetContainer);
            	rows.css('bottom',(titleHeight * -1) + 'px');
    		}
    	},
    	treemap: {
    		selector: '.treemap-widget-content', 
    	},
    	heatmap: {
    		selector: '.heatmap-widget-content',
    		customFormatter: function(widgetElement, widgetContainer){
    			//	Apply default formatting
    			defaultFormatter(widgetElement,widgetContainer);

    			//	Set relative positioning
            	widgetContainer.css('position','relative');

            	//	Set the height of SVG
            	var calendarSvg = $('svg',widgetContainer)[0];
            	calendarSvg.height(calendarSvg.height() + titleHeight);
    		}
    	},
    	sunburst: {
    		selector: '.sunburst-widget-content',
    	},
    	filterWidget: {
    		selector: '.filter-widget-wrapper',
    		customFormatter: function(widgetElement, widgetContainer){
    			//  Find the title bar's elements
		        var widgetHeaderElements = $('widget-header',widgetElement).children();

		        //  Loop through and remove title elements
		        $.each(widgetHeaderElements, function(){
		            //  Does this match the element types to remove?
		            var canRemove = $(this).is('div:not(.spacer)');
		            if (canRemove){
		                //  Yes, so delete
		                $(this).remove();
		            }
		        })

		        //	Move up
		        widgetContainer.css('top', '-' + widgetContainer.height()/2 + 'px');
		    	
		        //  Remove the title bar's border
		        $('widget-header',widgetElement).css('border','none');            

		        //  Move the dragger div to the top layer
		        $('widget-dragger',widgetElement).css('z-index',10);
    		}
    	},
    	imageWidget: {
    		selector: '.image-container',
    		customFormatter: function(widgetElement, widgetContainer){
    			//	Apply default formatting
    			defaultFormatter(widgetElement,widgetContainer);
    			
    			//	Set relative positioning, and add the same border as the textbox widget    			
            	widgetContainer.css('position','relative');
            	widgetContainer.css('border-bottom','4px white solid');
            	widgetContainer.css('max-height','none');

            	//	Format the imagewidget element      	            	
            	$('imagewidget',widgetElement).css('height','100%');
            }
    	},
    	DimensionChanger: {
    		selector: 'div.widget-body',
    		customFormatter: function(widgetElement, widgetContainer){
    			//	Apply default formatting
    			defaultFormatter(widgetElement,widgetContainer);

    			widgetContainer.css('position','relative');
    			
    		}
    	},
		
		smartLabel: {
                selector : '.smartLabelContainer'
		}
    }

	//////////////////////////
	//	Utility Functions	//
	//////////////////////////


	//	Function to handle the prediction
	function hideTitle(widget) {	

        //  Get the widget's style property and make sure to only run in the dashboard
        var hideTitle = (widget.style.hideTitle) && (prism.$ngscope.appstate == 'dashboard');

        //  Hide the widget's title bar when the property is set
        if (hideTitle) {

        	//  Get the widget's HTML element
            var widgetElement = $('widget[widgetid=' + widget.oid + ']');

        	//	Figure out the generic type 
	    	var type = widget.type ? widget.type.split("/")[0] : 'none';

	    	//	Get the selector
	    	var chartType = chartTypes[type];

	    	//	Does the chart type have a formatting option?
	    	if (chartType) {
	    		
		    	//	Find the container
		    	var chartContainer = $(chartType.selector,widgetElement);

		    	//	Apply formatting
		    	if (chartType.customFormatter){
		    		//	Apply custom formatting if defined for this chart type
		    		chartType.customFormatter(widgetElement,chartContainer);
		    	} else {
		    		//	Apply default formatting
		    		defaultFormatter(widgetElement,chartContainer);
		    	}
		    }
	    	
        }
    }

    //	Standard formatting for all chart types
    var defaultFormatter = function(widgetElement, chartContainer) {

        //  Find the title bar's elements        
        var widgetHeaderElements = $('widget-header',widgetElement).children();

        //  Loop through and remove title elements
        $.each(widgetHeaderElements, function(){
            //  Does this match the element types to remove?
            var canRemove = $(this).is('div:not(.spacer)');
            if (canRemove){
                //  Yes, so delete
                $(this).remove();
            }
        })

    	//  Adjust the height, and top properties    	
        chartContainer.height(chartContainer.height() + titleHeight);
        chartContainer.css('top', '-' + titleHeight + 'px');

        //  Remove the title bar's border
        $('widget-header',widgetElement).css('border','none');            

        //  Move the dragger div to the top layer
        $('widget-dragger',widgetElement).css('z-index',10);

    }

	//////////////////////////////////
	//	Initialization Functions	//
	//////////////////////////////////

	//	Function to determine if the regression option should be added
	function canAdd(e,args){
		
		//	Assume true by default
		var result = true;		
		try {			

			//	Only show this in the widget editor
			var widgetEditorOpen = (prism.$ngscope.appstate == "widget");
			if (!widgetEditorOpen) {
				result = false;
			}
			
			// find the widget
			var widget = e.currentScope.widget;
			if(widget == undefined){
				result = false;
			}	

			//	Make sure the widget menu was clicked
			var isNotWidgetMenu = (args.ui.css !== "w-menu-host");
			if (isNotWidgetMenu) {
				result = false;
			}

		} catch(e) {
			result = false;
		}

		//	Return result
		return result;
	}

	// Registering dashboard/ widget creation in order to perform drilling
	prism.on("dashboardloaded", function (e, args) {
		args.dashboard.on("widgetinitialized", onWidgetInitialized);
	});

	// register widget events upon initialization
	function onWidgetInitialized(dashboard, args) {
		//	Hooking to ready/destroyed events
		args.widget.on("destroyed", onWidgetDestroyed);
		
		//	Add hook for when the widget is ready
        args.widget.on("ready", hideTitle);
		
	}

	// unregistering widget events
	function onWidgetDestroyed(widget, args) {
		widget.off("destroyed", onWidgetDestroyed);
	}

	//	Create Options for the quadrant analysis
	prism.on("beforemenu", function (e, args) {

		//	Can we show the regression options?			
		var canAddMenuItem = canAdd(e,args);	

		//	Add the options in the settings menu
		if (canAddMenuItem) {

			//	Get the widget
			var widget = e.currentScope.widget;

			//	Get saved state
			var hideTitle = widget.style.hideTitle;
				
			//	Function the runs when an item is picked
			var itemPicked = function(){						
				//	Update the setting
				widget.style.hideTitle = !widget.style.hideTitle;
				//	Redraw the widget
				widget.redraw();						
			}
				
			//	Get the option as a string
			var option = this.label;

            var header = {
                caption: "Formatting",
                type: "header",
                disabled: false
            }

			//	Create the menu option
			var item = {
				caption: "Hide Title Bar",
				checked: hideTitle,
				size: 'xl',
				type: 'check',
				widget: widget,
				execute: itemPicked
			}		

			//	Add options to the menu
			args.settings.items.push(header);			
            args.settings.items.push(item);           

		}
	});

}]);