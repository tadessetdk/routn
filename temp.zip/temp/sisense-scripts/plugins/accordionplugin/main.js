/**
 * Accordion Plugin for Booking.com
 *
 * Dependencies:
 *   - jQuery
 *   - underscore.js
 *
 * @author Volodymyr Sheremeta <volodymyr.sh@sisense.com>
 */

//hide accordion folders for none owners
navver.directive('listItemHolder', [
    function () {
        return {
            restrict: 'C',
            link: function link($scope, lmnt, attrs) {
                if ($scope.listItem.title.match("^_accrd_")) {
                    if (prism.user._id != $scope.listItem.owner) {
                        $(lmnt).hide();
                    }
                }
            }
        }
    }
]);


(function (ns) {
    'use strict';

    /**
     * Accordion Class
     *
     * @constructor
     * @param {Object} params {default, element, widget, dashboard, dashboardUrl, dashboardName}
     * @return {ns.Accordion}
     */
    ns.Accordion = function (params) {

        var
            element = params.element && $(params.element),
            widget = params.widget,
            dashboard = params.dashboard,
            filters = _.map(params.filters || [], function (n) {
				if(typeof n == 'object'){
					n.dim1 = n.dim1.toLowerCase();
					n.dim2 = n.dim2.toLowerCase();
					return n;
				}
				else{
					return n.toLowerCase();
				}
                
            }),
			
            dashboardUrl = params.dashboardUrl,
            defaultHeight = 1200, // This sets the initial height of the iFrame
            defaultPaddingTop = 30,
            paddingString = '26px 4px 4px 4px',
            queryParams = '?h=false&t=false&l=false&r=false&volatile=true&embed=true',
            iframeSrc = dashboardUrl + queryParams,
            accorId = 'bk-id-' + widget.oid,
            dragging = null,
            pageY = null,
            currentHeight = null,
            iframeWrapper = null,
            filterString = null,
            parent = null,
            arrow = null,

            // private methods
            clickHandler = function () {
			
                iframeWrapper = $('#' + accorId);
                createIFrame();

                var
                    accordions = $('.bk-accordion'),
                    filtersString, isEqual
                    ;

                closeAccordions(accordions, iframeWrapper);

                if (iframeWrapper.data('opened') || !parent.hasClass('dashboard-layout-cell')) {
                    iframeWrapper.data('opened', false);
                    dashboard.off('refreshstart', dashboardRefreshStartHandler);
                } else {
                    accordions.data('opened', false);

                    arrow.css('opacity', 1);

                    iframeWrapper
                        .data('opened', true)
                        .removeClass('no-transition')
                        .css({
                            padding: paddingString,
                            opacity: 1,
                            height: (defaultHeight + defaultPaddingTop) + 'px'
                        });

                    iframeWrapper.find('*').css('display', 'block');
                    filtersString = getFilterString();
                    isEqual = iframeWrapper.find('iframe').attr('src') === filtersString;

                    setTimeout(function () {
                        iframeWrapper.find('iframe')
                            .css('height', defaultHeight + 'px');

                        if (!isEqual)
                            iframeWrapper.find('iframe').attr('src', filtersString)

                    }, isEqual ? 0 : 1000);

                    dashboard.on('refreshstart', dashboardRefreshStartHandler);
                }
            },

            dashboardRefreshStartHandler = function () {
                if (iframeWrapper.data('opened')) {

                    var filtersString = getFilterString();

                    if (iframeWrapper.find('iframe').attr('src') !== filtersString)
                        iframeWrapper.find('iframe').attr('src', filtersString);
                }
            },
			mergeFilterMembers = function(){
			
			},
            getFilterString = function () {
                var selectedFilters = [];
				var tempFilters = [];
				var dim1Found,dim2Found;
                if (filters.length) {
                    dashboard.filters.$$items.forEach(function (filter) {
                        filter.getJAQL().forEach(function (jaql) {
							for(var j=0;j < filters.length;j++){
								if(typeof filters[j] == 'object'){
									if(jaql.dim.toLowerCase() == filters[j].dim1){
										dim1Found = true;
										tempFilters.push(filter);
									}
									if(jaql.dim.toLowerCase() == filters[j].dim2){
										dim2Found = true;
										tempFilters.push(filter);
									}
								}
								else if (filters[j].indexOf(jaql.dim.toLowerCase())){
									selectedFilters.push(filter);
								}
                                
							}
							
                        });
                    });
					if(dim1Found && dim2Found && tempFilters.length){
								tempFilters[0].jaql.filter.members = tempFilters[0].jaql.filter.members.concat(tempFilters[1].jaql.filter.members);
								selectedFilters.push(tempFilters[0])
							}
					
					
                } else {
                    selectedFilters = dashboard.filters.$$items;
                }

                filterString = encodeURIComponent(JSON.stringify(selectedFilters));

                return iframeSrc + '&filter=' + filterString;
            },

            closeAccordions = function (accordions, currentAccordion) {
                var css = {
                    opacity: 0,
                    padding: 0,
                    height: 0
                };

                accordions && accordions.not('#' + accorId).css(css).addClass('no-transition').find('*').css('display', 'none');
                currentAccordion && currentAccordion.css(css).find('*').css('display', 'none');

                $('.bk-arrow').css('opacity', 0);
            },

            createIFrame = function () {
                parent = element.parents('.dashboard-layout-cell');

                arrow = element.siblings('.bk-arrow');

                if (!arrow.length){
                    arrow = $('<div class="bk-arrow"></div>');
                    element.after(arrow);
                }

                if (!iframeWrapper.length) {

                    iframeWrapper = $('<div class="bk-accordion">')
                        .attr('id', accorId)
                        .append('<div class="bk-wrapper">')
                        .append('<div class="bk-resize">')
                        .append('<div class="bk-close">');

                    iframeWrapper.find('.bk-wrapper')
                        .append('<div class="bk-loader"></div>')
                        .append($('<iframe>', {
                            width: '100%',
                            height: defaultHeight + 'px'
                        }));

                    iframeWrapper.find('.bk-close').on('click', function () {
                        iframeWrapper.data('opened', false);
                        closeAccordions(null, iframeWrapper);
                    });

                    initResize();

                }

                if (!$.contains(document, iframeWrapper[0])) {
                    parent.after(iframeWrapper);
                }
            },

            initResize = function () {
                iframeWrapper.find('.bk-resize').on("mousedown", function (e) {
                    dragging = true;
                    pageY = e.pageY;
                    currentHeight = parseInt(iframeWrapper.css('height'), 10);
                    iframeWrapper.addClass('no-transition-resize').find('iframe').hide(0);
                });

                $(document).on("mousemove", function (e) {
                    if (dragging) {
                        iframeWrapper.css('height', (currentHeight - (pageY - e.pageY)) + 'px')
                            .find('iframe').css('height', (currentHeight - (pageY - e.pageY) - defaultPaddingTop) + 'px');
                    }
                });

                $(document).on("mouseup", function (e) {
                    if (dragging) {
                        iframeWrapper.removeClass('no-transition-resize').find('iframe').show(0);
                        defaultHeight = parseInt(iframeWrapper.find('iframe').css('height'));
                        dragging = null;
                    }
                });
            },

            init = function () {
                if (!element) return;

                iframeWrapper = $('#' + accorId);

                createIFrame();
                parent.after(iframeWrapper);

                element.off('click');
                element.on('click', clickHandler);
                element.addClass("clickable");

                // if there "default" param - open widget once on the dashboard init
                if (params.default && !prism['isAccordionOpened_' + widget.oid]) {
                    prism['isAccordionOpened_' + widget.oid] = true;
                    clickHandler();
                }

                widget.on('destroyed', function () {
                    delete prism['isAccordionOpened_' + widget.oid];
                })

            };

        if(params.dashboardUrl == undefined && params.dashboardName != '')
		{
			//If dashboard name is supplied - determine dashboard Id dynamically
			$.ajax({
				method: "GET",
				url: "/api/v1/dashboards/"
			})	//	Function to run when complete
			.done(function( dashboards ) {
				var dashboard = dashboards.filter(function(item) { return item.title == params.dashboardName; });
				var dashboardId = dashboard[0].oid;
				var getUrl = window.location;
				var baseUrl = getUrl.protocol + "//" + getUrl.host + "/app/main/#/dashboards/";
				var dashboardUrl = baseUrl + dashboardId;
				iframeSrc = dashboardUrl + queryParams
				init();
			})
		}
		else
		{
			init();//initializing plugin
		}
        return this;
    };

    ns.Accordion.prototype.constructor = ns.Accordion;

}(window));