prism.registerWidget("imageWidget", {

    name: "imageWidget",
    family: "images",
    title: "imageWidget",
    iconSmall: "/plugins/imageWidget/imageWidget-24.png",
    styleEditorTemplate: "/plugins/imageWidget/styler.html",
    hideNoResults: true,
    style: {
        src: '',
        align: 'left',
        transform: 'original',
        width: 0.12,
        showMinMax: false,
		link: ''
    },
    directive: {

        desktop: "imagewidget"
    },
    data: {

        selection: [],
        defaultQueryResult: {},
        panels: []
    },
    options: {
        dashboardFiltersMode: "slice",
        selector: false,
        title: false
    },
    sizing: {

        minHeight: 128, //header
        maxHeight: 2048,
        minWidth: 128,
        maxWidth: 2048,
        height: 640,
        defaultWidth: 512
    }
});
