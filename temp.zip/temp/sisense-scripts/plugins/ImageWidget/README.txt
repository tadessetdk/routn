Sisense Web Plugins

Sisense has a directory called plugins, and a way to load plugin-provided modules.