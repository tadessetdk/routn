mod.directive('imagewidget', [

    function ($timeout, $dom) {


        return {
            priority: 0,
            replace: false,
            templateUrl: "/plugins/imageWidget/imageWidget.html",
            transclude: false,
            restrict: 'E',
            link: function ($scope, lmnt, attrs) {
            }
        }
    }]);

