
mod.controller('stylerController', ['$scope',
    function ($scope) {

        /**
         * variables
         */


        /**
         * watches
         */
        $scope.$watch('widget', function (val) {

            $scope.model = $$get($scope, 'widget.style');
        });



        /**
         * public methods
         */

        $scope.setLabels = function(value){
            $scope.model.showLabels = value;
            _.defer(function () {
                $scope.$root.widget.redraw();

            });
        }

        $scope.setFirstOnly = function(value){
            $scope.model.showFirstOnly = value;
            _.defer(function () {
                $scope.$root.widget.redraw();

            });
        }

        $scope.changeAlignment = function (halign) {

            $scope.model.halign = halign;

            _.defer(function () {
                $scope.$root.widget.redraw();

            });
        };

        $scope.changeSize = function (size) {

            $scope.model.size = size;

            _.defer(function () {
                $scope.$root.widget.redraw();

            });
        };

        $scope.toggleShowFirstOnly = function (showFirstOnly) {

            $scope.model.showFirstOnly = showFirstOnly;

            _.defer(function () {
                $scope.$root.widget.redraw();

            });
        };
        $scope.toggleShowLabels = function (showLabels) {

            $scope.model.showLabels = showLabels;

            _.defer(function () {
                $scope.$root.widget.redraw();

            });
        };
    }
]);