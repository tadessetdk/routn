
prism.registerWidget("smartLabel", {
	name : "smartLabel",
	family : "Text",
	title : "Smart Label",
	hideNoResults:true,
	iconSmall : "/plugins/smartLabelWidget/widget-24.png",
	styleEditorTemplate: "/plugins/smartLabelWidget/styler.html",
	style: {
		showLabels: true,
		showFirstOnly: false,
		halign: "left",
		size: "12pt"
	},
	options:{
		title:true,
		data: []
	},
	// sizing must be stated
	sizing: {
		minHeight: 50, //header
		maxHeight: 2048,
		minWidth: 128,
		maxWidth: 2048,
		height: 128,
		defaultWidth: 512
	},
	data : {
		selection : [],
		defaultQueryResult : {},
		panels : [
			//dimension panel
			{
				name : 'category',
				type : 'visible',
				metadata : {
					types : ['dimensions'],
					maxitems : -1
				}
			},
			{
				name: 'filters',
				type: 'filters',
				metadata: {
					types: ['dimensions'],
					maxitems: -1
				}
			}
		],

		allocatePanel : function (widget, metadataItem) {

			if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("category").items.length < 1) {

				return "category";
			}
		},

		// returns true/ reason why the given item configuration is not/supported by the widget
		isSupported : function (items) {

			return this.rankMetadata(items, null, null) > -1;
		},

		// ranks the compatibility of the given metadata items with the widget
		rankMetadata : function (items, type, subtype) {

			var a = prism.$jaql.analyze(items);

			// require at least 2 dimensions of lat and lng and 1 measure
			if (a.dimensions.length >= 2 && a.measures.length == 1) {
				return 0;
			}
			return -1;
		},

		// populates the metadata items to the widget
		populateMetadata : function (widget, items) {

			var a = prism.$jaql.analyze(items);

			// allocating dimensions
			widget.metadata.panel("category").push(a.dimensions);
			widget.metadata.panel("filters").push(a.filters);
		},

		// builds a jaql query from the given widget
		buildQuery : function (widget) {

			// building jaql query object from widget metadata
			var query = {
				datasource : widget.datasource,
				metadata : []
			};

			// pushing items
			widget.metadata.panel("category").items.forEach(function (item) {

				query.metadata.push(item);
			});


			// series - dimensions
			widget.metadata.panel('filters').items.forEach(function (item) {

				item = $$.object.clone(item, true);
				item.panel = "scope";

				query.metadata.push(item);
			});

			return query;

			//// building jaql query object from widget metadata
			//var query = {
			//	datasource : widget.datasource,
			//	metadata : []
			//};
            //
			////	Function to add filters to the query
			//var addFilters = function(filters,query) {
            //
			//	//	Loop through each filter in the array
			//	$.each(filters,function(){
            //
			//		//	Has this dimension already been added as a filter?
			//		var thisDim = this.jaql.dim;
			//		var alreadyAdded = $.grep(query.metadata, function(w) {
			//				return thisDim === w.jaql.dim;
			//			}).length > 0;
            //
			//		//	Only run if not already added
			//		if (!alreadyAdded) {
			//			//	Create a metadata item, based on the filter item
			//			var metadataItem = {
			//				isCascading: this.isCascading,
			//				jaql: this.jaql,
			//				disabled: this.disabled,
			//				panel: 'scope'
			//			};
			//			/*
			//			 var metadataItem = $.extend(true, {}, this);
            //
			//			 //	Remove unneccessary attributes
			//			 metadataItem.$filter = null;
			//			 metadataItem.$panel = null;
			//			 */
			//			//	Add to query
			//			query.metadata.push(metadataItem);
			//		}
			//	});
			//};
            //
			////	Function to save the responses
			//var saveLabels = function(data) {
            //
			//	//	Get the label
			//	var labelName = data.metadata[0].jaql.title;
			//	var labelDim = data.metadata[0].jaql.dim;
            //
			//	//	Loop through and save the values
			//	var labelValues = [];
			//	$.each(data.values, function(){
			//		labelValues.push(this[0].text);
			//	});
            //
			//	//	In this context this = widget, so add this to the data placeholder
			//	this.options.data.push({
			//		labelName: labelName,
			//		labelValues: labelValues,
			//		labelDim: labelDim
			//	});
			//};
            //
			////	Function to query for a specific label
			//var getLabel = function(query,widget) {
            //
			//	//	API endpoint for JAQL queries
			//	var apiEndpoint = "/api/datasources/" + encodeURI(widget.datasource.title) + "/jaql"
            //
			//	//	Run the API call, and pass the results to the saveLabels function
			//	$.ajax( {
			//		method:"POST",
			//		url:apiEndpoint,
			//		data:JSON.stringify(query),
			//		async:false,
			//		contentType:"application/json",
			//		context: widget
			//	}).done( saveLabels );
			//};
            //
			////	Get the widget's filters
			//var widgetFilters = widget.metadata.panel('filters').items;
			//addFilters(widgetFilters,query);
            //
			////	Get the dashboard's filters
			//var dashboardFilters = prism.activeDashboard.filters.$$items;
			//addFilters(dashboardFilters,query);
            //
			////	Get the labels selected
			//var labels =widget.metadata.panel("test").items;
            //
			////	Add a dummy object to the front of the metadata array
			//query.metadata.unshift({});
            //
			////	Loop through each dimension and run an API call
			//$.each(labels, function(){
            //
			//	//	Replace the first metadata item with this specific item's jaql
			//	query.metadata[0] = {
			//		jaql: this.jaql
			//	};
            //
			//	//	Add formatting mask?
			//	if (this.format && this.format.mask) {
			//		query.metadata[0].format = {
			//			mask: this.format.mask
			//		};
			//	}
            //
			//	//	Run the API call for this query
			//	getLabel(query, widget);
			//});
            //
			////	Return a dummy query
			//var dummyQuery = {
			//	datasource : widget.datasource,
			//	metadata : []
			//};
            //
			//return dummyQuery;
		},

		// prepares the widget-specific query result from the given result data-table
		processResult : function (widget, queryResult) {

			widget.options.data = [];

			var md = widget.metadata.panels[0].items;

			var dataOptions = [];

			// Set categories info
			md.forEach(function(item){
				dataOptions.push({
					labelName: item.jaql.title,
					labelValues: [],
					labelDim: item.jaql.dim
				})
			});

			// Get labels for each category
			queryResult.rows().forEach(function(row){
				row.forEach(function(item,index){
					if(dataOptions[index].labelValues.indexOf(item.text) == -1){
						dataOptions[index].labelValues.push(item.text);
					}
				});
			});

			widget.options.data = dataOptions;

			return queryResult;
		}
	},

	render : function (widget, event) {

		//	Get the html element
		var el = $(event.element);

		//	Clear anything old in the html
		el.empty();

		//	Get the data
		var data = widget.options.data;

		//	Start with an empty div container
		var containerDiv = $('<div class="smartLabelContainer" style="font-size:' + widget.style.size + ';" align="'+ widget.style.halign + '"></div>');

		//	Loop through each label
		$.each(data, function(){

			//	Init variables for this label
			var labelName = '',
				labelValues;

			//Check for all selection
			var dim = this.labelDim;
			var filter = $.grep(prism.activeDashboard.filters.$$items, function(w) {
				return w.jaql.dim === dim;
			});

			var allFlag = false,
				noneFlag = false;

			//	Is there a filter?
			if (filter.length > 0) {

				//	Get the filter's jaql
				var jaqlFilter = filter[0].jaql.filter;
				//	Get the filter's disabled flag
				var isdisabled = filter[0].disabled;
				//	Figure out the number of members available
				var numberOfMembers = 0;
				if (!jaqlFilter.all) {
					numberOfMembers = jaqlFilter.members ? jaqlFilter.members.length : jaqlFilter.exclude.members.length;
				}
				//	Check if there is no selection
				if ((numberOfMembers===0) || (isdisabled) ) {
					//	The filter has no selection
					allFlag = true;
				}
			}


			//	Show the label title?
			if (widget.style.showLabels) {
				labelName = this.labelName + ': ';
			}

			//	Show the first result only, or all results?
			if (allFlag) {
				// show all
				labelValues = 'All';
			} else if (widget.style.showFirstOnly) {
				//	Show only the first value
				labelValues = this.labelValues[0] ? this.labelValues[0] : '';
			} else {
				//	Show all values separated by a comma and white space
				labelValues = this.labelValues.join(', ');
			}

			//	Create html element
			var thisDiv = $('<div class="smartLabelRow"><span class="smartLabelRowTitle">' + labelName + '</span><span class="smartLabelRowValues">' + labelValues + '</span></div>');

			//	Append this to the container
			containerDiv.append(thisDiv);
		});

		//	Add the container to the widget
		el.append(containerDiv);

	},

	destroy : function (s, e) {}
});