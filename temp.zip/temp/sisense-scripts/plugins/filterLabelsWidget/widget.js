
prism.registerWidget("filterLabelsWidget", {

	name : "filterLabelsWidget",
	family : "Text",
	title : "Filter Labels",
	iconSmall : "/plugins/filterLabelsWidget/widget-24.png",
	styleEditorTemplate: "/plugins/filterLabelsWidget/styler.html",
	hideNoResults:true,
	style: {
		url: "http://www.sisense.com/documentation/wp-content/uploads/2014/02/logo.png"
	},
	// sizing must be stated
	sizing: {

		minHeight: 50, //header
		maxHeight: 2048,
		minWidth: 128,
		maxWidth: 2048,
		height: 200,
		defaultWidth: 512
	},
	data : {

		selection : [],
		defaultQueryResult : {},
		panels : [],

		allocatePanel : function (widget, metadataItem) {	
			return -1;
		},

		// ranks the compatibility of the given metadata items with the widget
		rankMetadata : function (items, type, subtype) {
			return -1;
		},

		// populates the metadata items to the widget
		populateMetadata : function (widget, items) {
		},

		// builds a jaql query from the given widget
		buildQuery : function (widget) {
			var query = {
				datasource : widget.datasource,
				metadata : []
			};
			return query;
		},

		// prepares the widget-specific query result from the given result data-table
		processResult : function (widget, queryResult) {
			return queryResult;
		}
	},
	render : function (widget, event) {

		//	Get the widget body
		var $lmnt = $(event.element);	
		$lmnt.empty();
				
		//	Create HTML for a divider line
		//var dividerHtml = "<hr class='filterDivider'></hr>";
		
		/*********************
		**	TITLE SECTION   **
		*********************/
		
		//	Create HTML for Dashboard Name
	/* 	var title = widget.dashboard.title;
		var titleHTML = "<div class='filterDashboardLabel'>" + title + "</div>"; */
		
		/*********************
		**	FILTER SECTION   **
		*********************/
		
		//	Create HTML for an Icon
		var iconHTML = "";
		if (widget.style.url.length > 0) {
			var iconURL = widget.style.url;
			iconHTML = "<div class='filterIconContainer'><img class='filterIcon' src='" + iconURL + "'></img></div>";
		}
		
		//	Create HTML list for each filter
		var filtersHtml = "<div class='filterContainer'>" + iconHTML + "<div class='filterSubContainer'>";
		
		//	Get all the dashboard filters
		var filterObjects = widget.dashboard.filters.$$items;
		
		//	Function to create the HTML for each filter object
		var createFilterHTML = function(title,value) {
			var myHtml = "<div class='filterBox'><div class='filterTitle'>" + title + "</div><div class='filterValue'>" + value + "</div></div>";
			return myHtml;
		};
		
		//	Function to handle all the filter types - calls createFilterHTML() 
		var addFilter = function(jaql) {
			//debugger
			//	Get the filter name
			var title = jaql.title;
			
			//	Define List Item HTML
			var listItem = "";
			
			//	Create the <li>
			var myFilter = jaql.filter;
	
			if (myFilter.from) {
				// Handle Dates -> From and To
				listItem += createFilterHTML("From " + title,myFilter.from);
				listItem += createFilterHTML("To " + title,myFilter.to);				
			} else if (myFilter.last) {
				// Handle Dates -> Last
				var lastMember = "";
				if (myFilter.last.count == 1) {
					//	For specific date selections
					if (myFilter.last.offset == 0) {
						//	Should end up like "Last Year"
						lastMember += "This " + jaql.level.substring(0,jaql.level.length-1);
					} else {
						//	Should end up like "2 Years Ago"
						lastMember += myFilter.last.offset + " " + jaql.level + " Ago";
					}
				} else {
					//	For multiple date selections
					var offset = (myFilter.last.count-1);
					if (myFilter.last.offset == 0) {
						//	Should end up like "This and Last 2 Years"
						var level = jaql.level;
						if (offset == 1) {
							level = level.substring(0,level.length-1);
						}
						lastMember += "This and last " + offset + " " + level;
					} else {
						if (myFilter.last.offset > 0) {
							//	Should end up like "7 Days Ago, Minus 1"
							lastMember += myFilter.last.offset + " " + jaql.level + " Ago, Minus " + myFilter.last.offset;
						} else {
							//	Should end up like "7 Days Ago, Plus 1"
							lastMember += myFilter.last.offset + " " + jaql.level + " Ago, Plus " + (-1 * myFilter.last.offset);
						}
					}
				}
				listItem += createFilterHTML(title,lastMember);					
			} else if (myFilter.next) {
				// Handle Dates -> Next
				var lastMember = "";
				if (myFilter.next.count == 1) {
					//	For specific date selections
					if (myFilter.next.offset == 0) {
						//	Should end up like "Next Year"
						lastMember += "This " + jaql.level.substring(0,jaql.level.length-1);
					} else {
						//	Should end up like "2 Years Ago"
						lastMember += "Next " + myFilter.next.offset + " " + jaql.level;
					}
				} else {
					//	For multiple date selections
					var offset = (myFilter.next.count-1);
					if (myFilter.next.offset == 0) {
						//	Should end up like "This and Next 2 Years"
						var level = jaql.level;
						if (offset == 1) {
							level = level.substring(0,level.length-1);
						}
						lastMember += "This and Next " + offset + " " + level;
					} else {
						if (myFilter.next.offset > 0) {
							//	Should end up like "Next 7 Days, Minus 1"
							lastMember += myFilter.next.offset + " " + jaql.level + " Ago, Minus " + myFilter.next.offset;
						} else {
							//	Should end up like "Next 7 Days, Plus 1"
							lastMember += myFilter.next.offset + " " + jaql.level + " Ago, Plus " + (-1 * myFilter.next.offset);
						}
					}
				}
				listItem += createFilterHTML(title,lastMember);				
			} else if (myFilter.all) {
				//	Filter is for ALL members				
				listItem += createFilterHTML(title,"All");	
			} else if (myFilter.explicit || myFilter.exclude) {
				//debugger
				//	Filter is for including/excluding SPECIFIC members
				var selectedMembers = "";
				var isDatetime = (jaql.datatype == "datetime");
				var members = myFilter.exclude ? myFilter.exclude.members : myFilter.members;
				
				if(myFilter.filter!=undefined && myFilter.filter!=''){
					var excludeFlag=true;
					var excludedFilterMembers=myFilter.filter.exclude.members;
				}
				

				$.each(members, function() {
					if(selectedMembers.length>0 && selectedMembers[selectedMembers.length-1] != ",") {
						selectedMembers += ",";
					}
					
					var member = '';
					if (isDatetime){
						//debugger
							
						//	Define month names & convert the text to a datetime
						var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
						var thisDate = Date.parseDate(this.toString());
						var e_month= thisDate.getMonth();
						var e_Year = thisDate.getFullYear();
						var e_date = thisDate.getDate();
						
						//	Format for years, months, days
						if (jaql.level == "years") {
							//	Format for years
							var excluedFilterExist=true;
							if(excludeFlag && myFilter.filter!=undefined && myFilter.filter!=''){
								for(var a=0;a<excludedFilterMembers.length;a++){
									var newArray= excludedFilterMembers[a].split("-");
									if( e_Year== newArray[0] ){
										excluedFilterExist=false;
										break;
									}
								}
								
							}
							if(excluedFilterExist)
								member = e_Year;
						} else if (jaql.level == 'quarters') {
							//	Format for quarters
							var excluedFilterExist=true;
							if(excludeFlag && myFilter.filter!=undefined && myFilter.filter!=''){
								for(var a=0;a<excludedFilterMembers.length;a++){
									var newArray= excludedFilterMembers[a].split("-");
									if(((e_month / 3)+1)==(((newArray[1]-1)/3)+1)  && e_Year== newArray[0] ){
										excluedFilterExist=false;
										break;
									}
								}
								
							}
							if(excluedFilterExist)							
								member = 'Q' + ((e_month / 3) + 1) + ' ' + thisDate.getFullYear();
						} else if (jaql.level == "months") {
							//	Format for months
							
							var excluedFilterExist=true;
							if(excludeFlag && myFilter.filter!=undefined && myFilter.filter!=''){
								for(var a=0;a<excludedFilterMembers.length;a++){
									var newArray= excludedFilterMembers[a].split("-");
									if((e_month+1)==newArray[1]  && e_Year== newArray[0] ){
										excluedFilterExist=false;
										break;
									}
								}
								
							}
							if(excluedFilterExist)
								member = monthNames[e_month] + ' ' + e_Year;
						} else if (jaql.level == "days") {
							var excluedFilterExist=true;
							if(excludeFlag && myFilter.filter!=undefined && myFilter.filter!=''){
								for(var a=0;a<excludedFilterMembers.length;a++){
									var newArray= excludedFilterMembers[a].split("-");
									var subArray= newArray[2].split("T");
									  
									if((e_month+1)==newArray[1] && e_date==subArray[0] && e_Year== newArray[0] ){
										excluedFilterExist=false;
										break;
									}
								}
								
							}
							//	Format for days
							if(excluedFilterExist)
								member = monthNames[e_month] + ' ' + e_date +' ' + e_Year;
						} else {
							//	otherwise... no formatting
							member = this;
						}
					} else {
						var excluedFilterExist=true;
						//	No additional formatting needed
						if(excludeFlag && myFilter.filter!=undefined && myFilter.filter!=''){
							for(var a=0;a<excludedFilterMembers.length;a++){
								if(excludedFilterMembers[a]==this.concat()){
									excluedFilterExist=false;
									break;
								}
							}
							
						}
						if(excluedFilterExist)	
							member = this;
					}
					selectedMembers +=  member;
				});	

				//	Add label for excluding members
				if (myFilter.exclude) {
					if(selectedMembers!='')
						selectedMembers =  "NOT " + selectedMembers;
					
				}
				if(selectedMembers!='')
					listItem += createFilterHTML(title,selectedMembers);	
			} else if (myFilter.top) {
				//	Filter is for Top x members				
				var topMembers = "Top " + myFilter.top + " by " + myFilter.by.column;
				listItem += createFilterHTML(title,topMembers);
			} else if (myFilter.bottom) {
				//	Filter is for Bottom x members				
				var bottomMembers = "Bottom " + myFilter.bottom + " by " + myFilter.by.column;
				listItem += createFilterHTML(title,bottomMembers);
			} else if (myFilter.contains) {
				//	Filter is for Text -> contains			
				listItem += createFilterHTML(title,"Contains: " + myFilter.contains);
			} else if (myFilter.startsWith) {
				//	Filter is for Text -> startsWith
				listItem += createFilterHTML(title,"Starts with: " + myFilter.startsWith);
			} else if (myFilter.endsWith) {
				//	Filter is for Text -> endsWith
				listItem += createFilterHTML(title,"Ends with: " + myFilter.endsWith);
			} else if (myFilter.doesntStartWith) {
				//	Filter is for Text -> doesntStartWith
				listItem += createFilterHTML(title,"Doesn't Start with: " + myFilter.doesntStartWith);
			} else if (myFilter.doesntEndWith) {
				//	Filter is for Text -> doesntEndWith
				listItem += createFilterHTML(title,"Doesn't End with: " + myFilter.doesntEndWith);
			} else if (myFilter.doesntContain) {
				//	Filter is for Text -> doesntContain
				listItem += createFilterHTML(title,"Doesn't Contain: " + myFilter.doesntContain);
			} else if (myFilter.doesntEqual) {
				//	Filter is for Text -> doesntEqual
				listItem += createFilterHTML(title,"Doesn't Equal: " + myFilter.doesntEqual);
			} else if (myFilter.equals) {
				//	Filter is for Text -> contains
				listItem += createFilterHTML(title,"Equals: " + myFilter.equals);
			} else if (myFilter.custom) {
				//	Filter is Custom		
				listItem += createFilterHTML(title,"Custom");
			} 
			else if(myFilter.and){
				if(jaql.column=="HoursFromLatest"){
					var fromValue= -(myFilter.and[0]['from']);
					var fromTime=moment().subtract(fromValue,'hours').format('DD-MM-YYYY  hhA:mm:ss');
					var toTime=moment().format('DD-MM-YYYY  hhA:mm:ss');
					
					var filtersValue= "From:"+fromTime +" ,  To: "+toTime;
					listItem += createFilterHTML( title,filtersValue);
					
				}
				else{
					var filtersValue= "From:"+myFilter.and[0]['from'] +" , To:"+myFilter.and[1]['to'];
					listItem += createFilterHTML( title,filtersValue); 
				}
			}
			else {
				//	Default
				listItem = listItem += createFilterHTML(title,"");
			}
			
			return listItem;
		}
		
		//	Loop through each filter
		$.each(filterObjects, function() {			
			//	Add to HTML list
			if (!this.disabled) {
				$.each(this.getJAQL(), function(){
					filtersHtml += addFilter(this);
				});
			}
		});
		
		//	Close out HTML list
		filtersHtml += "</div></div>";
		
		/******************************
		**	PUT EVERYTHING TOGETHER  **
		******************************/
		
		//	Create FilterWidget HTML
		//var filterWidgetHTML = titleHTML + dividerHtml + filtersHtml;
		var filterWidgetHTML =  filtersHtml;
		
		//	Append HTML to the widget
		$lmnt.append($(filterWidgetHTML));
	
		//	Apply formatting to the widget
		
	},

	destroy : function (s, e) {}
});