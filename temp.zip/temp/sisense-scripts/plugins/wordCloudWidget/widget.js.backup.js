
prism.registerWidget("wordCloudWidget", {

	name : "wordCloudWidget",
	family : "Column",
	title : "Word Cloud",
	iconSmall : "/plugins/wordCloudWidget/widget-24.png",
	styleEditorTemplate: "/plugins/wordCloudWidget/styler.html",
	hideNoResults:true,
	style: {
		shape: "cloud"
	},
	data : {
		selection : [],
		defaultQueryResult : {},	
		panels : [
			{
				name: 'Category',
				type: "series",
				itemAttributes: ["color"],
				allowedColoringTypes: function() {
					return {
						color: true,
						condition: false,
						range: false
					}
				},
				metadata: {
					types: ['dimensions'],
					maxitems: 1
				}
			},
			{
				name: 'value',
				type: 'visible',	
				metadata: {
					types: ['measures'],
					maxitems: 1
				}
			},			
			{
				name: 'filters',
				type: 'filters',
				metadata: {
					types: ['dimensions'],
					maxitems: -1
				}
			}
		],
		
		canColor: function (widget, panel, item) {
			return (panel.name === "value" && widget.metadata.panel("Category").items.length == 0);
            //return panel.name === "value" ;
        },
		
		allocatePanel: function (widget, metadataItem) {
			// measure
			if (prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("value").items.length === 0) {

				return "value";
			}
			// dimension
			else if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("Category").items.length < 3) {

				return "Category";
			}
		},

		// returns true/ reason why the given item configuration is not/supported by the widget
		isSupported: function (items) {

			return this.rankMetadata(items, null, null) > -1;
		},

		// ranks the compatibility of the given metadata items with the widget
		rankMetadata: function (items, type, subtype) {

			var a = prism.$jaql.analyze(items);

			// require 1 measure, 1 dimension
			if (a.measures.length == 1 && a.dimensions.length == 1) {

				return 0;
			}

			return -1;
		},

		// populates the metadata items to the widget
		populateMetadata: function (widget, items) {

			var a = prism.$jaql.analyze(items);

			// allocating dimensions
			widget.metadata.panel("Category").push(a.dimensions);
			widget.metadata.panel("value").push(a.measures);

			// allocating filters
			widget.metadata.panel("filters").push(a.filters);
		},

		// builds a jaql query from the given widget
		buildQuery: function (widget) {
	
			// building jaql query object from widget metadata 
			var query = { datasource: widget.datasource, metadata: [] };

			// pushing dimension
			$.each(widget.metadata.panel("Category").items, function() {
				query.metadata.push(this);
			});
			
			// pushing value, and force a sort by
			$.each(widget.metadata.panel("value").items, function() {
				var valueObject = this;
				valueObject.jaql.sort = "desc";
				query.metadata.push(valueObject);
			});
			
			// pushing filters
			widget.metadata.panel('filters').items.forEach(function (item) {
				item = $$.object.clone(item, true);
				item.panel = "scope";
				query.metadata.push(item);
			});
			return query;
		},

		//create highcharts data structure
		processResult : function (widget, queryResult) {		
			
			//	Define data objects
			var data = queryResult.$$rows;
			var newResult = [];
			var max = data[0][1].data;
			var min = data[data.length-1][1].data;

			$.each(data, function() {
				var scaledSize = Math.round((this[1].data / max) * 100) + 6;
				var newElement = {
					text: this[0].text,
					color: this[0].color,
					size: scaledSize
				};
				newResult.push(newElement);
			});
			
			return newResult;
		}
	},
	render : function (s, e) {
	
		// Get widget elements
		var $lmnt = $(e.element);
		$lmnt.empty();
		
		var width = $lmnt.width(),
			height = $lmnt.height();
		
		// Prepare the container div
		var MyDiv = $lmnt[0],
			ObjectID = s.oid,
			ChartDivName = "WordCloud-" + ObjectID;		
		MyDiv.setAttribute("id",ChartDivName);
		MyDiv.setAttribute("style","width: 99%; height: 99%; margin: 0 auto");

		//	Define the words
		var myWords = s.queryResult;

		//	Define options
		var radians = Math.PI / 180,
			r = 40.5,
			px = 35,
      		py = 20,
			from = -60,
			to = 60,
			count = myWords.length,
			scale = d3.scale.linear(),
			arc = d3.svg.arc()
				.innerRadius(0)
				.outerRadius(r);
		
		//	Define the draw function
		var draw = function(words) {
			d3.select("#" + ChartDivName).append("svg")
			    .attr("width", width)
			    .attr("height", height)
			  .append("g")
			    .attr("transform", "translate(" + Math.round(width/2) + "," + Math.round(height/2) + ")")
			  .selectAll("text")
			    .data(words)
			  .enter().append("text")
			    .style("font-size", function(d) { return d.size + "px"; })
			    .style("font-family", "Impact")
			    .style("fill", function(d) { return d.color; })
			    .attr("text-anchor", "middle")
			    .attr("transform", function(d) {
			      return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
			    })
			    .text(function(d) { return d.text; });
		};
		
		//	Render the word cloud
		d3.layout.cloud().size([width, height])
		  .words(myWords)
		  .padding(5)
		  .rotate(function() { return ~~(Math.random() * 2) * 90; })
		  .font("Impact")
		  .fontSize(function(d) { return d.size; })
		  .on("end", draw)
		  .start();
	},


	destroy : function (s, e) {}
});