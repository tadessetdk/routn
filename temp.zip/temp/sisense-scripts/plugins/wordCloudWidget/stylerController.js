
mod.controller('stylerController', ['$scope',
    function ($scope) {

        /**
         * variables
         */


        /**
         * watches
         */
        $scope.$watch('widget', function (val) {

            $scope.model = $$get($scope, 'widget.style');
        });



        /**
         * public methods
         */

        $scope.shape = function (shape) {
        	$scope.model.shape = shape;
        	_.defer(function () {
        		$scope.$root.widget.redraw();
        	});
        };
		
        $scope.font = function (font) {
            $scope.model.font = font;
            _.defer(function () {
                $scope.$root.widget.redraw();
            });
        };

        $scope.scale = function (scale) {
            $scope.model.scale = scale;
            _.defer(function () {
                $scope.$root.widget.redraw();
            });
        };
		
    }
]);