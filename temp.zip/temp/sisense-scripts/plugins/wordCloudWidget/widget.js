
prism.registerWidget("wordCloudWidget", {

	name : "wordCloudWidget",
	family : "Column",
	title : "Word Cloud",
	iconSmall : "/plugins/wordCloudWidget/widget-24.png",
	styleEditorTemplate: "/plugins/wordCloudWidget/styler.html",
	//hideNoResults:true,
	style: {
		shape: "archimedean",
		font: "abelregular",
		scale: "log"
	},
	data : {
		selection : [],
		defaultQueryResult : {},	
		panels : [
			{
				name: 'Category',
				type: "series",
				itemAttributes: ["color"],
				allowedColoringTypes: function() {
					return {
						color: true,
						condition: false,
						range: false
					}
				},
				metadata: {
					types: ['dimensions'],
					maxitems: 1
				}
			},
			{
				name: 'value',
				type: 'visible',	
				metadata: {
					types: ['measures'],
					maxitems: 1
				}
			},			
			{
				name: 'filters',
				type: 'filters',
				metadata: {
					types: ['dimensions'],
					maxitems: -1
				}
			}
		],
		
		canColor: function (widget, panel, item) {
			return (panel.name === "value" && widget.metadata.panel("Category").items.length == 0);
            //return panel.name === "value" ;
        },
		
		allocatePanel: function (widget, metadataItem) {
			// measure
			if (prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("value").items.length === 0) {

				return "value";
			}
			// dimension
			else if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("Category").items.length < 3) {

				return "Category";
			}
		},

		// returns true/ reason why the given item configuration is not/supported by the widget
		isSupported: function (items) {

			return this.rankMetadata(items, null, null) > -1;
		},

		// ranks the compatibility of the given metadata items with the widget
		rankMetadata: function (items, type, subtype) {

			var a = prism.$jaql.analyze(items);

			// require 1 measure, 1 dimension
			if (a.measures.length == 1 && a.dimensions.length == 1) {

				return 0;
			}

			return -1;
		},

		// populates the metadata items to the widget
		populateMetadata: function (widget, items) {

			var a = prism.$jaql.analyze(items);

			// allocating dimensions
			widget.metadata.panel("Category").push(a.dimensions);
			widget.metadata.panel("value").push(a.measures);

			// allocating filters
			widget.metadata.panel("filters").push(a.filters);
		},

		// builds a jaql query from the given widget
		buildQuery: function (widget) {
	
			// building jaql query object from widget metadata 
			var query = { datasource: widget.datasource, metadata: [] };

			// pushing dimension
			var dummyFilters = null;
			$.each(widget.metadata.panel("Category").items, function() {				
				//	Add in dummy filter to ensure all members come back
				dummyFilter = $.extend({},this);
				dummyFilter.panel = "scope";
				dummyFilter.jaql.filter = {
					all:true,
					explicit:false,
					multiselect:true
				};
				query.metadata.push(this);
			});
			
			// pushing value, and force a sort by
			$.each(widget.metadata.panel("value").items, function() {
				var valueObject = this;
				valueObject.jaql.sort = "desc";
				query.metadata.push(valueObject);
			});
			
			// pushing filters
			widget.metadata.panel('filters').items.forEach(function (item) {
				item = $$.object.clone(item, true);
				item.panel = "scope";
				query.metadata.push(item);
			});	

			//query.metadata.push(dummyFilter);	

			return query;
		},

		//create highcharts data structure
		processResult : function (widget, queryResult) {		
			
			//	Define data objects
			var data = queryResult.$$rows;
			var newResult = [];
			var count = data.length;
			var max = data[0][1].data;
			var min = data[count-1][1].data;

			var fontSizeScale = d3.scale.linear()
				.domain([min,max])
				.range([5,30]);

			var rotateScale = d3.scale.linear()
				.domain([0, count - 1]).range([-60, 60]);

			$.each(data, function() {
				//var scaledSize = Math.round((this[1].data / max) * 100) + 6;
				var newElement = {
					text: this[0].text,
					color: this[0].color,
					size: fontSizeScale(~~this[1].data),
					rotate: rotateScale(~~((Math.round(100 * Math.random()) / 100) * count))
				};
				newResult.push(newElement);
			});
			
			return newResult;
		}
	},
	render : function (s, e) {

		// Get widget elements
		var $lmnt = $(e.element);
		$lmnt.empty();
		
		var width = $lmnt.width(),
			height = $lmnt.height();
		
		// Prepare the container div
		var MyDiv = $lmnt[0],
			ObjectID = s.oid,
			ChartDivName = "WordCloud-" + ObjectID;		
		MyDiv.setAttribute("id",ChartDivName);
		MyDiv.setAttribute("style","width: 99%; height: 99%; margin: 0 auto");

		//	Define the words
		var myWords = s.queryResult,
			max = myWords[0].size,
			min = myWords[myWords.length-1].size;

		//	Define user options
		var spiral =s.style.shape,
			font = s.style.font,
			sizeScale = s.style.scale;

		// 	Function to handle click events
		var clickHandler = function(d,i) {

			//	Get the widget and id
			var widgetId = $(this).closest('widget').attr('widgetid');

			//	Get the widget
			var widget = $.grep(prism.activeDashboard.widgets.$$widgets,function(w){
				return w.oid === widgetId;
			})[0];

			//	Only run if the "Widget Affects Dashboard Filters option is selected"
			if (widget.options.selector) {

				//	Get the filter jaql
				var filterJaql = $.extend({},widget.metadata.panel('Category').items[0].jaql);

				//	Make the selection
				filterJaql.filter = {
					members:[d.text]
				}

				//	Create filter obects
				var filterObj = {
					jaql: filterJaql
				};
				var filterSettings = {
					save:true, 
					refresh:true, 
					unionIfSameDimensionAndSameType:false
				};

				//	Set the filter
				prism.activeDashboard.filters.update(filterObj,filterSettings);
			}
		};
		
		//	Define the draw function
		var draw = function(words) {
			d3.select("#" + ChartDivName).append("svg")
					.attr("width", width)
					.attr("height", height)
					.append("g")					
					.attr("transform", "translate(" + Math.round(width/2) + "," + Math.round(height/2) + ")")
				.selectAll("text")
					.data(words)
				.enter().append("text")
					.attr('widgetId',ObjectID)
					.on('click',clickHandler)
					.style("font-size", "1px")
					.style("cursor", function(){
						if (s.options.selector) {
							return "pointer";
						} else {
							return "default";
						}
					})
					.style("font-family", font)
					.style("fill", function(d) { return d.color; })
					.attr("text-anchor", "middle")
					.attr("transform", function(d) {
						return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
					})
					.text(function(d) { return d.text; })
				.transition()
					.duration(1000)
					.style("font-size", function(d) { return d.size + "px"; });
		};

		

		//	Create the word cloud object
		var myCloud = d3.layout.cloud()
			.size([width, height])
			.words(myWords)
			.padding(5)
			.overflow(true)
			.rotate(function(d) { return d.rotate; })
			.fontSize(function(d) { return d.size; })
			.on("end", draw)
			.spiral(spiral)
			.start();
	},

	destroy : function (s, e) {}
});