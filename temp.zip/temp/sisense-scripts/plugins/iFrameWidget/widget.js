
prism.registerWidget("iframewidget", {

	name : "iframewidget",
	family : "embedding",
	title : "IFrame Widget",
	iconSmall : "/plugins/iFrameWidget/widget-24.png",
	styleEditorTemplate : "/plugins/iframeWidget/styler.html",
	hideNoResults:true,
	style : {
		url: "http://www.sisense.com"
	},
	options: {
		title: false
	},
	directive: {
	
		desktop: "iframewidget"
	},
	
	// sizing must be stated
	sizing: {

		minHeight: 128, //header
		maxHeight: 2048,
		minWidth: 128,
		maxWidth: 2048,
		height: 640,
		defaultWidth: 512
	},
	data : {

		selection : [],
		defaultQueryResult : {},
		
		panels : [
			{
				name : 'URL',
				type : 'visible',
				metadata : {

					types : ['dimensions'],
					maxitems : 1
				}
			}, 
			{
				name: 'filters',
				type: 'filters',
				metadata: {

					types: ['dimensions'],
					maxitems: -1
				}
			}
		],

		allocatePanel : function (widget, metadataItem) {
			
			if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("URL").items.length < 1) {

				return "URL";
			}
		},

		// ranks the compatibility of the given metadata items with the widget
		rankMetadata : function (items, type, subtype) {

			return -1;
		},

		// populates the metadata items to the widget
		populateMetadata : function (widget, items) {
			
			var a = prism.$jaql.analyze(items);

			// allocating dimensions
			widget.metadata.panel("URL").push(a.dimensions);
			widget.metadata.panel("filters").push(a.filters);

		},

		// builds a jaql query from the given widget
		buildQuery : function (widget) {

			// building jaql query object from widget metadata
			var query = {
				datasource : widget.datasource,
				metadata : []
			};

			// pushing items
			widget.metadata.panel("URL").items.forEach(function (item) {

				query.metadata.push(item);
			});
			
			// filters
			widget.metadata.panel('filters').items.forEach(function (item) {

				item = $$.object.clone(item, true);
				item.panel = "scope";

				query.metadata.push(item);
			});


			return query;
		},

		// prepares the widget-specific query result from the given result data-table
		processResult : function (widget, queryResult) {

			//	Look for the first record returned
			var newUrl = queryResult.$$rows[0];

			//	Were there any results?
			if (newUrl) {

				//	If so, set the url property
				widget.style.url = newUrl[0].text;
				
				//	Look for this widget
				var thisWidget = $('widget[widgetid=' + widget.oid + ']');

				//	Look for this iframe
				var iframe = $('iframe', thisWidget);

				//	Change the source
				iframe.attr('src',newUrl[0].text);

			}

		}
	}
});