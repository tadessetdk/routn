mod.directive('iframewidget', [
    
    function () {

    	return {

    		priority: 0,
    		replace: false,
    		transclude: false,
    		restrict: 'E',
    		link: function link($scope, lmnt, attrs) {
				var $frame = $("<iframe></iframe>");
                var url = $scope.widget.style.url ? $scope.widget.style.url : $scope.widget.title;
				$frame.attr("src", url);
				$frame.attr("marginwidth", 10);
				$(lmnt).append($frame);
    		}
    	}
    }]);

