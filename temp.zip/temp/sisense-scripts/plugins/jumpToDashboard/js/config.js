var appConfig = {
    drilledDashboardPrefix              : "_drill",             // The prefix of the drilled dashboards name.
    displayFilterPane                   : true,                 // Display filter pane in the drilled dashboard window.
    displayDashboardsPane               : true,                 // Display dashboards pane in the drilled dashboard window.
    displayToolbarRow                   : true,                 // Display toolbar in the drilled dashboard window.
    displayHeaderRow                    : true,                 // Display header in the drilled dashboard window.
    volatile                            : false,                // Volatile for the drilled dashboard window.
    hideDrilledDashboards               : true,                 // Hide drilled dashboards from the dashboards navigator for non owner users.
    drillToDashboardMenuCaption         : "Jump to dashboard",  // The caption for the drill to dashboard menu
    drillToDashboardRightMenuCaption    : "Jump to ",           // The caption for the drill to dashboard menu
    drillToDashboardNavigateType        : 1,                    // Default navigation type for widgets
    drillToDashboardNavigateTypePivot   : 2,                    // Navigation type for pivot widget
    drillToDashboardNavigateTypeCharts  : 1,                    // Navigation type for chart widgets
    drillToDashboardNavigateTypeOthers  : 3,                    // Navigation type for other widgets (indicator, richtexteditor, imageWidget)
    excludeFilterDims                   : [],                   // Dimensions to exclude from the drilled dashboard filter
    includeFilterDims                   : [],                   // Dimensions to include in the drilled dashboard filter
    drilledDashboardDisplayType         : 2,                    // How to display the drilled dashboard
    dashboardId                         : null,                 // Drilled dashboard id
    dashboardIds                        : [],                   // Dashboard IDs allowed to be drilled to
    dashboardCaption                    : null,                 // Drilled dashboard id
    modalWindowWidth                    : null,                 // Modal window width, In case the selected display type is modal window.
    modalWindowHeight                   : null,                 // Modal window height, In case the selected display type is modal window.
    showFolderNameOnMenuSelection       : false,                 // In case true, the folder name will be shown before the dashboard title inside the dashboards list menu
    resetDashFiltersAfterJTD            : false
};