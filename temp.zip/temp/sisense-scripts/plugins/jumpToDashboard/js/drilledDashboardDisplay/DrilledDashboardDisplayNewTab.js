// Drilled Dashboard Display New Tab class


function DrilledDashboardDisplayNewTab(){
    DrilledDashboardDisplayTab.call(this, false);
}

DrilledDashboardDisplayNewTab.prototype = Object.create(DrilledDashboardDisplayTab.prototype);
DrilledDashboardDisplayNewTab.prototype.constructor = DrilledDashboardDisplayNewTab;


