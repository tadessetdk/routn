 prism.registerWidget("helloworld", { 
	name : "helloworld", 
	family : "Column", 
	title : "Blank Html", 
	hideNoResults : true, 
	iconSmall : "/plugins/blankWidget/widget-24.png",
	data: {
        selection: [],
        defaultQueryResult: { message: "QUERY NOT SUCCESSFUL" },
        panels: [],
		buildQuery: function(widget, query) { 
			//debugger; 
			return query; 
		}, 
		processResult: function(widget, query) { 
				//debugger; 
				return {message: "Hello Morpheus!"}; 
		}
    },  
	render : function (s, e) { 
		
		//debugger
		
		var $e = $(e.element); 
		$e.empty();
		var xHtml="<div class='blankHtml' style='width:100%;height:100%;'></div>";
		$e.append(xHtml);
	
	}
});
 