
prism.parameters = {
	settings: {
		table: "Parameters"
	},
	dictionary: {}
}