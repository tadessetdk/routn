mod.directive('multifilterwidget', [
    '$timeout',
    'ux-controls.services.$dom',
    function ($timeout, $dom) {
        function linkFunction($scope, lmnt, attrs) {
            //  Add any additional code to run when creating the menu
			
			console.log($scope.widget.queryResult);
			
        }
    	return {
    		priority: 0,
    		replace: false,
    		templateUrl: "/plugins/multiFilterWidget/widget-template.html",
			transclude: false,
    		restrict: 'E',
    		link: linkFunction    
    	}
    }
]);

/* mod.config(['$provide', Decorate]);
function Decorate($provide) {
	$provide.decorator('filterwidget', function($delegate) {
		var directive = $delegate[0];
		directive.templateUrl = "/plugins/multiFilterWidget/widget-template.html";
		
		return directive;
    });
}  */

