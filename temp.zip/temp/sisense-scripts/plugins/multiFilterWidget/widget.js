prism.registerWidget('multiFilterWidget', {
	name: 'multiFilterWidget',
	family: 'multiFilterWidget',
	title: "Multi Filter",
	iconSmall: "/plugins/multiFilterWidget/widget-24.png",
	styleEditorTemplate: null,
	directive: {
		desktop: 'multifilterwidget'
	},
	style: {},
	data:  {
		selection: ['items'],
		defaultQueryResult: {},
		panels: [
			{
				name: 'items',
				type: 'visible',
				allowedDataTypes: ["text"],
				metadata: {
					types: ['dimensions'],
					maxitems: 10,
					sortable: {
						maxitems: 10
					}
				}
			},
			{
				name: 'filters',
				type: 'filters',
				metadata: {

					types: ['dimensions'],
					maxitems: -1
				}
			}
		],
		allocatePanel: function (widget, metadataItem) {
			return "items";
		},
		// returns true/ reason why the given item configuration is not/supported by the widget
		isSupported: function (items) {
			
			var a = prism.$jaql.analyze(items);
			return a.dimensions.length > 0 && a.measures.length === 0;
		},
		// ranks the compatibility of the given metadata items with the widget
		rankMetadata: function (items, type, subtype) {
			
			var a = prism.$jaql.analyze(items);
			
			// require at least 1 dimension
			if (a.measures.length > 0 || a.dimensions.length === 0) {
				return -1;
			}
			return 0;
		},
		// populates the metadata items to the widget
		populateMetadata: function (widget, items) {
			
			var a = prism.$jaql.analyze(items);
			
			// allocating dimensions
			widget.metadata.panel(0).push(a.dimensions);
			
			// allocating filters
			widget.metadata.panel("filters").push(a.filters);
		},


		// builds a jaql query from the given widget
		buildQuery: function (widget) {
			
			//debugger
			
			// building jaql query object from widget metadata 
			var query = { datasource: widget.datasource, metadata: [] };
			widget.metadata.panel(0).items.forEach(function (item) {
				query.metadata.push($$.object.clone(item, true));
			});

			// series - dimensions
			widget.metadata.panel('filters').items.forEach(function (item) {
				item = $$.object.clone(item, true);
				item.panel = "scope";
				query.metadata.push(item);
			});

			return query;
		},

		// prepares the widget-specific query result from the given result data-table
		processResult: function (widget, queryResult) {
			//debugger
			queryResult.outputArray=[];
			
			var resultArray=queryResult.$$rows;
			var v_elements=widget.metadata.panels[0].items;
			var v_length=v_elements.length; 
			var resultArrayLength=resultArray.length;
			
			for(var i=0;i<v_length;i++){
				var ele_name =  v_elements[i].jaql.title;
				var keys = [];
				var output=[];
				for(var j=0;j<resultArrayLength;j++){
					var key= resultArray[j][i]['data'];
					if(keys.indexOf(key) === -1) {
					  keys.push(key);
					  output.push(resultArray[j][i]);
				  }
					
				}
				var e_out=[];
				e_out['title']=ele_name;
				e_out['data']=output;
				queryResult.outputArray.push(e_out);
			} 
			
			
			
			return queryResult;
		}
	},

	ready: function(widget, args){
		
		
		//  Dropdown menu constructor
        function DropDown(el, metadata) {
			//debugger
            this.dd = el;
          	this.metadata = metadata;
            this.opts = this.dd.find('ul.filter-widget-dropdown > li');
            this.val = '';
            this.index = -1;
			this.initEvents();
        }

        //  Dropdown menu prototype
        DropDown.prototype = {
        	defaultClearSelection: "No Selection",
            initEvents : function() {
				//debugger
                var obj = this;
                //	Function for clicking on the dropdown menu
                var menuClick = function(event){
                	$(this).toggleClass('active');
                	//console.log("Menu clicked");
                    return false;
                };
                //	Attach the event handler only once
                if (!obj.dd.data('click-handled')) {
                	obj.dd.data('click-handled', true).on('click', menuClick);
                }
                //	Function for clicking on a menu item
                var itemClick = function() {
					//debugger
					
                    var opt = $(this);
					var parent_index=opt.attr("parent_index");
					if( parent_index=== undefined )
						parent_index=opt.next().attr("parent_index");
                    obj.val = opt.text();
                    obj.index = opt.index();
                    obj.setFilter(parent_index);
                    
					//debugger
					var spanId=obj.metadata[parent_index].jaql.title
                    if (obj.val === obj.defaultClearSelection) {
                    	$("#"+parent_index).text(obj.metadata[parent_index].jaql.title);
                    } else {
	                    //obj.placeholder.text(obj.val);
						$("#"+parent_index).text(obj.val);
						
	                }
                    console.log("item clicked");
                };

				$(obj.dd).each(function(v_index,v_element){
					var filterLength=prism.activeDashboard.filters.$$items.length;
					var filters=prism.activeDashboard.filters.$$items;
					var in_metadata= obj.metadata[v_index];
					//checking jaql exists in this metadata 
					if(in_metadata!=undefined && in_metadata.hasOwnProperty('jaql')){
						
						e_JaqlFilter=in_metadata.jaql;
						var is_member_exist=true;
						
						for(var i=0;i<filterLength;i++){
							if(filters[i]['jaql'].table==e_JaqlFilter.table && filters[i]['jaql'].column==e_JaqlFilter.column  && filters[i]['jaql'].datatype==e_JaqlFilter.datatype){
								
								$("#"+v_index).text( filters[i].jaql.filter.members );
								is_member_exist=false;
								break;
							}						
						}
						if(is_member_exist)
							$("#"+v_index).text( e_JaqlFilter.title );
					}
				});
					
                //	Loop through each menu item and attach event only once
                $.each(obj.opts, function(){
					
					if (!$(this).data('item-click-handled')) {
                		$(this).data('item-click-handled', true).on('click',itemClick);
                	}
                })
                
            },
            getValue : function() {
                return this.val;
            },
            getIndex : function() {
                return this.index;
            },
            setFilter: function(temp_parent_index) {
                //debugger
				
                //  Create JAQL Filter
                var filter = {
                    jaql: {
                        column: this.metadata[temp_parent_index]['jaql'].column,
                        table: this.metadata[temp_parent_index]['jaql'].table,
                        dim: this.metadata[temp_parent_index]['jaql'].dim,
                        datatype: this.metadata[temp_parent_index]['jaql'].datatype,
                        title: this.metadata[temp_parent_index]['jaql'].title
                    }
                };
                //	Set filter based on selection
                if (this.val === this.defaultClearSelection) {
                	//	Clearing the filter
                	filter.jaql.filter = {
                		all: true,
                		explicit: false,
                		multiSelection: false
                	};
                } else  {
                	//	Selecting a specific member
                	filter.jaql.filter = {
                		members:[this.val]
                	};
                }

                //  Create filter options
                var options = {
                    save: true,
                    refresh: true,
                    unionIfSameDimensionAndSameType:false
                };

                //debugger;
                //  Set via JavaScript API
                prism.activeDashboard.filters.update(filter,options);
            }
        }
        setTimeout(function(){
	        //  Initialize the dropdown
	        var metadata = widget.metadata.panels[0].items;
	        var widgetElement = $('widget[widgetid="'+widget.oid+'"]');
	        var dd = new DropDown( $('.filter-widget-wrapper',widgetElement), metadata );
	        $(document).click(function() {
	            // all dropdowns
	            $('.filter-widget-wrapper').removeClass('active');
	        });
	    
	        // Add CSS to handle overlfow
	        widgetElement.css("overflow","visible");
	        widgetElement.css("z-index","1000");
	    }, 1000);
	},
	mask: {
		numeric: function (widget, item) {
			return {
				type: "number",
				abbreviations: {
					t: true,
					b: true,
					m: true,
					k: false
				},
				separated: true,
				decimals: "auto"
			};
		}
	},
	options: {
		dashboardFiltersMode: "select",
		selector: true
	},
	sizing: {
		minHeight: 72, //header
		maxHeight: 2048,
		minWidth: 128,
		maxWidth: 2048,
		height: 72,
		defaultWidth: 512
	}
});
	
