//	Init the Dropdown menu constructor
function DropDown(el, metadata, widget) {                    
    this.dd = el;
    this.widget = widget;
    this.metadata = metadata[0].jaql;
    this.placeholder = this.dd.children('span');
    this.placeholder.text(this.getDashboardFilterSelection());
    this.opts = this.dd.find('ul.filter-widget-dropdown > li');
    this.val = '';
    this.index = -1;
    this.initEvents();
}

//  Dropdown menu prototype
DropDown.prototype = {
    defaultClearSelection: "No Selection",
    initEvents : function() {
        var obj = this;
        //  Function for clicking on the dropdown menu
        var menuClick = function(event){
            // Make sure all other menus are closed/hidden
            $('.filter-widget-wrapper').removeClass('active');
            $('widget[type="filterWidget"]').css('z-index',0);
            // Set the current menu as active                            
            $(this).toggleClass('active');
            // Set CSS to show the dropdown menu on top of other widgets
            var myWidget = $(this).parent().parent();
            myWidget.css("z-index",1000);
            myWidget.css("overflow","visible");                     
            return false;
        };
        //  Attach the event handler only once
        if (!obj.dd.data('click-handled')) {
            obj.dd.data('click-handled', true).on('click', menuClick);
        }
        //  Function for clicking on a menu item
        var itemClick = function() {
            
            var opt = $(this);            
            obj.val = opt.text();
            obj.data = new Date(opt.attr('ref'));
            obj.index = opt.index();
            obj.setFilter();                            
            if (obj.val === obj.defaultClearSelection) {
                obj.placeholder.text(obj.metadata.title);
            } else {
                obj.placeholder.text(obj.val);
            }
            //console.log("item clicked");
        };
        //  Loop through each menu item and attach event only once

        $.each(obj.opts, function(){
            if ($(this).data('item-click-handled')) {
                $(this).data('item-click-handled', true).off('click');
                $(this).data('item-click-handled', true).on('click',itemClick);
            } else {
                $(this).data('item-click-handled', true).on('click',itemClick);
            }
        })               
    },
    getValue : function() {
        return this.val;
    },
    getIndex : function() {
        return this.index;
    },
    setFilter: function() {
                              
        //  Create JAQL Filter
        var filter = {
            jaql: {
                column: this.metadata.column,
                table: this.metadata.table,
                dim: this.metadata.dim,
                datatype: this.metadata.datatype,
                level: this.metadata.level,
                title: this.metadata.title
            }
        };
        //  Define the value
        var selectedVal;
        //  What is the data type
        if (this.metadata.datatype === "datetime") {
            //  Datetime field
            selectedVal = this.data;
            /*
            //  Get the date mask
            var dimMask = this.widget.metadata.panel('items').itemsthisSeries.format.mask[this.metadata.level];
            //  Get the filter object

            debugger
            if (this.metadata.level === "years") {
                //  Create a date time obj for selected year
                selectedVal = new Date(parseInt(this.val),0,1);
            } else if (this.metadata.level === "quarters"){
                //  Create a datetime obj for selected year-quarter
                selectedVal = new Date(2014,9,1);                       
            } else if (this.metadata.level === "months"){
                //  Create a datetime obj for selected year-month
                selectedVal = new Date(2014,11,1);
            } else if (this.metadata.level === "days"){
                //  Create a datetime obj for selected year-month-day
                selectedVal = new Date(2014,11,25);
            } else {
                return;
            }
            */
        } else {
            //  value is a text field
            selectedVal = this.val;
        }
        //  Set filter based on selection
        if (this.val === this.defaultClearSelection) {
            //  Clearing the filter
            filter.jaql.filter = {
                all: true,
                explicit: false,
                multiSelection: true
            };
        } else  {
            //  Selecting a specific member
            filter.jaql.filter = {
                members:[selectedVal],
                all: false
            };
        }

        //  Create filter options
        var options = {
            save: true,
            refresh: false,
            unionIfSameDimensionAndSameType:false
        };

        //  Set via JavaScript API 
        prism.activeDashboard.filters.update(filter,options);

        //  Make sure the widgets get refreshed
        var refreshDashboard = function(){
            $.each(prism.activeDashboard.widgets.$$widgets,function(){
                this.refresh();
            })
        }
        setTimeout(refreshDashboard,500)
    },
    getDashboardFilterSelection: function() {               
        //  Define this object
        var obj = this;

        //  Get all the filters
        var filters = prism.activeDashboard.filters.$$items;
        
        //  Look for a filter for this dim
        var thisFilter = $.grep(filters, function(w){                            
            if (w.isCascading) {
                //  Handle dependant cascading filter
                var isMatch = false;
                $.each(w.levels,function(){
                    if (this.dim === obj.metadata.dim) {
                        isMatch = true;
                    }
                })
                return isMatch;
            } else {
                //  Normal filter
                return w.jaql.dim === obj.metadata.dim;
            }
        })[0];
        
        //  Is there a filter defined        
        var returnText = '';
        if (thisFilter) {  
            //  Get the filter jaql                            
            var thisJaql = null;   
            if (thisFilter.isCascading) {
                //  Part of a dependant filter
                $.each(thisFilter.levels,function(){
                    if (this.dim === obj.metadata.dim) {
                        thisJaql = this;
                    }
                })
            } else {
                //  Part of a normal filter
                thisJaql = thisFilter.jaql;
            }

            //  Get the selection here
            if (thisJaql.filter.all) {
                //  All members selected
                return obj.metadata.title;
            } else if (thisJaql.datatype === "datetime"){                        
                //  Format the date field                
                var dimMask = obj.widget.metadata.panel('items').items[0].format.mask;
                var mask = dimMask[thisJaql.level]
                var dateValue = thisFilter.jaql.filter.members[0];                        
                var dateFormatted = prism.dateFormatter(dateValue,mask);                        
                return dateFormatted;
            } else {                        
                //  Grab the text of what was selected
                return thisJaql.filter.members[0];
            }
        } else {                        
            //  No filter selected, just show the title
            return obj.metadata.title;
        }
    }
}