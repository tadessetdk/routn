//	Save the filter mask
prism.run(["$filter", function($filter) {	
	if (!prism.dateFormatter) {
		prism.dateFormatter = $filter("levelDate");
	}
}])

prism.registerWidget('filterWidget', {
	name: 'filterWidget',
	family: 'filterWidget',
	title: "Filter",
	iconSmall: "/plugins/filterWidget/widget-24.png",
	styleEditorTemplate: "/plugins/filterWidget/styler.html",
	style: {
		isDependantFilter: true,
		ignoreDashboardFilter: true
	},
	data:  {
		selection: ['items'],
		defaultQueryResult: {},
		panels: [
			{
				name: 'items',
				type: 'visible',
				allowedDataTypes: ["text"],
				metadata: {
					types: ['dimensions'],
					maxitems: 1,
					sortable: {
						maxitems: 1
					}
				}
			},
			{
				name: 'filters',
				type: 'filters',
				metadata: {

					types: ['dimensions'],
					maxitems: -1
				}
			}
		],
		allocatePanel: function (widget, metadataItem) {
			return "items";
		},
		// returns true/ reason why the given item configuration is not/supported by the widget
		isSupported: function (items) {
			
			var a = prism.$jaql.analyze(items);
			return a.dimensions.length > 0 && a.measures.length === 0;
		},
		// ranks the compatibility of the given metadata items with the widget
		rankMetadata: function (items, type, subtype) {
			
			var a = prism.$jaql.analyze(items);
			
			// require at least 1 dimension
			if (a.measures.length > 0 || a.dimensions.length === 0) {
				return -1;
			}
			return 0;
		},
		// populates the metadata items to the widget
		populateMetadata: function (widget, items) {
			
			var a = prism.$jaql.analyze(items);
			
			// allocating dimensions
			widget.metadata.panel(0).push(a.dimensions);
			
			// allocating filters
			widget.metadata.panel("filters").push(a.filters);
		},
		// builds a jaql query from the given widget
		buildQuery: function (widget) {
	    
			// building jaql query object from widget metadata 
			var query = { 
				datasource: widget.datasource, 
				metadata: [] 
			};

			//	Add in the panel item(s), save the dims			
			widget.metadata.panel(0).items.forEach(function (item) {
				//	Save a copy of the metadata item
				query.metadata.push($$.object.clone(item, true));
			});

			// Add in any widget filters			
			widget.metadata.panel('filters').items.forEach(function (item) {
				//	Create a copy of the filter item
				item = $$.object.clone(item, true);
				item.panel = "scope";
				query.metadata.push(item);
			});

			return query;
		},
		
		// prepares the widget-specific query result from the given result data-table
		processResult: function (widget, queryResult) {   
			var rows = queryResult.rows();                
			return rows;
		}
	},
	beforequery: function(widget,args){

		//	Ignore all dashboard filters
		if (widget.style.ignoreDashboardFilter){

			//	Get the widget's fitler items
			var widgetDimItems = [];
			$.each(widget.metadata.panel(0).items, function(){
				widgetDimItems.push(this.jaql.dim)
			});

			//	Get the widget's fitler items
			var widgetFilterItems = [];
			$.each(widget.metadata.panel("filters").items, function(){
				widgetFilterItems.push(this.jaql.dim)
			});

			//	Loop through the query's metadata			
			for (var i=args.query.metadata.length-1; i>=0; i--){

				//	Check to see if the item is a filter AND if it is a dashboard filter
				var isFilter = (args.query.metadata[i].panel == "scope"),
					isDashboardFilter = (widgetFilterItems.indexOf(args.query.metadata[i].jaql.dim) < 0),
					matchesDim = (widgetDimItems.indexOf(args.query.metadata[i].jaql.dim) >= 0);				
				
				//	Matches all three conditions, remove the item
				if (isFilter && isDashboardFilter && matchesDim){
					args.query.metadata.splice(i,1);
				}
				
			}
		}			
	},
	render: function(widget, args){		

		//	Is there any data?
		if (widget.metadata.panels[0].items.length ==  0) {
			//	Nope, don't bother drawing anything
			$(args.element).empty();
		} else {

			//	Yes there's data, init the menu
			var metadata = widget.metadata.panels[0].items,
				title = widget.metadata.panels[0].items[0].jaql.title;
			
			//	Build the HTML
			var container = $(args.element),
				wrapper = $("<div class='filter-widget-wrapper'>"),
				titleSpan = $("<span>" + title + "</span>"),
				list = $("<ul class='filter-widget-dropdown' style='overflow:scroll; z-index:1000;'>")
				firstItem = $("<li><a>No Selection</a></li>");

			//	Clear out any old html
			container.empty();

			//	Build up the list
			list.append(firstItem);
			for (var i=0; i<widget.queryResult.length; i++) {
				//	Create the new list item					
				var thisSeries = widget.queryResult[i][0] ? widget.queryResult[i][0] : {},
					thisSelected = thisSeries.selected ? true : false,
					thisText = thisSeries.text ? thisSeries.text : thisSeries.data.toString(),
					thisData = thisSeries.data,
					newItem = $('<li data-ng-class="{ selected: ' + thisSelected + ' }" ref="' + thisData + '"><a>' + thisText + '</a></li>');
				//	Append to the list
				list.append(newItem);				
			}
			
			//	Add the title and list to the container
			wrapper.append(titleSpan);
			wrapper.append(list);
			container.append(wrapper);			

			//	Init the dropdown menu
			var dd = new DropDown( $('.filter-widget-wrapper',container), metadata, widget );

	        //  Add a click handler for when a user clicks out of the dropdown
	        $(document).click(function() {                        
	            //  Hide the dropdown menu when clicking out
	            $('.filter-widget-wrapper').removeClass('active');
	        })

	        //	Special handler for mobile viewing
	        var isTabletOrPhone = (prism.$device.tablet() || prism.$device.phone());
	        if (isTabletOrPhone){
	        	
	        	//	Fix the widget's height
	        	var widgetBody = container.closest('widget');
	        	widgetBody.css('height','72px');
	        	
	        	//	Hide the widget header	        	
	        	var widgetHeader = $('widget-header',widgetBody);
	        	widgetHeader.css('display','none');
	        }
	    }
	},
	mask: {
		numeric: function (widget, item) {
			return {
				type: "number",
				abbreviations: {
					t: true,
					b: true,
					m: true,
					k: false
				},
				separated: true,
				decimals: "auto"
			};
		}
	},
	options: {
		dashboardFiltersMode: "highlight",
		selector: false,
        noSelectionText: ''
	},
	sizing: {
		minHeight: 72, //header
		maxHeight: 200,
		minWidth: 128,
		maxWidth: 200,
		height: 72,
		defaultWidth: 512
	}
});
	
