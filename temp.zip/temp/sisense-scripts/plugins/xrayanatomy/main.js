prism.run(["ux-controls.services.$dom","$compile",
function($dom,$compile){
	prism.registerWidget("xrayanatomy", 
	{

		name : "xrayanatomy",
		family : "xrayanatomy",
		title : "X-ray Diagram",
		iconSmall : "/plugins/xrayanatomy/widget-24.png",
		styleEditorTemplate : "",
		style : {},
		hideNoResults:false,
		// sizing must be stated
		sizing: {

			minHeight: 128, //header
			maxHeight: 2048,
			minWidth: 128,
			maxWidth: 2048,
			height: 640,
			defaultWidth: 512
		},
		options: {
			dashboardFiltersMode: "select",
			selector: true
		},
		directive:{
			desktop: "xrayanatomy" // name of the folder 
		},
		data : {

			selection : ['organs'],
			defaultQueryResult : {},

			panels : [
				//dimension panel
				{
					name : 'organs',
					type : 'visible',
					metadata : {

						types : ['dimensions'],
						maxitems : 1
					}
				},
				{//measure panel
					name : 'value', //must match canColor Funciton
					type : 'visible',
					itemAttributes: ["color"],
					allowedColoringTypes: function() {
					return  {
						color: true,
						condition: true,
						range: true
					};
				},
				metadata: {
					types: ['measures'],
					maxitems: 1
				},
				itemAdded: function(widget, item) {
					var colorFormatType = $$get(item, "format.color.type");
					if ("color" === colorFormatType || "color" === colorFormatType) {
						var color = item.format.color.color;
						defined(color) && "transparent" != color && "white" != color && "#fff" != color && "#ffffff" != color || $jaql.resetColor(item)
					}
					"range" === colorFormatType && $jaql.resetColor(item), defined(item, "format.color_bkp") && $jaql.resetColor(item), defined(item, "format.members") && delete item.format.members
				}
			},
				{
					name: 'filters',
					type: 'filters',
					metadata: {

						types: ['dimensions'],
						maxitems: -1
					}
				}
			],
			
			canColor: function (widget, panel, item) {			
            return panel.name === "value" ; // must match what needs to be colored 
        },

			allocatePanel : function (widget, metadataItem) {
				// measure
				if (prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("value").items.length === 0) {

					return "value";
				}

				// item
				else if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("organs").items.length < 3) {

					return "items";
				}
			},

			// returns true/ reason why the given item configuration is not/supported by the widget
			isSupported : function (items) {

				return this.rankMetadata(items, null, null) > -1;
			},

			// ranks the compatibility of the given metadata items with the widget
			rankMetadata : function (items, type, subtype) {

				var a = prism.$jaql.analyze(items);

				// require at least 2 dimensions of lat and lng and 1 measure
				if (a.dimensions.length >= 2 && a.measures.length == 1) {

					return 0;
				}
				return -1;
			},

			// populates the metadata items to the widget
			populateMetadata : function (widget, items) {
				debugger;
				var a = prism.$jaql.analyze(items);

				// allocating dimensions
				widget.metadata.panel("organs").push(a.dimensions);
				widget.metadata.panel("value").push(a.measures);
				widget.metadata.panel("filters").push(a.filters);
			},

			// builds a jaql query from the given widget
			buildQuery : function (widget) {
				
				// building jaql query object from widget metadata
				var query = {
					datasource : widget.datasource,
					metadata : []
				};

				// pushing items
				widget.metadata.panel("organs").items.forEach(function (item) {
					query.metadata.push(item);
				});

				// pushing data
				query.metadata.push(widget.metadata.panel("value").items[0]);
				//console.log("The check item[0] " + widget.metadata.panel("value").items[0]);

				// series - dimensions
				widget.metadata.panel('filters').items.forEach(function (item) {

					item = $$.object.clone(item, true);
					item.panel = "scope";

					query.metadata.push(item);
				});

				return query;
			},

			// prepares the widget-specific query result from the given result data-table
			processResult : function (widget, queryResult) {
				return queryResult;
			}
		},
		
		render : function (widget, e) 
		{
			debugger;

			/** variable declaration **/
			// widget element
			var $lmnt = $(e.element);
			//$lmnt.empty();
			//$lmnt.remove();
				
			var results = widget.rawQueryResult,
				rawData = widget.queryResult.$$rows,
				headers = widget.rawQueryResult.headers,
				i;

			var width = $lmnt.width(),
				height = $lmnt.height();
			
			// Prepare the container div
			/*var MyDiv = $('<xrayanatomy class="widget-body"></xrayanatomy>');
				ObjectID = widget.oid,
				DivName = "xrayanatomy-" + ObjectID;*/
				
			var MyDiv = $lmnt[0],
				ObjectID = widget.oid,
				DivName = "xrayanatomy-" + ObjectID;
			//<xrayanatomy class="widget-body" data-ng-class="{error:widget.$error, 'no-results-widget-body':!widget.manifest.hideNoResults &amp;&amp; widget.$noResults}"></xrayanatomy>
			var pathIDs = [];
			var anatomies = [];
			var pathDefaultColors = [];
			var pathHighlightColors = [];

			if (!defined(MyDiv)){
				return;
			}
			
			MyDiv.setAttribute("id",DivName);
			MyDiv.setAttribute("style","width: 99%; height: 99%; margin: 0 auto");	
			/*var svgTemplate = '<div id="svgContent" ng-include="\'/plugins/xrayanatomy/views/XRayDiagram.html\'"></div></div>';
			$(MyDiv).append(svgTemplate);
			var svgContent = document.getElementById("svgContent");
			var local_scope = angular.element(svgContent).scope();
			var compiledSVGTemplate = $compile(svgContent)(prism.$ngscope);
			MyDiv.append(compiledSVGTemplate[0]);
			prism.$ngscope.$apply();*/
			/*MyDiv[0].setAttribute("id",DivName);
			MyDiv[0].setAttribute("style","width: 99%; height: 99%; margin: 0 auto");	
			var svgTemplate = '<div><div ng-include="\'/plugins/xrayanatomy/views/XRayDiagram.html\'"></div></div>';
			var compiledSVGTemplate = $compile(svgTemplate)(prism.$ngscope);
			MyDiv[0].append(compiledSVGTemplate[0]);*/
			
			//prism.$ngscope.$apply();*/
			
			function addToolTip(id, organ, value){ //function to add Tool Tip
				var settings = {
						template:"<div> " + organ + " - " + value + " </div>",
						scope: prism.$ngscope
					},
					ui = {
						placement: {
							place: 'r',
							anchor: 't'
						},
						initialShowDelay: 100,
						betweenShowDelay: 100
					};
				//
				var tip = $dom.tip(settings,ui);
				$(" #" + id, $lmnt).hover(function(ev){
						//console.log("in");

						tip.activate({
							x: ev.clientX,
							y: ev.clientY,
							space: 10
						});
					},
					function(){
						tip.deactivate();
						//console.log("out")
					});

				//TODO - Double check you're not making multiple tooltip handlers
				$(" #" + id, $lmnt).on("contextmenu", function(ev){
					ev.preventDefault();
					ev.stopPropagation();


				})
			}
			
			function changeColor(id, value){
				//alert("Acknowledge to modify object color.");
				if(value!="#828487" && value!="#056083"){ //check if grey  //old value - #6a6a6a
					var object = document.getElementById(id);
					if(object){
						pathDefaultColors.push(object.style.fill);
						object.style.fill = value;		
						pathHighlightColors.push(value);
					}
				}
				/* remove the below code after testing */
				if(id=="path4816"){
					var paths = document.getElementsByClassName("Skull"); // Select all paths with class as 'Skull'
					for(var i = 0; i<paths.length ; i++){
						paths[i].style.fill = value;
					}
				}
				
				if(id=="path3347"){
					var paths = document.getElementsByClassName("Abdomen"); // Select all paths with class as 'Abdomen'
					for(var i = 0; i<paths.length ; i++){
						paths[i].style.fill = value;
					}
				}
				
			}
			
			function addToClickHandlerArrays(id,anatomy)
			{
				
				//TODO - Don't double add these items
				pathIDs.push("#"+id);//this is what I am going to click
			    anatomies.push(anatomy);// this is what I am going to filter
			}
			
			var filter = widget.dashboard.filters.item(widget.metadata.panels[0].items[0].jaql.dim);
			if (filter && filter.jaql.filter.all){  //when a anatomy is selected/filtered render is fired again which resets all highlighting/transparency added 
				for(i = 0; i< rawData.length; i++){ //Below code to color anatomies need to be called when there is no selection/filtering of anatomy in the diagram. 
					if (rawData[i][0].text.equalsIgnoreCase("Chest")) 
					{
						//left side
						addToolTip("path17", "Chest" ,rawData[i][1].text);
						changeColor("path17", rawData[i][1].color);
						addToolTip("path11", "Chest" ,rawData[i][1].text);
						changeColor("path11", rawData[i][1].color);
						addToolTip("path13", "Chest" ,rawData[i][1].text);
						changeColor("path13", rawData[i][1].color);
						addToolTip("path9", "Chest" ,rawData[i][1].text);
						changeColor("path9", rawData[i][1].color);
						addToClickHandlerArrays("path11",rawData[i][0].text)
						addToClickHandlerArrays("path17",rawData[i][0].text)
						addToClickHandlerArrays("path13",rawData[i][0].text)
						addToClickHandlerArrays("path9",rawData[i][0].text)
						
						//Sternum
						addToolTip("path5618","Chest",rawData[i][1].text)
						changeColor("path5618",rawData[i][1].color);
						addToClickHandlerArrays("path5618",rawData[i][0].text)		
						addToolTip("path4896","Chest",rawData[i][1].text)
						changeColor("path4896",rawData[i][1].color);
						addToClickHandlerArrays("path4896",rawData[i][0].text)
						
						//Rib
						addToolTip("path331", "Chest",rawData[i][1].text)
						changeColor("path331",rawData[i][1].color);
						addToolTip("path331-3", "Chest",rawData[i][1].text)
						changeColor("path331-3",rawData[i][1].color);	
						addToClickHandlerArrays("path331",rawData[i][0].text)
						addToClickHandlerArrays("path331-3",rawData[i][0].text)	
						
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Abdomen")){
						addToolTip("path3347", "Abdomen",rawData[i][1].text)
						changeColor("path3347",rawData[i][1].color);
						addToClickHandlerArrays("path3347",rawData[i][0].text)
					}else if(rawData[i][0].text.equalsIgnoreCase("Hand")){
						//hand
						addToolTip("path5173", "Hand",rawData[i][1].text)
						changeColor("path5173",rawData[i][1].color);		
						addToClickHandlerArrays("path5173",rawData[i][0].text)
						addToolTip("path3354", "Hand",rawData[i][1].text)
						changeColor("path3354",rawData[i][1].color);		
						addToClickHandlerArrays("path3354",rawData[i][0].text)	
								
						//left thumb
						addToolTip("path5578", "Hand",rawData[i][1].text)
						changeColor("path5578",rawData[i][1].color);
						addToolTip("path5424", "Hand",rawData[i][1].text)
						changeColor("path5424",rawData[i][1].color);
						addToClickHandlerArrays("path5424",rawData[i][0].text)
						addToClickHandlerArrays("path5578",rawData[i][0].text)
						
						//WRIST
						addToolTip('path5390','Hand',rawData[i][1].text);
						changeColor('path5390',rawData[i][1].color);
						addToClickHandlerArrays('path5390',rawData[i][0].text);
						addToolTip('path5400','Hand',rawData[i][1].text);
						changeColor('path5400',rawData[i][1].color);
						addToClickHandlerArrays('path5400',rawData[i][0].text);
						addToolTip('path5516','Hand',rawData[i][1].text);
						changeColor('path5516',rawData[i][1].color);
						addToClickHandlerArrays('path5516',rawData[i][0].text);
						addToolTip('path5538','Hand',rawData[i][1].text);
						changeColor('path5538',rawData[i][1].color);
						addToClickHandlerArrays('path5538',rawData[i][0].text);
						addToolTip('path5390','Hand',rawData[i][1].text);
						changeColor('path5390',rawData[i][1].color);
						addToClickHandlerArrays('path5390',rawData[i][0].text);
						addToolTip('path5412','Hand',rawData[i][1].text);
						changeColor('path5412',rawData[i][1].color);
						addToClickHandlerArrays('path5412',rawData[i][0].text);
						addToolTip('path5410','Hand',rawData[i][1].text);
						changeColor('path5410',rawData[i][1].color);
						addToClickHandlerArrays('path5410',rawData[i][0].text);
						addToolTip('path5546','Hand',rawData[i][1].text);
						changeColor('path5546',rawData[i][1].color);
						addToClickHandlerArrays('path5546',rawData[i][0].text);
						addToolTip('path5526','Hand',rawData[i][1].text);
						changeColor('path5526',rawData[i][1].color);
						addToClickHandlerArrays('path5526',rawData[i][0].text);
						addToolTip('path5284','Hand',rawData[i][1].text);
						changeColor('path5284',rawData[i][1].color);
						addToClickHandlerArrays('path5284',rawData[i][0].text);
						addToolTip('path5266','Hand',rawData[i][1].text);
						changeColor('path5266',rawData[i][1].color);
						addToClickHandlerArrays('path5266',rawData[i][0].text);
						addToolTip('path5286','Hand',rawData[i][1].text);
						changeColor('path5286',rawData[i][1].color);
						addToClickHandlerArrays('path5286',rawData[i][0].text);
						addToolTip('path5264','Hand',rawData[i][1].text);
						changeColor('path5264',rawData[i][1].color);
						addToClickHandlerArrays('path5264',rawData[i][0].text);
						addToolTip('path5300','Hand',rawData[i][1].text);
						changeColor('path5300',rawData[i][1].color);
						addToClickHandlerArrays('path5300',rawData[i][0].text);
						addToolTip('path5276','Hand',rawData[i][1].text);
						changeColor('path5276',rawData[i][1].color);
						addToClickHandlerArrays('path5276',rawData[i][0].text);
						addToolTip('path5326','Hand',rawData[i][1].text);
						changeColor('path5326',rawData[i][1].color);
						addToClickHandlerArrays('path5326',rawData[i][0].text);
						addToolTip('path5320','Hand',rawData[i][1].text);
						changeColor('path5320',rawData[i][1].color);
						addToClickHandlerArrays('path5320',rawData[i][0].text);
						addToolTip('path5312','Hand',rawData[i][1].text);
						changeColor('path5312',rawData[i][1].color);
						addToClickHandlerArrays('path5312',rawData[i][0].text);
						addToolTip('path5302','Hand',rawData[i][1].text);
						changeColor('path5302',rawData[i][1].color);
						addToClickHandlerArrays('path5302',rawData[i][0].text);
						addToolTip('path5274','Hand',rawData[i][1].text);
						changeColor('path5274',rawData[i][1].color);
						addToClickHandlerArrays('path5274',rawData[i][0].text);
						addToolTip('path5320','Hand',rawData[i][1].text);
						changeColor('path5320',rawData[i][1].color);
						addToClickHandlerArrays('path5320',rawData[i][0].text);
						
						//finger
						addToolTip('path5172','Hand',rawData[i][1].text);
						changeColor('path5172',rawData[i][1].color);
						addToClickHandlerArrays('path5172',rawData[i][0].text);
						addToolTip('path5156','Hand',rawData[i][1].text);
						changeColor('path5156',rawData[i][1].color);
						addToClickHandlerArrays('path5156',rawData[i][0].text);
						addToolTip('path5352','Hand',rawData[i][1].text);
						changeColor('path5352',rawData[i][1].color);
						addToClickHandlerArrays('path5352',rawData[i][0].text);
						addToolTip('path5344','Hand',rawData[i][1].text);
						changeColor('path5344',rawData[i][1].color);
						addToClickHandlerArrays('path5344',rawData[i][0].text);
						addToolTip('path5244','Hand',rawData[i][1].text);
						changeColor('path5244',rawData[i][1].color);
						addToClickHandlerArrays('path5244',rawData[i][0].text);
						addToolTip('path5214','Hand',rawData[i][1].text);
						changeColor('path5214',rawData[i][1].color);
						addToClickHandlerArrays('path5214',rawData[i][0].text);
						addToolTip('path5226','Hand',rawData[i][1].text);
						changeColor('path5226',rawData[i][1].color);
						addToClickHandlerArrays('path5226',rawData[i][0].text);
						addToolTip('path5332','Hand',rawData[i][1].text);
						changeColor('path5332',rawData[i][1].color);
						addToClickHandlerArrays('path5332',rawData[i][0].text);
						addToolTip('path5194','Hand',rawData[i][1].text);
						changeColor('path5194',rawData[i][1].color);
						addToClickHandlerArrays('path5194',rawData[i][0].text);
						addToolTip('path5064','Hand',rawData[i][1].text);
						changeColor('path5064',rawData[i][1].color);
						addToClickHandlerArrays('path5064',rawData[i][0].text);
						addToolTip('path5104','Hand',rawData[i][1].text);
						changeColor('path5104',rawData[i][1].color);
						addToClickHandlerArrays('path5104',rawData[i][0].text);
						addToolTip('path5108','Hand',rawData[i][1].text);
						changeColor('path5108',rawData[i][1].color);
						addToClickHandlerArrays('path5108',rawData[i][0].text);
						addToolTip('path5190','Hand',rawData[i][1].text);
						changeColor('path5190',rawData[i][1].color);
						addToClickHandlerArrays('path5190',rawData[i][0].text);
						addToolTip('path5366','Hand',rawData[i][1].text);
						changeColor('path5366',rawData[i][1].color);
						addToClickHandlerArrays('path5366',rawData[i][0].text);
						addToolTip('path5200','Hand',rawData[i][1].text);
						changeColor('path5200',rawData[i][1].color);
						addToClickHandlerArrays('path5200',rawData[i][0].text);
						addToolTip('path5072','Hand',rawData[i][1].text);
						changeColor('path5072',rawData[i][1].color);
						addToClickHandlerArrays('path5072',rawData[i][0].text);
						addToolTip('path5124','Hand',rawData[i][1].text);
						changeColor('path5124',rawData[i][1].color);
						addToClickHandlerArrays('path5124',rawData[i][0].text);
						addToolTip('path5072','Hand',rawData[i][1].text);
						changeColor('path5072',rawData[i][1].color);
						addToClickHandlerArrays('path5072',rawData[i][0].text);
						addToolTip('path5202','Hand',rawData[i][1].text);
						changeColor('path5202',rawData[i][1].color);
						addToClickHandlerArrays('path5202',rawData[i][0].text);
						addToolTip('path5372','Hand',rawData[i][1].text);
						changeColor('path5372',rawData[i][1].color);
						addToClickHandlerArrays('path5372',rawData[i][0].text);
						addToolTip('path5208','Hand',rawData[i][1].text);
						changeColor('path5208',rawData[i][1].color);
						addToClickHandlerArrays('path5208',rawData[i][0].text);
						addToolTip('path5090','Hand',rawData[i][1].text);
						changeColor('path5090',rawData[i][1].color);
						addToClickHandlerArrays('path5090',rawData[i][0].text);
						addToolTip('path5144','Hand',rawData[i][1].text);
						changeColor('path5144',rawData[i][1].color);
						addToClickHandlerArrays('path5144',rawData[i][0].text);
						addToolTip('path5300','Hand',rawData[i][1].text);
						changeColor('path5300',rawData[i][1].color);
						addToClickHandlerArrays('path5300',rawData[i][0].text);
						addToolTip('path5302','Hand',rawData[i][1].text);
						changeColor('path5302',rawData[i][1].color);
						addToClickHandlerArrays('path5302',rawData[i][0].text);
						addToolTip('path5328','Hand',rawData[i][1].text);
						changeColor('path5328',rawData[i][1].color);
						addToClickHandlerArrays('path5328',rawData[i][0].text);
						addToolTip('path5320','Hand',rawData[i][1].text);
						changeColor('path5320',rawData[i][1].color);
						addToClickHandlerArrays('path5320',rawData[i][0].text);
						addToolTip('path5326','Hand',rawData[i][1].text);
						changeColor('path5326',rawData[i][1].color);
						addToClickHandlerArrays('path5326',rawData[i][0].text);
						addToolTip('path5244','Hand',rawData[i][1].text);
						changeColor('path5244',rawData[i][1].color);
						addToClickHandlerArrays('path5244',rawData[i][0].text);
						addToolTip('path5390','Hand',rawData[i][1].text);
						changeColor('path5390',rawData[i][1].color);
						addToClickHandlerArrays('path5390',rawData[i][0].text);
						addToolTip('path5392','Hand',rawData[i][1].text);
						changeColor('path5392',rawData[i][1].color);
						addToClickHandlerArrays('path5392',rawData[i][0].text);
						addToolTip('path5400','Hand',rawData[i][1].text);
						changeColor('path5400',rawData[i][1].color);
						addToClickHandlerArrays('path5400',rawData[i][0].text);
						addToolTip('path5516','Hand',rawData[i][1].text);
						changeColor('path5516',rawData[i][1].color);
						addToClickHandlerArrays('path5516',rawData[i][0].text);
						addToolTip('path5540','Hand',rawData[i][1].text);
						changeColor('path5540',rawData[i][1].color);
						addToClickHandlerArrays('path5540',rawData[i][0].text);
						addToolTip('path5544','Hand',rawData[i][1].text);
						changeColor('path5544',rawData[i][1].color);
						addToClickHandlerArrays('path5544',rawData[i][0].text);
						addToolTip('path5526','Hand',rawData[i][1].text);
						changeColor('path5526',rawData[i][1].color);
						addToClickHandlerArrays('path5526',rawData[i][0].text);
						addToolTip('path5600','Hand',rawData[i][1].text);
						changeColor('path5600',rawData[i][1].color);
						addToClickHandlerArrays('path5600',rawData[i][0].text);
						addToolTip('path5604','Hand',rawData[i][1].text);
						changeColor('path5604',rawData[i][1].color);
						addToClickHandlerArrays('path5604',rawData[i][0].text);
						addToolTip('path5616','Hand',rawData[i][1].text);
						changeColor('path5616',rawData[i][1].color);
						addToClickHandlerArrays('path5616',rawData[i][0].text);
						addToolTip('path5584','Hand',rawData[i][1].text);
						changeColor('path5584',rawData[i][1].color);
						addToClickHandlerArrays('path5584',rawData[i][0].text);
						addToolTip('path5578','Hand',rawData[i][1].text);
						changeColor('path5578',rawData[i][1].color);
						addToClickHandlerArrays('path5578',rawData[i][0].text);
						addToolTip('path5424','Hand',rawData[i][1].text);
						changeColor('path5424',rawData[i][1].color);
						addToClickHandlerArrays('path5424',rawData[i][0].text);
						addToolTip('path5436','Hand',rawData[i][1].text);
						changeColor('path5436',rawData[i][1].color);
						addToClickHandlerArrays('path5436',rawData[i][0].text);
						addToolTip('path5448','Hand',rawData[i][1].text);
						changeColor('path5448',rawData[i][1].color);
						addToClickHandlerArrays('path5448',rawData[i][0].text);
						addToolTip('path5452','Hand',rawData[i][1].text);
						changeColor('path5452',rawData[i][1].color);
						addToClickHandlerArrays('path5452',rawData[i][0].text);
						addToolTip('path5570','Hand',rawData[i][1].text);
						changeColor('path5570',rawData[i][1].color);
						addToClickHandlerArrays('path5570',rawData[i][0].text);
						addToolTip('path5512','Hand',rawData[i][1].text);
						changeColor('path5512',rawData[i][1].color);
						addToClickHandlerArrays('path5512',rawData[i][0].text);
						addToolTip('path5498','Hand',rawData[i][1].text);
						changeColor('path5498',rawData[i][1].color);
						addToClickHandlerArrays('path5498',rawData[i][0].text);
						addToolTip('path5486','Hand',rawData[i][1].text);
						changeColor('path5486',rawData[i][1].color);
						addToClickHandlerArrays('path5486',rawData[i][0].text);
						addToolTip('path5462','Hand',rawData[i][1].text);
						changeColor('path5462',rawData[i][1].color);
						addToClickHandlerArrays('path5462',rawData[i][0].text);
						addToolTip('path5478','Hand',rawData[i][1].text);
						changeColor('path5478',rawData[i][1].color);
						addToClickHandlerArrays('path5478',rawData[i][0].text);
						addToolTip('path5470','Hand',rawData[i][1].text);
						changeColor('path5470',rawData[i][1].color);
						addToClickHandlerArrays('path5470',rawData[i][0].text);
						addToolTip('path5510','Hand',rawData[i][1].text);
						changeColor('path5510',rawData[i][1].color);
						addToClickHandlerArrays('path5510',rawData[i][0].text);
						addToolTip('path5570','Hand',rawData[i][1].text);
						changeColor('path5570',rawData[i][1].color);
						addToClickHandlerArrays('path5570',rawData[i][0].text);
						addToolTip('path5558','Hand',rawData[i][1].text);
						changeColor('path5558',rawData[i][1].color);
						addToClickHandlerArrays('path5558',rawData[i][0].text);
						addToolTip('path5550','Hand',rawData[i][1].text);
						changeColor('path5550',rawData[i][1].color);
						addToClickHandlerArrays('path5550',rawData[i][0].text);
						addToolTip('path5610','Hand',rawData[i][1].text);
						changeColor('path5610',rawData[i][1].color);
						addToClickHandlerArrays('path5610',rawData[i][0].text);
						addToolTip('path5242','Hand',rawData[i][1].text);
						changeColor('path5242',rawData[i][1].color);
						addToClickHandlerArrays('path5242',rawData[i][0].text);
						
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Femur")){
						addToolTip("path3838", "Femur",rawData[i][1].text)
						changeColor("path3838",rawData[i][1].color);
						addToolTip("path3834", "Femur",rawData[i][1].text)
						changeColor("path3834",rawData[i][1].color);
						addToolTip("path3858", "Femur",rawData[i][1].text)
						changeColor("path3858",rawData[i][1].color);
						addToolTip("path3862", "Femur",rawData[i][1].text)
						changeColor("path3862",rawData[i][1].color);
						addToolTip("path3860", "Femur",rawData[i][1].text)
						changeColor("path3860",rawData[i][1].color);
						addToolTip("path3852", "Femur",rawData[i][1].text)
						changeColor("path3852",rawData[i][1].color);
						addToClickHandlerArrays("path3834",rawData[i][0].text)
						addToClickHandlerArrays("path3838",rawData[i][0].text)
						addToClickHandlerArrays("path3858",rawData[i][0].text)
						addToClickHandlerArrays("path3862",rawData[i][0].text)
						addToClickHandlerArrays("path3860",rawData[i][0].text)
						addToClickHandlerArrays("path3852",rawData[i][0].text)
					}else if(rawData[i][0].text.equalsIgnoreCase("Foot")){
						addToolTip("path5233", "Foot",rawData[i][1].text)
						changeColor("path5233",rawData[i][1].color);
						addToolTip("path5191", "Foot",rawData[i][1].text)
						changeColor("path5191",rawData[i][1].color);	
						addToClickHandlerArrays("path5191",rawData[i][0].text)
						addToClickHandlerArrays("path5233",rawData[i][0].text)
						
						addToolTip("path3516","Foot",rawData[i][1].text)
						changeColor("path3516",rawData[i][1].color);
						addToolTip("path3504","Foot",rawData[i][1].text)
						changeColor("path3504",rawData[i][1].color);
						addToolTip("path3508","Foot",rawData[i][1].text)
						changeColor("path3508",rawData[i][1].color);
						addToolTip("path3444","Foot",rawData[i][1].text)
						changeColor("path3444",rawData[i][1].color);
						addToClickHandlerArrays("path3504",rawData[i][0].text)
						addToClickHandlerArrays("path3516",rawData[i][0].text)
						addToClickHandlerArrays("path3508",rawData[i][0].text)
						addToClickHandlerArrays("path3444",rawData[i][0].text)
						
						//Toe
						
						addToolTip("path3516","Foot",rawData[i][1].text)
						changeColor("path3516",rawData[i][1].color);
						addToolTip("path3504","Foot",rawData[i][1].text)
						changeColor("path3504",rawData[i][1].color);
						addToolTip("path3508","Foot",rawData[i][1].text)
						changeColor("path3508",rawData[i][1].color);
						addToolTip("path3444","Foot",rawData[i][1].text)
						changeColor("path3444",rawData[i][1].color);
						addToClickHandlerArrays("path3504",rawData[i][0].text)
						addToClickHandlerArrays("path3516",rawData[i][0].text)
						addToClickHandlerArrays("path3508",rawData[i][0].text)
						addToClickHandlerArrays("path3444",rawData[i][0].text)
						
						addToolTip('path3532','Foot',rawData[i][1].text);
						changeColor('path3532',rawData[i][1].color);
						addToClickHandlerArrays('path3532',rawData[i][0].text);
						addToolTip('path3526','Foot',rawData[i][1].text);
						changeColor('path3526',rawData[i][1].color);
						addToClickHandlerArrays('path3526',rawData[i][0].text);
						addToolTip('path3524','Foot',rawData[i][1].text);
						changeColor('path3524',rawData[i][1].color);
						addToClickHandlerArrays('path3524',rawData[i][0].text);
						addToolTip('path3482','Foot',rawData[i][1].text);
						changeColor('path3482',rawData[i][1].color);
						addToClickHandlerArrays('path3482',rawData[i][0].text);
						addToolTip('path3504','Foot',rawData[i][1].text);
						changeColor('path3504',rawData[i][1].color);
						addToClickHandlerArrays('path3504',rawData[i][0].text);
						addToolTip('path3516','Foot',rawData[i][1].text);
						changeColor('path3516',rawData[i][1].color);
						addToClickHandlerArrays('path3516',rawData[i][0].text);
						addToolTip('path3454','Foot',rawData[i][1].text);
						changeColor('path3454',rawData[i][1].color);
						addToClickHandlerArrays('path3454',rawData[i][0].text);
						addToolTip('path3462','Foot',rawData[i][1].text);
						changeColor('path3462',rawData[i][1].color);
						addToClickHandlerArrays('path3462',rawData[i][0].text);
						addToolTip('path3508','Foot',rawData[i][1].text);
						changeColor('path3508',rawData[i][1].color);
						addToClickHandlerArrays('path3508',rawData[i][0].text);
						addToolTip('path3490','Foot',rawData[i][1].text);
						changeColor('path3490',rawData[i][1].color);
						addToClickHandlerArrays('path3490',rawData[i][0].text);
						addToolTip('path3478','Foot',rawData[i][1].text);
						changeColor('path3478',rawData[i][1].color);
						addToClickHandlerArrays('path3478',rawData[i][0].text);
						addToolTip('path3406','Foot',rawData[i][1].text);
						changeColor('path3406',rawData[i][1].color);
						addToClickHandlerArrays('path3406',rawData[i][0].text);
						addToolTip('path3416','Foot',rawData[i][1].text);
						changeColor('path3416',rawData[i][1].color);
						addToClickHandlerArrays('path3416',rawData[i][0].text);
						addToolTip('path3432','Foot',rawData[i][1].text);
						changeColor('path3432',rawData[i][1].color);
						addToClickHandlerArrays('path3432',rawData[i][0].text);
						addToolTip('path3444','Foot',rawData[i][1].text);
						changeColor('path3444',rawData[i][1].color);
						addToClickHandlerArrays('path3444',rawData[i][0].text);
						addToolTip('path3438','Foot',rawData[i][1].text);
						changeColor('path3438',rawData[i][1].color);
						addToClickHandlerArrays('path3438',rawData[i][0].text);
						addToolTip('path3424','Foot',rawData[i][1].text);
						changeColor('path3424',rawData[i][1].color);
						addToClickHandlerArrays('path3424',rawData[i][0].text);
						addToolTip('path3372','Foot',rawData[i][1].text);
						changeColor('path3372',rawData[i][1].color);
						addToClickHandlerArrays('path3372',rawData[i][0].text);
						addToolTip('path3374','Foot',rawData[i][1].text);
						changeColor('path3374',rawData[i][1].color);
						addToClickHandlerArrays('path3374',rawData[i][0].text);
						addToolTip('path3378','Foot',rawData[i][1].text);
						changeColor('path3378',rawData[i][1].color);
						addToClickHandlerArrays('path3378',rawData[i][0].text);
						addToolTip('path3380','Foot',rawData[i][1].text);
						changeColor('path3380',rawData[i][1].color);
						addToClickHandlerArrays('path3380',rawData[i][0].text);
						addToolTip('path3390','Foot',rawData[i][1].text);
						changeColor('path3390',rawData[i][1].color);
						addToClickHandlerArrays('path3390',rawData[i][0].text);
						addToolTip('path3384','Foot',rawData[i][1].text);
						changeColor('path3384',rawData[i][1].color);
						addToClickHandlerArrays('path3384',rawData[i][0].text);
						addToolTip('path3396','Foot',rawData[i][1].text);
						changeColor('path3396',rawData[i][1].color);
						addToClickHandlerArrays('path3396',rawData[i][0].text);
						
						addToolTip('path3710','Foot',rawData[i][1].text);
						changeColor('path3710',rawData[i][1].color);
						addToClickHandlerArrays('path3710',rawData[i][0].text);
						addToolTip('path3712','Foot',rawData[i][1].text);
						changeColor('path3712',rawData[i][1].color);
						addToClickHandlerArrays('path3712',rawData[i][0].text);
						addToolTip('path3696','Foot',rawData[i][1].text);
						changeColor('path3696',rawData[i][1].color);
						addToClickHandlerArrays('path3696',rawData[i][0].text);
						addToolTip('path3698','Foot',rawData[i][1].text);
						changeColor('path3698',rawData[i][1].color);
						addToClickHandlerArrays('path3698',rawData[i][0].text);
						addToolTip('path3680','Foot',rawData[i][1].text);
						changeColor('path3680',rawData[i][1].color);
						addToClickHandlerArrays('path3680',rawData[i][0].text);
						addToolTip('path3676','Foot',rawData[i][1].text);
						changeColor('path3676',rawData[i][1].color);
						addToClickHandlerArrays('path3676',rawData[i][0].text);
						addToolTip('path3718','Foot',rawData[i][1].text);
						changeColor('path3718',rawData[i][1].color);
						addToClickHandlerArrays('path3718',rawData[i][0].text);
						addToolTip('path3728','Foot',rawData[i][1].text);
						changeColor('path3728',rawData[i][1].color);
						addToClickHandlerArrays('path3728',rawData[i][0].text);
						addToolTip('path3704','Foot',rawData[i][1].text);
						changeColor('path3704',rawData[i][1].color);
						addToClickHandlerArrays('path3704',rawData[i][0].text);
						addToolTip('path3690','Foot',rawData[i][1].text);
						changeColor('path3690',rawData[i][1].color);
						addToClickHandlerArrays('path3690',rawData[i][0].text);
						addToolTip('path3684','Foot',rawData[i][1].text);
						changeColor('path3684',rawData[i][1].color);
						addToClickHandlerArrays('path3684',rawData[i][0].text);
						addToolTip('path3656','Foot',rawData[i][1].text);
						changeColor('path3656',rawData[i][1].color);
						addToClickHandlerArrays('path3656',rawData[i][0].text);
						addToolTip('path3720','Foot',rawData[i][1].text);
						changeColor('path3720',rawData[i][1].color);
						addToClickHandlerArrays('path3720',rawData[i][0].text);
						addToolTip('path3656','Foot',rawData[i][1].text);
						changeColor('path3656',rawData[i][1].color);
						addToClickHandlerArrays('path3656',rawData[i][0].text);
						addToolTip('path3648','Foot',rawData[i][1].text);
						changeColor('path3648',rawData[i][1].color);
						addToClickHandlerArrays('path3648',rawData[i][0].text);
						addToolTip('path3600','Foot',rawData[i][1].text);
						changeColor('path3600',rawData[i][1].color);
						addToClickHandlerArrays('path3600',rawData[i][0].text);
						addToolTip('path3618','Foot',rawData[i][1].text);
						changeColor('path3618',rawData[i][1].color);
						addToClickHandlerArrays('path3618',rawData[i][0].text);
						addToolTip('path3638','Foot',rawData[i][1].text);
						changeColor('path3638',rawData[i][1].color);
						addToClickHandlerArrays('path3638',rawData[i][0].text);
						addToolTip('path3572','Foot',rawData[i][1].text);
						changeColor('path3572',rawData[i][1].color);
						addToClickHandlerArrays('path3572',rawData[i][0].text);
						addToolTip('path3584','Foot',rawData[i][1].text);
						changeColor('path3584',rawData[i][1].color);
						addToClickHandlerArrays('path3584',rawData[i][0].text);
						addToolTip('path3566','Foot',rawData[i][1].text);
						changeColor('path3566',rawData[i][1].color);
						addToClickHandlerArrays('path3566',rawData[i][0].text);
						addToolTip('path3572','Foot',rawData[i][1].text);
						changeColor('path3572',rawData[i][1].color);
						addToClickHandlerArrays('path3572',rawData[i][0].text);
						addToolTip('path3556','Foot',rawData[i][1].text);
						changeColor('path3556',rawData[i][1].color);
						addToClickHandlerArrays('path3556',rawData[i][0].text);
						
						addToolTip('path3364','Foot',rawData[i][1].text);
						changeColor('path3364',rawData[i][1].color);
						addToClickHandlerArrays('path3364',rawData[i][0].text);
						addToolTip('path3362','Foot',rawData[i][1].text);
						changeColor('path3362',rawData[i][1].color);
						addToClickHandlerArrays('path3362',rawData[i][0].text);
						addToolTip('path3470','Foot',rawData[i][1].text);
						changeColor('path3470',rawData[i][1].color);
						addToClickHandlerArrays('path3470',rawData[i][0].text);
						addToolTip('path3502','Foot',rawData[i][1].text);
						changeColor('path3502',rawData[i][1].color);
						addToClickHandlerArrays('path3502',rawData[i][0].text);
						addToolTip('path3590','Foot',rawData[i][1].text);
						changeColor('path3590',rawData[i][1].color);
						addToClickHandlerArrays('path3590',rawData[i][0].text);
						addToolTip('path3610','Foot',rawData[i][1].text);
						changeColor('path3610',rawData[i][1].color);
						addToClickHandlerArrays('path3610',rawData[i][0].text);
						addToolTip('path3640','Foot',rawData[i][1].text);
						changeColor('path3640',rawData[i][1].color);
						addToClickHandlerArrays('path3640',rawData[i][0].text);
						addToolTip('path3626','Foot',rawData[i][1].text);
						changeColor('path3626',rawData[i][1].color);
						addToClickHandlerArrays('path3626',rawData[i][0].text);
						addToolTip('path3612','Foot',rawData[i][1].text);
						changeColor('path3612',rawData[i][1].color);
						addToClickHandlerArrays('path3612',rawData[i][0].text);
						addToolTip('path3600','Foot',rawData[i][1].text);
						changeColor('path3600',rawData[i][1].color);
						addToClickHandlerArrays('path3600',rawData[i][0].text);
						addToolTip('path3664','Foot',rawData[i][1].text);
						changeColor('path3664',rawData[i][1].color);
						addToClickHandlerArrays('path3664',rawData[i][0].text);
						addToolTip('path3704','Foot',rawData[i][1].text);
						changeColor('path3704',rawData[i][1].color);
						addToClickHandlerArrays('path3704',rawData[i][0].text);
						addToolTip('path3572','Foot',rawData[i][1].text);
						changeColor('path3572',rawData[i][1].color);
						addToClickHandlerArrays('path3572',rawData[i][0].text);
						addToolTip('path3702','Foot',rawData[i][1].text);
						changeColor('path3702',rawData[i][1].color);
						addToClickHandlerArrays('path3702',rawData[i][0].text);
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Shoulder")){
						/*addToolTip("path6239", "Shoulder",rawData[i][1].text)
						changeColor("path6239",rawData[i][1].color);
						addToolTip("path5231", "Shoulder",rawData[i][1].text)
						changeColor("path5231",rawData[i][1].color);	
						addToClickHandlerArrays("path6239",rawData[i][0].text)
						addToClickHandlerArrays("path5231",rawData[i][0].text)*/
						
						//Clavicle
						addToolTip("path4906","Shoulder",rawData[i][1].text)
						changeColor("path4906",rawData[i][1].color);
						addToClickHandlerArrays("path4906",rawData[i][0].text)	
						addToolTip("path4912","Shoulder",rawData[i][1].text)
						changeColor("path4912",rawData[i][1].color);
						addToClickHandlerArrays("path4912",rawData[i][0].text)	
						
						//Scapula right
						addToolTip("path3930","Shoulder",rawData[i][1].text)
						changeColor("path3930",rawData[i][1].color);
						addToClickHandlerArrays("path3930",rawData[i][0].text)	
						addToolTip("path3928","Shoulder",rawData[i][1].text)
						changeColor("path3928",rawData[i][1].color);
						addToClickHandlerArrays("path3928",rawData[i][0].text)	
						addToolTip("path3926","Shoulder",rawData[i][1].text)
						changeColor("path3926",rawData[i][1].color);
						addToClickHandlerArrays("path3926",rawData[i][0].text)	
						addToolTip("path3924","Shoulder",rawData[i][1].text)
						changeColor("path3924",rawData[i][1].color);
						addToClickHandlerArrays("path3924",rawData[i][0].text)
						//Scapula left						
						addToolTip("path3924-9","Shoulder",rawData[i][1].text)
						changeColor("path3924-9",rawData[i][1].color);
						addToClickHandlerArrays("path3924-9",rawData[i][0].text)	
						addToolTip("path3926-2","Shoulder",rawData[i][1].text)
						changeColor("path3926-2",rawData[i][1].color);
						addToClickHandlerArrays("path3926-2",rawData[i][0].text)	
						
						addToolTip("path6277","Shoulder",rawData[i][1].text)
						changeColor("path6277",rawData[i][1].color);
						addToClickHandlerArrays("path6277",rawData[i][0].text)	
						addToolTip("path6281","Shoulder",rawData[i][1].text)
						changeColor("path6281",rawData[i][1].color);
						addToClickHandlerArrays("path6281",rawData[i][0].text)	
						addToolTip("path6283","Shoulder",rawData[i][1].text)
						changeColor("path6283",rawData[i][1].color);
						addToClickHandlerArrays("path6285",rawData[i][0].text)	
						//joint
						addToolTip("path3934","Shoulder",rawData[i][1].text)
						changeColor("path3934",rawData[i][1].color);
						addToClickHandlerArrays("path3934",rawData[i][0].text)	
						addToolTip("path3936","Shoulder",rawData[i][1].text)
						changeColor("path3936",rawData[i][1].color);
						addToClickHandlerArrays("path3936",rawData[i][0].text)
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Head")){
						/*addToolTip("path5211", "Head",rawData[i][1].text)
						changeColor("path5211",rawData[i][1].color);	
						addToClickHandlerArrays("path5211",rawData[i][0].text)	*/
						addToolTip("path4717", "Head",rawData[i][1].text)
						changeColor("path4717",rawData[i][1].color);
						addToClickHandlerArrays("path4717",rawData[i][0].text)
						addToolTip("path4719", "Head",rawData[i][1].text)	
						changeColor("path4719",rawData[i][1].color);	
						addToClickHandlerArrays	("path4719",rawData[i][0].text)	
						//Skull
						addToolTip("path4816", "Head",rawData[i][1].text)
						changeColor("path4816",rawData[i][1].color);
						addToClickHandlerArrays("path4816",rawData[i][0].text)
						
						//Mandible
						addToolTip("path4628", "Head",rawData[i][1].text)
						changeColor("path4628",rawData[i][1].color);	
						addToClickHandlerArrays("path4628",rawData[i][0].text)
					}else if(rawData[i][0].text.equalsIgnoreCase("Pelvis")){
						addToolTip("path3882","Pelvis",rawData[i][1].text)
						changeColor("path3882",rawData[i][1].color);
						addToClickHandlerArrays("path3882",rawData[i][0].text)	
						
						addToolTip("path3890","Pelvis",rawData[i][1].text)
						changeColor("path3890",rawData[i][1].color);
						addToClickHandlerArrays("path3890",rawData[i][0].text)	
						addToolTip("path3892","Pelvis",rawData[i][1].text)
						changeColor("path3892",rawData[i][1].color);
						addToClickHandlerArrays("path3892",rawData[i][0].text)	
						addToolTip("path3894","Pelvis",rawData[i][1].text)
						changeColor("path3894",rawData[i][1].color);
						addToClickHandlerArrays("path3894",rawData[i][0].text)	
						addToolTip("path3896","Pelvis",rawData[i][1].text)
						changeColor("path3896",rawData[i][1].color);
						addToClickHandlerArrays("path3896",rawData[i][0].text)	
						addToolTip("path3898","Pelvis",rawData[i][1].text)
						changeColor("path3898",rawData[i][1].color);
						addToClickHandlerArrays("path3898",rawData[i][0].text)	
						addToolTip("path3900","Pelvis",rawData[i][1].text)
						changeColor("path3900",rawData[i][1].color);
						addToClickHandlerArrays("path3900",rawData[i][0].text)
						addToolTip("path3900","Pelvis",rawData[i][1].text)
						changeColor("path3900",rawData[i][1].color);
						addToClickHandlerArrays("path3900",rawData[i][0].text)
						addToolTip("path3814","Pelvis",rawData[i][1].text)
						changeColor("path3814",rawData[i][1].color);
						addToClickHandlerArrays("path3814",rawData[i][0].text)
						addToolTip("path3816","Pelvis",rawData[i][1].text)
						changeColor("path3816",rawData[i][1].color);
						addToClickHandlerArrays("path3816",rawData[i][0].text)
						addToolTip("path3818","Pelvis",rawData[i][1].text)
						changeColor("path3818",rawData[i][1].color);
						addToClickHandlerArrays("path3818",rawData[i][0].text)
						addToolTip("path3826","Pelvis",rawData[i][1].text)
						changeColor("path3826",rawData[i][1].color);
						addToClickHandlerArrays("path3826",rawData[i][0].text)
						addToolTip("path3824","Pelvis",rawData[i][1].text)
						changeColor("path3824",rawData[i][1].color);
						addToClickHandlerArrays("path3824",rawData[i][0].text)
						addToolTip("path3846","Pelvis",rawData[i][1].text)
						changeColor("path3846",rawData[i][1].color);
						addToClickHandlerArrays("path3846",rawData[i][0].text)
						addToolTip("path3864","Pelvis",rawData[i][1].text)
						changeColor("path3864",rawData[i][1].color);
						addToClickHandlerArrays("path3864",rawData[i][0].text)
						//coccyx
						addToolTip("path3944","Pelvis",rawData[i][1].text)
						changeColor("path3944",rawData[i][1].color);
						addToClickHandlerArrays("path3944",rawData[i][0].text)	
						//sacrum
						addToolTip("path3958","Pelvis",rawData[i][1].text)
						changeColor("path3958",rawData[i][1].color);
						addToClickHandlerArrays("path3958",rawData[i][0].text)	

					}else if(rawData[i][0].text.equalsIgnoreCase("Humerus")){
						addToolTip("path4924","Humerus",rawData[i][1].text)
						changeColor("path4924",rawData[i][1].color);
						addToClickHandlerArrays("path4924",rawData[i][0].text)		
						addToolTip("path4984","Humerus",rawData[i][1].text)
						changeColor("path4984",rawData[i][1].color);
						addToClickHandlerArrays("path4984",rawData[i][0].text)										
					}else if(rawData[i][0].text.equalsIgnoreCase("Tib Fib")){

						//bottom bones
						addToolTip('path5622','Tib Fib',rawData[i][1].text);
						changeColor('path5622',rawData[i][1].color);
						addToClickHandlerArrays('path5622',rawData[i][0].text);
						addToolTip('path5632','Tib Fib',rawData[i][1].text);
						changeColor('path5632',rawData[i][1].color);
						addToClickHandlerArrays('path5632',rawData[i][0].text);
						addToolTip('path5634','Tib Fib',rawData[i][1].text);
						changeColor('path5634',rawData[i][1].color);
						addToClickHandlerArrays('path5634',rawData[i][0].text);
						addToolTip('path5646','Tib Fib',rawData[i][1].text);
						changeColor('path5646',rawData[i][1].color);
						addToClickHandlerArrays('path5646',rawData[i][0].text);
						addToolTip('path3796','Tib Fib',rawData[i][1].text);
						changeColor('path3796',rawData[i][1].color);
						addToClickHandlerArrays('path3796',rawData[i][0].text);
						addToolTip('path3786','Tib Fib',rawData[i][1].text);
						changeColor('path3786',rawData[i][1].color);
						addToClickHandlerArrays('path3786',rawData[i][0].text);
						addToolTip('path3798','Tib Fib',rawData[i][1].text);
						changeColor('path3798',rawData[i][1].color);
						addToClickHandlerArrays('path3798',rawData[i][0].text);
						addToolTip('path3790','Tib Fib',rawData[i][1].text);
						changeColor('path3790',rawData[i][1].color);
						addToClickHandlerArrays('path3790',rawData[i][0].text);
						addToolTip('path3792','Tib Fib',rawData[i][1].text);
						changeColor('path3792',rawData[i][1].color);
						addToClickHandlerArrays('path3792',rawData[i][0].text);
						addToolTip('path3810','Tib Fib',rawData[i][1].text);
						changeColor('path3810',rawData[i][1].color);
						addToClickHandlerArrays('path3810',rawData[i][0].text);
						addToolTip('path3804','Tib Fib',rawData[i][1].text);
						changeColor('path3804',rawData[i][1].color);
						addToClickHandlerArrays('path3804',rawData[i][0].text);
						addToolTip('path3800','Tib Fib',rawData[i][1].text);
						changeColor('path3800',rawData[i][1].color);
						addToClickHandlerArrays('path3800',rawData[i][0].text);
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Spine")){
						addToolTip("path4014","Spine",rawData[i][1].text)
						changeColor("path4014",rawData[i][1].color);
						addToClickHandlerArrays("path4014",rawData[i][0].text)
						addToolTip("path4016","Spine",rawData[i][1].text)
						changeColor("path4016",rawData[i][1].color);
						addToClickHandlerArrays("path4016",rawData[i][0].text)
						addToolTip("path4018","Spine",rawData[i][1].text)
						changeColor("path4018",rawData[i][1].color);
						addToClickHandlerArrays("path4018",rawData[i][0].text)
						addToolTip("path4020","Spine",rawData[i][1].text)
						changeColor("path4020",rawData[i][1].color);
						addToClickHandlerArrays("path4020",rawData[i][0].text)
						addToolTip("path4010","Spine",rawData[i][1].text)
						changeColor("path4010",rawData[i][1].color);
						addToClickHandlerArrays("path4010",rawData[i][0].text)
						addToolTip("path4042","Spine",rawData[i][1].text)
						changeColor("path4042",rawData[i][1].color);
						addToClickHandlerArrays("path4042",rawData[i][0].text)	
						addToolTip("path4066","Spine",rawData[i][1].text)
						changeColor("path4066",rawData[i][1].color);
						addToClickHandlerArrays("path4066",rawData[i][0].text)
						addToolTip("path4122","Spine",rawData[i][1].text)
						changeColor("path4122",rawData[i][1].color);
						addToClickHandlerArrays("path4122",rawData[i][0].text)
						addToolTip("path4152","Spine",rawData[i][1].text)
						changeColor("path4152",rawData[i][1].color);
						addToClickHandlerArrays("path4152",rawData[i][0].text)
						addToolTip("path4186","Spine",rawData[i][1].text)
						changeColor("path4186",rawData[i][1].color);
						addToClickHandlerArrays("path4186",rawData[i][0].text)
						addToolTip("path4094","Spine",rawData[i][1].text)
						changeColor("path4094",rawData[i][1].color);
						addToClickHandlerArrays("path4094",rawData[i][0].text)
						addToolTip("path4592","Spine",rawData[i][1].text)
						changeColor("path4592",rawData[i][1].color);
						addToClickHandlerArrays("path4592",rawData[i][0].text)
						addToolTip("path4572","Spine",rawData[i][1].text)
						changeColor("path4572",rawData[i][1].color);
						addToClickHandlerArrays("path4572",rawData[i][0].text)
						addToolTip("path4500","Spine",rawData[i][1].text)
						changeColor("path4500",rawData[i][1].color);
						addToClickHandlerArrays("path4500",rawData[i][0].text)
						addToolTip("path4526","Spine",rawData[i][1].text)
						changeColor("path4526",rawData[i][1].color);
						addToClickHandlerArrays("path4526",rawData[i][0].text)
						addToolTip("path4168","Spine",rawData[i][1].text)
						changeColor("path4168",rawData[i][1].color);
						addToClickHandlerArrays("path4168",rawData[i][0].text)
						addToolTip("path4086","Spine",rawData[i][1].text)
						changeColor("path4086",rawData[i][1].color);
						addToClickHandlerArrays("path4086",rawData[i][0].text)
						addToolTip("path4088","Spine",rawData[i][1].text)
						changeColor("path4088",rawData[i][1].color);
						addToClickHandlerArrays("path4088",rawData[i][0].text)
						addToolTip("path4000","Spine",rawData[i][1].text)				
						changeColor("path4000",rawData[i][1].color);
						addToClickHandlerArrays("path4000",rawData[i][0].text)
						addToolTip("path4616","Spine",rawData[i][1].text)
						changeColor("path4616",rawData[i][1].color);
						addToClickHandlerArrays("path4616",rawData[i][0].text)
						addToolTip("path4548","Spine",rawData[i][1].text)
						changeColor("path4548",rawData[i][1].color);
						addToClickHandlerArrays("path4548",rawData[i][0].text)	
					}else if(rawData[i][0].text.equalsIgnoreCase("Forearm")){
						//right
						addToolTip("path5024","Forearm",rawData[i][1].text)
						changeColor("path5024",rawData[i][1].color);
						addToClickHandlerArrays("path5024",rawData[i][0].text)	
						addToolTip("path5040","Forearm",rawData[i][1].text)
						changeColor("path5040",rawData[i][1].color);
						addToClickHandlerArrays("path5040",rawData[i][0].text)	
						addToolTip("path5026","Forearm",rawData[i][1].text)
						changeColor("path5026",rawData[i][1].color);
						addToClickHandlerArrays("path5026",rawData[i][0].text)
						//left						
						addToolTip("path4962","Forearm",rawData[i][1].text)
						changeColor("path4962",rawData[i][1].color);
						addToClickHandlerArrays("path4962",rawData[i][0].text)	
						addToolTip("path4950","Forearm",rawData[i][1].text)
						changeColor("path4950",rawData[i][1].color);
						addToClickHandlerArrays("path4950",rawData[i][0].text)	
						addToolTip("path4966","Forearm",rawData[i][1].text)
						changeColor("path4966",rawData[i][1].color);
						addToClickHandlerArrays("path4966",rawData[i][0].text)	
					}else if(rawData[i][0].text.equalsIgnoreCase("Knee")){
						addToolTip("path5650","Knee",rawData[i][1].text)
						changeColor("path5650",rawData[i][1].color);
						addToClickHandlerArrays("path5650",rawData[i][0].text)	
						addToolTip("path5658","Knee",rawData[i][1].text)
						changeColor("path5658",rawData[i][1].color);
						addToClickHandlerArrays("path5658",rawData[i][0].text)	
						addToolTip("path5652","Knee",rawData[i][1].text)
						changeColor("path5652",rawData[i][1].color);
						addToClickHandlerArrays("path5652",rawData[i][0].text)
						//left						
						addToolTip("path5654","Knee",rawData[i][1].text)
						changeColor("path5654",rawData[i][1].color);
						addToClickHandlerArrays("path5654",rawData[i][0].text)	
						addToolTip("path5662","Knee",rawData[i][1].text)
						changeColor("path5662",rawData[i][1].color);
						addToClickHandlerArrays("path5662",rawData[i][0].text)	
						addToolTip("path5660","Knee",rawData[i][1].text)
						changeColor("path5660",rawData[i][1].color);
						addToClickHandlerArrays("path5660",rawData[i][0].text)	
						addToolTip("path3878","Knee",rawData[i][1].text)
						changeColor("path3878",rawData[i][1].color);
						addToClickHandlerArrays("path3878",rawData[i][0].text)
						addToolTip("path3844","Knee",rawData[i][1].text)
						changeColor("path3844",rawData[i][1].color);
						addToClickHandlerArrays("path3844",rawData[i][0].text)
					}
				}
				pathIDs.forEach(function(path,index){
					//after doing 'clear selection' we need to remove the opacity set. 
					var pathId = path.substr(1,path.length-1);
					var obj = document.getElementById(pathId);
					if(obj)
						obj.style.opacity="1"; 
				});
			}
		
				
				//TODO Fade non selected body portions if anatomy is filtered
				for (i = 0; i < pathIDs.length; i++) 
				{
					//Remove all old handlers
					$(pathIDs[i]).unbind('click');
					
					// Add the handler
					$(pathIDs[i]).click({"anatomy":anatomies[i]},function(event){
				
							prism.activeDashboard.filters.update({
								"jaql": {
								  "table": results.metadata[0].jaql.table,
								  "column": results.metadata[0].jaql.column,
								  "dim": results.metadata[0].jaql.dim,
								  "datatype": results.metadata[0].jaql.table.datatype,
								  "merged": results.metadata[0].jaql.merged,
								  "title": results.metadata[0].jaql.title,
								  "filter": {
										explicit: true,
										members: [event.data.anatomy],
										multiSelection: true
								  },
								  "collapsed": true
								}
							});
						 
						//  Refresh the dashboard
						prism.activeDashboard.refresh();
						//To-Do
						/*Each anatomy has multiple paths. So when I click a anatomy, we get only clicked path in event callback .
							We need to identify all other paths associated with that anatomy and highlight*/
						var filter = widget.dashboard.filters.item(widget.metadata.panels[0].items[0].jaql.dim);
						// then check if the filter is set to include all or not
						if (filter && !filter.jaql.filter.all){
							// set the widget selector object to true and update the manifest with the selected dim name
							widget.options.selector = true;
							widget.manifest.data.selection[0] = widget.metadata.panels[0].name;

							var selectedAnatomyId = event.currentTarget.id;
							
							if(widget.options.dashboardFiltersMode=="select"){ //highlight/select is the filter mode selected
								pathIDs.forEach(function(path,index){
									var pathId = path.substr(1,path.length-1); //path value is in the format #path3347. need to remove # and extract only id
									var pathObject = document.getElementById(pathId);
									if(pathId!=selectedAnatomyId){	
										if(pathObject)
											pathObject.style.opacity='0.1'; //add opacity to other anatomies 
									}else{
										if(pathObject){
											document.getElementById(pathId).style.opacity = '1';
											document.getElementById(pathId).style.fill=pathHighlightColors[index]; //highlight clicked anatomy
										}
									}
								});
							}else if(widget.options.dashboardFiltersMode=="filter"){ //slice/filter is the selected filter mode selected
								pathIDs.forEach(function(path,index){ 
									var pathId = path.substr(1,path.length-1); //path value is in the format #path3347. need to remove # and extract only id
									var pathObject = document.getElementById(pathId);
									if(pathId!=selectedAnatomyId){
										if(pathObject)	
											document.getElementById(pathId).style.fill="#e9e9e9" //#e9e9e9"; //grey out other anatomies 
									}else{
										if(pathObject)
											document.getElementById(pathId).style.fill=pathHighlightColors[index]; //highlight clicked anatomy
									}
								});
							}							
						}
						else {
							widget.options.selector = false;
							widget.manifest.data.selection = [];
						}
						// save the widget state and refresh
							widget.changesMade();
							widget.refresh();
						});
				}				
		},
		
		destroy : function (widget, e) {
		}
	});
}])
