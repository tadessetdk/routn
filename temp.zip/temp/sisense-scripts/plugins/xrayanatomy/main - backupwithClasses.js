prism.run(["ux-controls.services.$dom","$compile",
function($dom,$compile){
	prism.registerWidget("xrayanatomy", 
	{

		name : "xrayanatomy",
		family : "xrayanatomy",
		title : "X-ray Diagram",
		iconSmall : "/plugins/xrayanatomy/widget-24.png",
		styleEditorTemplate : "",
		style : {},
		hideNoResults:false,
		// sizing must be stated
		sizing: {

			minHeight: 128, //header
			maxHeight: 2048,
			minWidth: 128,
			maxWidth: 2048,
			height: 640,
			defaultWidth: 512
		},
		options: {
			dashboardFiltersMode: "select",
			selector: true
		},
		directive:{
			desktop: "xrayanatomy" // name of the folder 
		},
		data : {

			selection : ['organs'],
			defaultQueryResult : {},

			panels : [
				//dimension panel
				{
					name : 'organs',
					type : 'visible',
					metadata : {

						types : ['dimensions'],
						maxitems : 1
					}
				},
				{//measure panel
					name : 'value', //must match canColor Funciton
					type : 'visible',
					itemAttributes: ["color"],
					allowedColoringTypes: function() {
					return  {
						color: true,
						condition: true,
						range: true
					};
				},
				metadata: {
					types: ['measures'],
					maxitems: 1
				},
				itemAdded: function(widget, item) {
					var colorFormatType = $$get(item, "format.color.type");
					if ("color" === colorFormatType || "color" === colorFormatType) {
						var color = item.format.color.color;
						defined(color) && "transparent" != color && "white" != color && "#fff" != color && "#ffffff" != color || $jaql.resetColor(item)
					}
					"range" === colorFormatType && $jaql.resetColor(item), defined(item, "format.color_bkp") && $jaql.resetColor(item), defined(item, "format.members") && delete item.format.members
				}
			},
				{
					name: 'filters',
					type: 'filters',
					metadata: {

						types: ['dimensions'],
						maxitems: -1
					}
				}
			],
			
			canColor: function (widget, panel, item) {			
            return panel.name === "value" ; // must match what needs to be colored 
        },

			allocatePanel : function (widget, metadataItem) {
				// measure
				if (prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("value").items.length === 0) {

					return "value";
				}

				// item
				else if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("organs").items.length < 3) {

					return "items";
				}
			},

			// returns true/ reason why the given item configuration is not/supported by the widget
			isSupported : function (items) {

				return this.rankMetadata(items, null, null) > -1;
			},

			// ranks the compatibility of the given metadata items with the widget
			rankMetadata : function (items, type, subtype) {

				var a = prism.$jaql.analyze(items);

				// require at least 2 dimensions of lat and lng and 1 measure
				if (a.dimensions.length >= 2 && a.measures.length == 1) {

					return 0;
				}
				return -1;
			},

			// populates the metadata items to the widget
			populateMetadata : function (widget, items) {
				debugger;
				var a = prism.$jaql.analyze(items);

				// allocating dimensions
				widget.metadata.panel("organs").push(a.dimensions);
				widget.metadata.panel("value").push(a.measures);
				widget.metadata.panel("filters").push(a.filters);
			},

			// builds a jaql query from the given widget
			buildQuery : function (widget) {
				
				// building jaql query object from widget metadata
				var query = {
					datasource : widget.datasource,
					metadata : []
				};

				// pushing items
				widget.metadata.panel("organs").items.forEach(function (item) {
					query.metadata.push(item);
				});

				// pushing data
				query.metadata.push(widget.metadata.panel("value").items[0]);
				//console.log("The check item[0] " + widget.metadata.panel("value").items[0]);

				// series - dimensions
				widget.metadata.panel('filters').items.forEach(function (item) {

					item = $$.object.clone(item, true);
					item.panel = "scope";

					query.metadata.push(item);
				});

				return query;
			},

			// prepares the widget-specific query result from the given result data-table
			processResult : function (widget, queryResult) {
				return queryResult;
			}
		},
		
		render : function (widget, e) 
		{
			debugger;

			/** variable declaration **/
			// widget element
			var $lmnt = $(e.element);
			//$lmnt.empty();
			//$lmnt.remove();
				
			var results = widget.rawQueryResult,
				rawData = widget.queryResult.$$rows,
				headers = widget.rawQueryResult.headers,
				i;

			var width = $lmnt.width(),
				height = $lmnt.height();
			
			// Prepare the container div
			/*var MyDiv = $('<xrayanatomy class="widget-body"></xrayanatomy>');
				ObjectID = widget.oid,
				DivName = "xrayanatomy-" + ObjectID;*/
				
			var MyDiv = $lmnt[0],
				ObjectID = widget.oid,
				DivName = "xrayanatomy-" + ObjectID;
			//<xrayanatomy class="widget-body" data-ng-class="{error:widget.$error, 'no-results-widget-body':!widget.manifest.hideNoResults &amp;&amp; widget.$noResults}"></xrayanatomy>
			var pathIDs = [];
			var anatomies = [];
			var pathHighlightColors = [];

			if (!defined(MyDiv)){
				return;
			}
			
			MyDiv.setAttribute("id",DivName);
			MyDiv.setAttribute("style","width: 99%; height: 99%; margin: 0 auto");	
			/*var svgTemplate = '<div id="svgContent" ng-include="\'/plugins/xrayanatomy/views/XRayDiagram.html\'"></div></div>';
			$(MyDiv).append(svgTemplate);
			var svgContent = document.getElementById("svgContent");
			var local_scope = angular.element(svgContent).scope();
			var compiledSVGTemplate = $compile(svgContent)(prism.$ngscope);
			MyDiv.append(compiledSVGTemplate[0]);
			prism.$ngscope.$apply();*/
			/*MyDiv[0].setAttribute("id",DivName);
			MyDiv[0].setAttribute("style","width: 99%; height: 99%; margin: 0 auto");	
			var svgTemplate = '<div><div ng-include="\'/plugins/xrayanatomy/views/XRayDiagram.html\'"></div></div>';
			var compiledSVGTemplate = $compile(svgTemplate)(prism.$ngscope);
			MyDiv[0].append(compiledSVGTemplate[0]);*/
			
			//prism.$ngscope.$apply();*/
			
			function addToolTip(organ, value){ //function to add Tool Tip
				var anatomy = '';
				if(organ=='TibFib')
					anatomy = 'Tib Fib';
				else
					anatomy = organ;
				var settings = {
						template:"<div> " + anatomy + " - " + value + " </div>",
						scope: prism.$ngscope
					},
					ui = {
						placement: {
							place: 'r',
							anchor: 't'
						},
						initialShowDelay: 100,
						betweenShowDelay: 100
					};
				//
				var tip = $dom.tip(settings,ui);
				$("." + organ, $lmnt).hover(function(ev){
						//console.log("in");

						tip.activate({
							x: ev.clientX,
							y: ev.clientY,
							space: 10
						});
					},
					function(){
						tip.deactivate();
						//console.log("out")
					});

				//TODO - Double check you're not making multiple tooltip handlers
				$("." + organ, $lmnt).on("contextmenu", function(ev){
					ev.preventDefault();
					ev.stopPropagation();


				})
			}
			
			function changeColor(anatomy, value){
				//alert("Acknowledge to modify object color.");
				if(value!="#828487" && value!="#056083"){ //check if grey  //old value - #6a6a6a
					var paths = document.getElementsByClassName(anatomy);
					for(var i = 0; i<paths.length ; i++){
						paths[i].style.fill = value;	
					}
					pathHighlightColors.push(value);
				}
			}
			
			function addToClickHandlerArrays(anatomy)
			{
				
				//TODO - Don't double add these items
				pathIDs.push("."+anatomy);//this is what I am going to click
				if(anatomy=='TibFib')
					anatomies.push('Tib Fib');// this is what I am going to filter
				anatomies.push(anatomy);
			}
			
			var filter = widget.dashboard.filters.item(widget.metadata.panels[0].items[0].jaql.dim);
			if (filter && filter.jaql.filter.all){  //when a anatomy is selected/filtered render is fired again which resets all highlighting/transparency added 
				for(i = 0; i< rawData.length; i++){ //Below code to color anatomies need to be called when there is no selection/filtering of anatomy in the diagram. 
					if(rawData[i][0].text.equalsIgnoreCase("Abdomen")){
						addToolTip("Abdomen",rawData[i][1].text)
						changeColor("Abdomen",rawData[i][1].color);
						addToClickHandlerArrays("Abdomen");
					}else if(rawData[i][0].text.equalsIgnoreCase("Humerus")){
						addToolTip("Humerus",rawData[i][1].text)
						changeColor("Humerus",rawData[i][1].color);
						addToClickHandlerArrays(rawData[i][0].text)
					}else if(rawData[i][0].text.equalsIgnoreCase("Head")){
						addToolTip("Head",rawData[i][1].text)
						changeColor("Head",rawData[i][1].color);
						addToClickHandlerArrays("Head")
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Shoulder")){
						addToolTip("Shoulder",rawData[i][1].text)
						changeColor("Shoulder",rawData[i][1].color);
						addToClickHandlerArrays("Shoulder");
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Chest")){
						addToolTip("Chest",rawData[i][1].text)
						changeColor("Chest",rawData[i][1].color);
						addToClickHandlerArrays("Chest")
					}else if(rawData[i][0].text.equalsIgnoreCase("Forearm")){
						addToolTip("Forearm",rawData[i][1].text)
						changeColor("Forearm",rawData[i][1].color);
						addToClickHandlerArrays("Forearm")
					}else if(rawData[i][0].text.equalsIgnoreCase("Pelvis")){
						addToolTip("Pelvis",rawData[i][1].text)
						changeColor("Pelvis",rawData[i][1].color);
						addToClickHandlerArrays("Pelvis")
					}else if(rawData[i][0].text.equalsIgnoreCase("Knee")){
						addToolTip("Knee",rawData[i][1].text)
						changeColor("Knee",rawData[i][1].color);
						addToClickHandlerArrays("Knee")
					}else if(rawData[i][0].text.equalsIgnoreCase("Femur")){
						addToolTip("Femur",rawData[i][1].text)
						changeColor("Femur",rawData[i][1].color);
						addToClickHandlerArrays("Femur")
					}else if(rawData[i][0].text.equalsIgnoreCase("Spine")){
						addToolTip("Spine",rawData[i][1].text)
						changeColor("Spine",rawData[i][1].color);
						addToClickHandlerArrays("Spine");
					}
					else if(rawData[i][0].text.equalsIgnoreCase("Hand")){
						addToolTip("Hand",rawData[i][1].text)
						changeColor("Hand",rawData[i][1].color);
						addToClickHandlerArrays("Hand")
					}else if(rawData[i][0].text.equalsIgnoreCase("Tib Fib")){
						addToolTip("TibFib",rawData[i][1].text)
						changeColor("TibFib",rawData[i][1].color);
						addToClickHandlerArrays("TibFib");
					}else if(rawData[i][0].text.equalsIgnoreCase("Foot")){
						addToolTip("Foot",rawData[i][1].text)
						changeColor("Foot",rawData[i][1].color);
						addToClickHandlerArrays("Foot")
					}
					
				}
				pathIDs.forEach(function(path,index){
					//after doing 'clear selection' we need to remove the opacity set. 

					$(path).css('opacity','1');
					if(path=='.Tib Fib')
						$('.Tib.Fib').css('opacity','1');
				});
			}
		
				
				//TODO Fade non selected body portions if anatomy is filtered
				for (i = 0; i < pathIDs.length; i++) 
				{
					//Remove all old handlers
					$(pathIDs[i]).unbind('click');
					
					// Add the handler
					$(pathIDs[i]).click({"anatomy":anatomies[i]},function(event){
				
							prism.activeDashboard.filters.update({
								"jaql": {
								  "table": results.metadata[0].jaql.table,
								  "column": results.metadata[0].jaql.column,
								  "dim": results.metadata[0].jaql.dim,
								  "datatype": results.metadata[0].jaql.table.datatype,
								  "merged": results.metadata[0].jaql.merged,
								  "title": results.metadata[0].jaql.title,
								  "filter": {
										explicit: true,
										members: [event.data.anatomy],
										multiSelection: true
								  },
								  "collapsed": true
								}
							});
						 
						//  Refresh the dashboard
						prism.activeDashboard.refresh();
						//To-Do
						/*Each anatomy has multiple paths. So when I click a anatomy, we get only clicked path in event callback .
							We need to identify all other paths associated with that anatomy and highlight*/
						var filter = widget.dashboard.filters.item(widget.metadata.panels[0].items[0].jaql.dim);
						// then check if the filter is set to include all or not
						if (filter && !filter.jaql.filter.all){
							// set the widget selector object to true and update the manifest with the selected dim name
							widget.options.selector = true;
							widget.manifest.data.selection[0] = widget.metadata.panels[0].name;

							var selectedAnatomyClass= event.currentTarget.className.baseVal //getting the clicked anatomy class name
							
							if(widget.options.dashboardFiltersMode=="select"){ //highlight/select is the filter mode selected
								pathIDs.forEach(function(path,index){
									var pathClass = path.substr(1,path.length-1); //path value is in the format #path3347. need to remove # and extract only id
									if(pathClass!=selectedAnatomyClass){	
										$(path).css('opacity','0.1'); //add opacity to other anatomies 
										if(path=='.Tib Fib')
											$('.Tib.Fib').css('opacity','0.1');
									}else{
										$(path).css('opacity','1');
										$(path).css('fill',pathHighlightColors[index]);
										if(path=='.Tib Fib'){
											$('.Tib.Fib').css('opacity','1');
											$('.Tib.Fib').css('fill',pathHighlightColors[index]);
										}
									}
								});
									
							}
							else if(widget.options.dashboardFiltersMode=="filter"){ //slice/filter is the selected filter mode selected
								pathIDs.forEach(function(path,index){ 
									var pathClass = path.substr(1,path.length-1); //path value is in the format #path3347. need to remove # and extract only id
									if(pathClass!=selectedAnatomyClass){
										$(path).css('fill','#e9e9e9'); //add opacity to other anatomies
										if(path=='.Tib Fib'){
											$('.Tib.Fib').css('fill','#e9e9e9');
										}
									}else{
										$(path).css('fill',pathHighlightColors[index]); //highlight clicked anatomy
										if(path=='.Tib Fib'){
											$('.Tib.Fib').css('fill',pathHighlightColors[index]);
										}
									}
								});
							}							
						}
						else {
							widget.options.selector = false;
							widget.manifest.data.selection = [];
						}
						// save the widget state and refresh
							widget.changesMade();
							widget.refresh();
						});
				}				
		},
		
		destroy : function (widget, e) {
		}
	});
}])
