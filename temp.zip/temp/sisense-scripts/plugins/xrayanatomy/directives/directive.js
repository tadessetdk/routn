/**
 * Created by avi.tavdi on 9/8/2016.
 */
mod.directive('xrayanatomy', [
	'$timeout',
    'ux-controls.services.$dom',
    function () {
        return {
            transclude: false,
            restrict: 'E',
			templateUrl:'/plugins/xrayanatomy/views/XRayDiagram.html',
            link: function link(scope, lmnt, attrs) {
				console.log("link fired");
				/*scope.contentUrl = '/plugins/xrayanatomy/views/XRayDiagram.html';
				scope.dashboard.on('filterschanged',function(){
					scope.contentUrl = '/plugins/xrayanatomy/views/XRayDiagram.html';
					console.log("filterschanged");
				});
				scope.getContentURL = function(){
					return scope.contentUrl;
				}*/
            },
			//template : '<div ng-include="contentUrl"></div>'
        };
    }]);