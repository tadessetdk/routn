const reporter = require('./reporters/htmlReporter')

module.exports = {
      reporter: reporter.generate.bind(null, __dirname + '/reports/report.html')
}