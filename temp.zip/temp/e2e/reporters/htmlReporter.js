const fs = require('fs')
const path = require('path')
const htmlencode = require('htmlencode')

const space = '&nbsp;';

function getReportHtml(packages){
      let metrics = { tests: 0, passed: 0, failed: 0, skipped: 0, time: 0 }
      const contentHtml = getContentHtml(packages, metrics)
      metrics.tests = metrics.passed + metrics.failed + metrics.skipped

      const html = getHeaderHtml(metrics) + contentHtml
      return `<html><body><table width="100%" border="0" cellpadding="10" cellspacing="0"><tr><td>${html}</td></tr></table></body></html>`
}

function getHeaderHtml(metrics){
      return  `<h2>E2E Test Results</h2>
            <table width="100%" bgcolor="${metrics.failed && '#f46541' || 'lightblue'}" border="0" cellpadding="0" cellspacing="0"><tr><td>
                  <table border="0" cellpadding="16" cellspacing="0">
                        <tr>
                              <td><strong>Overall result</strong></td>
                              <td>Tests:${space}<strong>${metrics.tests}</strong></td>
                              <td>Passed:${space}<strong>${metrics.passed}</strong></td>
                              <td>Failed:${space}<strong>${metrics.failed}</strong></td>
                              <td>Skipped:${space}<strong>${metrics.skipped}</strong></td>
                              <td>Time:${space}<strong>${Math.round(metrics.time*100)/100} sec</strong></td>
                              <td>&nbsp;</td>
                        </tr>
                  </table>
            </td></tr></table>`
}

function getSuiteName(name){
      let pathSeparator = (name.indexOf('/') === -1 && '\\') || '/';
      let suiteName = name.replace(`tests${pathSeparator}`, '').replace('.e2e-spec', '')
      return suiteName.split(pathSeparator).map(p=> toSentenceCase(p)).join(' | ')
}

function getContentHtml(package, metrics){
      const suites = package.modules;
      let html = '';
      let testsCount = 0;
      let failedTestsCount = 0;
     
      for(let k in suites){
            const suite = suites[k];
            metrics.passed += suite.tests;
            metrics.failed += suite.failures;
            metrics.skipped += suite.skipped.length;
            metrics.time += parseFloat(suite.time);

            const color =  suite.failures && '#f46541' || '#28b745';
            html += `<h4></h4>
            <table width="100%" bgcolor="${color}" border="0" cellpadding="0" cellspacing="0"><tr><td>
                  <table border="0" cellpadding="8" cellspacing="0"><tr><td><font size="5">${getSuiteName(k)}</font></td><td>&nbsp;</td></tr></table>
            </td></tr></table>
            <table border="0" cellpadding="10" cellspacing="0">
                  <tr>
                        <td>Tests:${space}<strong>${suite.tests}</strong></td>
                        <td>Failed:${space}<strong>${suite.failures}</strong></td>
                        <td>Skipped:${space}<strong>${suite.skipped.length}</strong></td>
                        <td>Time:${space}<strong>${suite.time} sec</strong></td>
                  </tr>
            </table>
            <table cellpadding="8" cellspacing="0" border="1" borderColor="#CCC">
                  <tr bgcolor="#DDD">
                        <th>Status</th>
                        <th>Test</th>
                        <th>Time</th>
                        <th>Assertions</th>
                  </tr>
                  ${getTestCasesHtml(suite.completed)}
            </table>`
      }

      return html;
}

function toSentenceCase(str){
      return str[0].toUpperCase() + str.slice(1)
}

function getTestCasesHtml(testCases) {
      let html = '';

      for(let k in testCases){
            const test = testCases[k];
            const color = test.failed && '#dd1c1c' || '#28b745';
            html += `<tr>
                  <td><font size="4" color="${color}">${test.failed && 'Fail' || 'Success'}</font></td>
                  <td><strong>${toSentenceCase(k)}</strong></td>
                  <td><strong>${test.time}s</strong></td>
                  <td width="60%">${getAssertionsHtml(test.assertions)}</td>
            </tr>`
      }

      return html;
}

function getAssertionsHtml(assertions){
      return assertions.map((a, i)=> {
            const separator = (i && '<hr size="1" color="#DDD"/>') || '';
            const color = a.failure && 'color="#dd1c1c"' || '';
            return `${separator}
                  <font ${color}>
                        <div>${htmlencode.htmlEncode(a.message)}</div>
                  </font>
                  <font size="2" ${color}>
                        <div>${htmlencode.htmlEncode(a.stackTrace)}</div>
                  </font>`
      }).join('')
}

module.exports = {
      generate : function(reportFilePath, results, done) {
            fs.writeFileSync(reportFilePath, getReportHtml(results), { flag: 'w' })
            done()
      }
}