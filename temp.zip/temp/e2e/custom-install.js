const exec = require('child_process').exec;
(process.env.NIGHTWATCH_ENV !== 'win32') && 
(exec('npm install chromedriver@2.29.0', (error, stdout, stderr)=> {
      stdout && console.log(stdout);
      stderr && console.log(stderr);
}))
