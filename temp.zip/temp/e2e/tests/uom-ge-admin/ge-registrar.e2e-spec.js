const testUtils = require('../test-utils')
const testData = require('./uom-ge-admin-test-data')

module.exports = {

  'login into app': client=> {
    client.useCss();

    client
      .url(testUtils.getUrl(client, testData))
      .setValue('#cred_userid_inputtext', testData.registrar.loginId)
      .setValue('#cred_password_inputtext', testData.registrar.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')

      client.assert.containsText('orgs-comp h3', 'Organizations')

  },

  'load all organizations loaded': client=> {
   
      client.waitForElementVisible('.sub-row')
      client.elements('css selector', '.sub-row', result=> { 
        client.assert.ok(result.value.length > 0)
      })

  }, 

  'search an organization': client=> {
   
      client.waitForElementVisible('input[type="text"]')
      client.setValue('input[type="text"]', 'Healthcare Community')
     
      client.click('.items-list-content>div>.row:first-child');

  }, 

  'load first organization': client=> {
     
      client.waitForElementVisible('input[type="text"]:first-child')
      client.expect.element('input[type="text"][formcontrolname="organizationName"]').to.have.value.equals('Healthcare Community')

  }, 

  'update organization contact info': client=> {
      const selector = 'input[type="text"][formcontrolname="contact"]'
      client.waitForElementVisible(selector)
      client.clearValue(selector).setValue(selector, 'Contact-' + Date.now())
      client.click('button[type="submit"]')

      client.waitForElementVisible('.sub-row')
      client.elements('css selector', '.sub-row', result=> { 
          client.assert.ok(result.value.length > 0)
      })
  }, 

  'add new organization': client=> {
      const aSelector = 'a[href="#/orgs/add"]'
      client.waitForElementVisible(aSelector)
      client.click(aSelector)

      const appSelector = '[formarrayname="insightApps"] .compact-row:first-child input[type="checkbox"]'
      client.waitForElementVisible(appSelector)

      const prefix = Date.now()
      const orgName = `e2e-test-org-${prefix}`
      client.click(appSelector)
      client.setValue('input[type="text"][formcontrolname="organizationName"]', orgName)
      client.setValue('input[type="text"][formcontrolname="id"]', testUtils.getGuid())
      client.setValue('input[type="text"][formcontrolname="location"]', `location-${prefix}`)
      client.setValue('input[type="text"][formcontrolname="contact"]', `contact-${prefix}`)
      client.setValue('[formarrayname="admins"] input[type="text"][formcontrolname="name"]', 'admin')
      client.setValue('[formarrayname="admins"] input[type="email"][formcontrolname="email"]', 'admin@test.com')
      client.setValue('[formarrayname="tags"] input[type="text"][formcontrolname="name"]', 'tag')
      client.setValue('[formarrayname="tags"] input[type="text"][formcontrolname="value"]', 'tag-value')

      client.click('button[type="submit"]')

      client.waitForElementVisible('.sub-row')

      client.useXpath()
      client.expect.element(`//*[contains(text(), "${prefix}")]`).to.be.present
      client.useCss()
      
  }, 

  'after': client=> {
    client.end()
  }
};