module.exports =  { 
      appUrl: 'https://stg-uomadmin.analytics.gehealthcare.com', 
      appUrlPrep: 'https://uom-web-ui-admin-stg-cd-prep.bi-dashboard-cloud-ase.p.azurewebsites.net',
      registrar: {
            loginId: 'UOMAdminAppRegistrar@healthcloudbidev01.onmicrosoft.com',
            loginPwd: 'July2017'
      },
      viewer: {
            loginId: 'UOMAdminAppViewer@healthcloudbidev01.onmicrosoft.com',
            loginPwd: 'July2017'
      }
}