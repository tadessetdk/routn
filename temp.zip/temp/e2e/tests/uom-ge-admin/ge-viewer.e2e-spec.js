const testData = require('./uom-ge-admin-test-data')
const testUtils = require('../test-utils')

module.exports = {

  'login into app': client=> {
    client.useCss();

    client
      .url(testUtils.getUrl(client, testData))
      .setValue('#cred_userid_inputtext', testData.viewer.loginId)
      .setValue('#cred_password_inputtext', testData.viewer.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')

      client.assert.containsText('orgs-comp h3', 'Organizations')

  },

  'load all organizations loaded': client=> {
   
      client.waitForElementVisible('.sub-row')
      client.elements('css selector', '.sub-row', result=> { 
        client.assert.ok(result.value.length > 0)
      })
  }, 

  'should not display Add New org button': client=> {
   
      client.waitForElementVisible('.sub-row')
      client.expect.element('a[href="#/orgs/add"]').to.be.not.present
  }, 

  'search an organization': client=> {
   
      client.waitForElementVisible('input[type="text"]')
      client.setValue('input[type="text"]', 'Healthcare Community')
     
      client.click('.items-list-content>div>.row:first-child');

  }, 

  'load first organization': client=> {
     
      client.waitForElementVisible('input[type="text"]:first-child')
      client.expect.element('input[type="text"][formcontrolname="organizationName"]').to.have.value.equals('Healthcare Community')

  }, 

  'should not display Update org button': client=> {
   
      client.expect.element('button[type="submit"]').to.be.not.present
      
  }, 

  'after': client=> {
    client.end()
  }
};