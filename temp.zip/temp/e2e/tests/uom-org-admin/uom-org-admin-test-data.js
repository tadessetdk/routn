module.exports =  { 
      appUrl: 'https://stg-uom.analytics.gehealthcare.com', 
      appUrlPrep: 'https://uom-web-ui-user-stg-cd-prep.bi-dashboard-cloud-ase.p.azurewebsites.net',
      updater: {
            loginId: 'UOMAppUpdate@HCADemo.onmicrosoft.com',
            loginPwd: 'MayMay2017'
      },
      viewer: {
            loginId: 'UOMAppViewOnly@HCADemo.onmicrosoft.com',
            loginPwd: 'MayMay2017'
      }
}