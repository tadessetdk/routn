const testData = require('./uom-org-admin-test-data')
const testUtils = require('../test-utils')

module.exports = {

  'login into app': client=> {
    client.useCss();

    client
      .url(testUtils.getUrl(client, testData))
      .setValue('#cred_userid_inputtext', testData.viewer.loginId)
      .setValue('#cred_password_inputtext', testData.viewer.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')

      client.waitForElementVisible('input[type="text"]:first-child')
      client.expect.element('input[type="text"][formcontrolname="organizationName"]').to.have.value.equals('Healthcare Community')

  },

  'should not display update org button': client=> {
   
      client.expect.element('button[type="submit"]').to.be.not.present

  }, 

  'after': client=> {
    client.end()
  }
};