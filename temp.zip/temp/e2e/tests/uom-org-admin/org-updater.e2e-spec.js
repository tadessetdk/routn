const testData = require('./uom-org-admin-test-data')
const testUtils = require('../test-utils')

module.exports = {

  'login into app': client=> {
    client.useCss();

    client
      .url(testUtils.getUrl(client, testData))
      .setValue('#cred_userid_inputtext', testData.updater.loginId)
      .setValue('#cred_password_inputtext', testData.updater.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')

      client.waitForElementVisible('input[type="text"]:first-child')
      client.expect.element('input[type="text"][formcontrolname="organizationName"]').to.have.value.equals('Healthcare Community')

  },

  'update organization contact info': client=> {
      const selector = 'input[type="text"][formcontrolname="contact"]'
      client.waitForElementVisible(selector)
      const contactInfo = 'Contact-' + Date.now()
      client.clearValue(selector).setValue(selector, contactInfo)
      client.click('button[type="submit"]')

      client.waitForElementPresent('.spinner-container')
      client.waitForElementNotPresent('.spinner-container')
      
      /*client.getValue(selector, result=> { 
          client.assert.equal(result.value, contactInfo)
      })*/

  }, 

  'after': client=> {
    client.end()
  }
};