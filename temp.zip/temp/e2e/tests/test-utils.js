const CSS_SELECTOR = 'css selector';
const getId = ()=> Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
const clickEx = (client, sel, onParent)=> {
      client.execute(function(){
            const args = Array.prototype.slice.call(arguments)
            const sel1 = args[0]
            const parentSel = args[1]
            let el = document.querySelector(args[0])
            parentSel && (el = el.closest(parentSel))
            el.click()
      }, [sel, onParent], function(result){ 
            (result.status) && (console.log(`failed to click ${sel}`, result))
      })
}

module.exports = { 
      getUrl: (client, testData)=> {
            return client.launch_url === 'prep' && testData.appUrlPrep || testData.appUrl
      },

      click: (client, sel)=> {
            return client.waitForElementVisible(sel)
                  .click(sel)
                  .moveToElement(sel, 0, 0)
                  .mouseButtonClick(0)
      },

      clickEx: (client, sel)=> {
            clickEx(client, sel)
      },

      clickParent: (client, sel, parentSel)=>{
            clickEx(client, sel, parentSel)
      },

      getEnabled: (client, selector, callback)=> {
          client.element(CSS_SELECTOR, selector, result=> {
                client.elementIdEnabled(result.value.ELEMENT, res=> {
                    callback(res.value)
                })
          })
      },

      verifyInputSelected: (client, selector, expectedValue)=> {
            if(expectedValue){
                  client.expect.element(selector).to.be.selected
            } else {
                  client.expect.element(selector).to.not.be.selected
            }
      },

      getInputsState: (client, callback, ...selectors)=> {
            let counter = selectors.length;
            let values = {};
            selectors.forEach(sel=> {
                  client.element(CSS_SELECTOR, sel, result=> {
                        client.elementIdSelected(result.value.ELEMENT, res=> {
                              values[sel] = res.value
                              if(--counter === 0) {
                                    callback(values)
                              }
                        })
                  })
            })
      },

      waitElementVisibleNoFail: (client, selector)=> {
            client.waitForElementVisible(selector, client.globals.waitForConditionTimeout, false)
      },

      waitElementPresentNoFail: (client, selector)=> {
            client.waitForElementPresent(selector, client.globals.waitForConditionTimeout, false)
      },

      assertPresent: (client, selector) => client.expect.element(selector || '#cred_userid_inputtext').to.be.present.after(60000),

      getGuid: function() {
            return getId() + getId() + '-' + getId() + '-' + getId() + '-' + getId() + '-' + getId() + getId() + getId()
      },

      clickButtonWithText: (client, sel, type = 'button')=> {
            client.useXpath()
            client.click(`//button[@type='${type}']/i[.='${sel}']`)
            client.useCss()
      }      
}
