const testUtils = require('../test-utils')
const testData = require('./analytic-solutions-test-data')

const firstDashboardSelector = '.items-list-content .row:first-child input[type="checkbox"]'
const lastDashboardSelector = '.items-list-content .row:last-child input[type="checkbox"]'

module.exports = {

  'login into app': client=> {
    client.useCss();

    client
      .url(testUtils.getUrl(client, testData))
      .setValue('#cred_userid_inputtext', testData.dashboardAssigner.loginId)
      .setValue('#cred_password_inputtext', testData.dashboardAssigner.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')
  },

  'navigate to config settings': client=> {
      
      const accountButtonSel = 'button.btn.dropdown-toggle'
      client.waitForElementPresent(accountButtonSel)
      client.click(accountButtonSel)
      
      const settingsSel = 'a[href="#/settings"]'
      client.waitForElementPresent(settingsSel)
      client.click(settingsSel)
      client.expect.element('a[href="#orgInfoSummary"]').to.be.present
      
  },  

  'selects an application and dashboard action': client=> {

      testUtils.clickEx(client, 'a[href="#dashboardsAssign"]')
      
      const appSelector = `select[name="applicationAlias"] option[value="${testData.applicationId}"]`
      client.expect.element(appSelector).to.be.present
      client.click(appSelector)

      const ddSelector = `select[name="orgGroupId"] option[value="${testData.groupId}"]`
      client.expect.element(ddSelector).to.be.present
      client.click(ddSelector)
   
      testUtils.clickButtonWithText(client, 'Lookup Dashboards', 'submit')
      client.expect.element('input[type="checkbox"][id="expiring-implants"]').to.be.present

  },

  'assign upto 2 dashboards': (client)=> {

        const cb = state=> {
            client.click(firstDashboardSelector)
                .click(lastDashboardSelector)

            testUtils.clickButtonWithText(client, 'Update')

            const loadingSelector = '.loading'
            client.waitForElementPresent(loadingSelector)
                .waitForElementNotPresent(loadingSelector)

            testUtils.verifyInputSelected(client, firstDashboardSelector, !state[firstDashboardSelector])
            testUtils.verifyInputSelected(client, lastDashboardSelector, !state[lastDashboardSelector])
        }

        testUtils.getInputsState(client, cb, firstDashboardSelector, lastDashboardSelector)
            
  },

  'cancel changes': (client)=> {

        const cb = state=> {
            client.click(firstDashboardSelector)
            testUtils.verifyInputSelected(client, firstDashboardSelector, !state[firstDashboardSelector])

            testUtils.clickButtonWithText(client, 'Undo')
            testUtils.verifyInputSelected(client, firstDashboardSelector, state[firstDashboardSelector])
        }

        testUtils.getInputsState(client, cb, firstDashboardSelector)

  },

  'after': client=> {
    client.end()
  }
};