const assert = require('assert');
const testUtils = require('../test-utils');
const testData = require('./analytic-solutions-test-data');
const screenToggleBtn = 'span.screen-dash-btn';
const navOpenBtn = 'span.nav-dash-btn';
const loading = 'div.loading spacings';
const navCloseBtn = 'a.closebtn';
const filterInput = 'input[type="text"]';
const rootFolderSelector = '#rootFolder';
const appSelector = '.dropdown.application-dropdown'

module.exports = {

  'login into app with roles should login to viewer': client=> {
      client.useCss();
      client
            .url(testUtils.getUrl(client, testData))
            .setValue('#cred_userid_inputtext', testData.userWithNoRole.loginId)
            .setValue('#cred_password_inputtext', testData.userWithNoRole.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')
      
      client.expect.element('span.ge-logo').to.be.visible;
  },

  'Verify footer is displayed with proper links': client => {

      client.expect.element('div.footer a').to.be.visible;

  },

  'Verify viewer dashboard structure exists': client => {
        
      client.expect.element('a.isDashboard').to.be.present;

  },

  'Verify viewer can support full screen mode': client => {

      client.waitForElementVisible(screenToggleBtn);
      client.assert.attributeContains('#dashboard-panel', 'class', 'col-sm-9')
      
      testUtils.clickEx(client, screenToggleBtn);
      client.assert.attributeContains('#dashboard-panel', 'class', 'col-sm-12')

  },

  'Verify clicking compress button reduce screen size to default mode': client => {

      testUtils.clickEx(client, screenToggleBtn);
      client.assert.attributeContains('#dashboard-panel', 'class', 'col-sm-9')
      
  },

  'Verify navigation still functional in full screen mode': client => {

      testUtils.clickEx(client, screenToggleBtn);

      client.expect.element(navOpenBtn).to.be.visible;
      client.expect.element(navCloseBtn).to.not.be.visible;

      testUtils.clickEx(client, navOpenBtn);

      client.expect.element(navCloseBtn).to.be.visible;
      testUtils.clickEx(client, screenToggleBtn);

  },

  'Verify application switch in header': client => {

     client.waitForElementVisible(appSelector)
     testUtils.clickEx(client, appSelector)

     client.getText(appSelector, result=> {
         client.waitForElementVisible(appSelector)
         testUtils.clickEx(client, 'ul.dropdown-menu li:last-child a.dropdown-list-element')
         client.expect.element(appSelector).text.to.not.equal(result.value)
     })

  },

  'Verify dashboards list loads when application is selected': client => {

        client.waitForElementVisible(appSelector)
        testUtils.clickEx(client, appSelector)

        client.getText(rootFolderSelector, result=> {
            client.waitForElementVisible(appSelector)
            testUtils.clickEx(client, 'ul.dropdown-menu li:first-child a.dropdown-list-element')
            client.expect.element(rootFolderSelector).text.to.not.equal(result.value)
        })

  },

  'after': client=> {
      client.end()
  }
};