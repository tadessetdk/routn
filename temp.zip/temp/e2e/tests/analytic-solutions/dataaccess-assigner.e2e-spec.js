const testUtils = require('../test-utils')
const testData = require('./analytic-solutions-test-data')

const firstEcubeSelector = '.items-list-content .row:first-child input[type="text"]'

module.exports = {

  'login into app': client=> {
    client.useCss();

    client
      .url(testUtils.getUrl(client, testData))
      .setValue('#cred_userid_inputtext', testData.dataAccessAssigner.loginId)
      .setValue('#cred_password_inputtext', testData.dataAccessAssigner.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')
  },

  'navigate to config settings': client=> {
      
      const accountButtonSel = 'button.btn.dropdown-toggle'
      client.waitForElementPresent(accountButtonSel)
      client.click(accountButtonSel)
      
      const settingsSel = 'a[href="#/settings"]'
      client.waitForElementPresent(settingsSel)
      client.click(settingsSel)
      client.expect.element('a[href="#orgInfoSummary"]').to.be.present
      
  },  

  'selects an application and filters action': client=> {

      testUtils.clickEx(client, 'a[href="#dataAccessAssign"]')
      
      const appSelector = `select[name="applicationAlias"] option[value="${testData.applicationId}"]`
      client.expect.element(appSelector).to.be.present
      client.click(appSelector)

      const ddSelector = `select[name="orgGroupId"] option[value="${testData.groupId}"]`
      client.expect.element(ddSelector).to.be.present
      client.click(ddSelector)
   
      testUtils.clickButtonWithText(client, 'Lookup Filters', 'submit')
      client.expect.element(firstEcubeSelector).to.be.present

  },

'set filter for the first ecube': (client)=> {

        const loadingSelector = '.loading'
        const submitSelector = '.items-list-content .row:first-child button:first-child'
        const newValue = testUtils.getGuid()
       
        client.clearValue(firstEcubeSelector)
                .setValue(firstEcubeSelector, newValue) 
                .pause(500)

        client.click(submitSelector)

        client.waitForElementPresent(loadingSelector)
                .waitForElementNotPresent(loadingSelector)

        client.getValue(firstEcubeSelector, res=> {
            client.assert.equal(res.value, newValue)
        })
           
  },

  'cancel changes': (client)=> {

        client.getValue(firstEcubeSelector, res=> {
            const prevValue = res.value
            client.clearValue(firstEcubeSelector).setValue(firstEcubeSelector, Date.now())

            const cancelSelector = '.items-list-content .row:first-child button:last-child'
            client.click(cancelSelector)

            client.getValue(firstEcubeSelector, r=> {
                client.assert.equal(r.value, prevValue)
            })
        })

  },

  'after': client=> {
    client.end()
  }
};