const testUtils = require('../test-utils')
const testData = require('./analytic-solutions-test-data')
const loading = 'div[class="loading spacings"]';

module.exports = {

  'login into app with roles should login to viewer': client=> {
      client.useCss();
      client
        .url(testUtils.getUrl(client, testData))
        .setValue('#cred_userid_inputtext', testData.userWithNoRole.loginId)
        .setValue('#cred_password_inputtext', testData.userWithNoRole.loginPwd)

      client.pause(1000)
      client.click('#cred_sign_in_button')
   
      client.expect.element('span[class="ge-logo"]').to.be.visible;

  },

  'Verify a user with no role are able to go to viewer, but not settings': client => {

      client.url(`${testUtils.getUrl(client, testData)}/#/settings`);
      testUtils.waitElementVisibleNoFail(client, 'div[class="alert alert-error"]');
      client.expect.element('div[class="alert alert-error"]').to.be.visible;
      
  },

  'after': client=> {
      client.end()
  }
};