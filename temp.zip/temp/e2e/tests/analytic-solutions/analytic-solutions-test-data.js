module.exports =  { 
      appUrl: 'https://stg-configuration.analytics.gehealthcare.com', 
      appUrlPrep: 'https://bi-dashboard-config-stg-cd-prep.bi-dashboard-cloud-ase.p.azurewebsites.net',
      dashboardAssigner: {
            loginId: 'leonardo.dicaprio@HCADemo.onmicrosoft.com',
            loginPwd: 'June2017'
      },
      dataAccessAssigner: {
            loginId: 'bruce.willis@HCADemo.onmicrosoft.com',
            loginPwd: 'June2017'
      },  
      userWithAllRole: {
            loginId: 'UserAllRoles@HCADemo.onmicrosoft.com',
            loginPwd: 'June2017'
      },
      userWithNoRole: {
            loginId: 'winslet.kate@HCADemo.onmicrosoft.com',
            loginPwd: 'June2017'
      },
      applicationId: 'inventory',
      groupId: '1a46bb57-2717-4acc-b7c1-42c9a0798b61'
}