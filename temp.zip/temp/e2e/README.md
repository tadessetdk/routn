# E2E Tests for All Web UI Apps

## Steps to prepare tests

1.  install `node.js`
2.  `git clone git@github.build.ge.com:gehc-bia/web-ui-e2e-tests.git`
3.  `cd /web-ui-e2e-tests`
4.  `npm install` 

## Steps to run tests

1.  `npm run e2e` 
