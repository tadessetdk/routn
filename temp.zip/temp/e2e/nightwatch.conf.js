module.exports = (function(settings) {
  if (process.env.NIGHTWATCH_ENV === 'win32') {
    settings.selenium.cli_args['webdriver.chrome.driver'] = './drivers/chromedriver.exe'
  }
  return settings;

})(require('./nightwatch.json'));