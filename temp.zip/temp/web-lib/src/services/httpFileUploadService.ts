import { Injectable, Inject } from '@angular/core';
import { Http, ConnectionBackend, RequestOptions, Request, RequestOptionsArgs, Headers, Response, ResponseOptions } from '@angular/http';

import { Observable } from 'rxjs';
import { Guid } from '../common/guid';
import { IClientSettings } from '../common/config';
import { ClientConfigService } from './clientConfigService';
import { XmlHttpRequestService } from './xmlHttpRequestService';

export interface IUploadFile {
    file: File;
    name?: string;    
}

@Injectable()
export class HttpFileUploadService {
    static AUTH_SESSION = 'auth-session';
    static AUTH_SESSION_ID = 'auth-session-id';

    private config: IClientSettings;

    constructor(private configService: ClientConfigService, private xmlHttpRequestService: XmlHttpRequestService, @Inject('Window') private window: Window) {          
        this.config = configService.value();
    }

    public uploadFiles(uri: string, files: Array<IUploadFile>): Observable<{}> {    
        return Observable.create(uploadAction$=> {
            const xhr = this.xmlHttpRequestService.createRequest();            
            xhr.open('POST', uri, true);
            
            let headers = {};
            this.setHeaders(xhr, uri, headers);
            this.addEventListeners(uri, xhr, headers, uploadAction$);

            const formData = new FormData();
            files.forEach(f=> formData.append(f.name || f.file.name, f.file))
            xhr.send(formData);
        });
    }  

    private addEventListeners(uri: string, xhr: XMLHttpRequest, headers, uploadAction$: any){
        xhr.onreadystatechange = ()=> {
            if (xhr.readyState === 4){
                const response = this.getResponse(uri, xhr, headers);                    
                Math.floor(xhr.status / 100) === 2 ? uploadAction$.next({ data: response }) : uploadAction$.error(response);
                uploadAction$.complete();
            } 
        };

        xhr.upload.onprogress = e=>{
            if(!e.lengthComputable) return
            uploadAction$.next({ type: 'progress', data: Math.ceil((e.loaded/e.total)*100) })
        }
    }

    private setHeaders(xhr: XMLHttpRequest, url: string, headers: any) {                 
        var endpoints = this.config.api.endpoints;
        var apiKeys = Object.keys(endpoints).filter(k=> url.toLowerCase().indexOf(endpoints[k].url.toLowerCase()) !== -1);        
        apiKeys.length && endpoints[apiKeys[0]].allowCredentials && (xhr.withCredentials = true);

        const authInfo = this.window.sessionStorage.getItem(HttpFileUploadService.AUTH_SESSION);
        const idToken = JSON.parse(authInfo).idToken;
        xhr.setRequestHeader('Authorization', `Bearer ${idToken}`);

        xhr.setRequestHeader('X-App-ID', `${this.config.appId}_${this.config.version}`);
        
        const sessionId = this.window.sessionStorage.getItem(HttpFileUploadService.AUTH_SESSION_ID);
        xhr.setRequestHeader('X-Session-ID', sessionId);

        const correlationId = Guid.NewGuid().toString();
        xhr.setRequestHeader('X-Correlation-ID', correlationId);
    
        headers.sessionId = sessionId;
        headers.correlationId = correlationId;
        headers.timestamp = new Date().getTime();
    }   

    private getResponse(uri: string, xhr: XMLHttpRequest, headers: any){
        const hdrs = { 'X-Session-ID': headers.sessionId, 'X-Correlation-ID': headers.correlationId }
        return {
            url: uri,
            status: xhr.status,
            statusText: xhr.statusText,
            request: {
                timestamp: headers.timestamp,
                headers: { get: key=> hdrs[key] }
            }
        }
    }
}