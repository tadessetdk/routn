/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { ClientConfigService } from './clientConfigService';

describe('ClientConfigService', () => {
    
    let clientConfigService: ClientConfigService;
    const config = { aadSettings: { clientId : 'clientId', tenantId: 'tenantId' } }; 
    let prevConfig;

    beforeAll(() => {
        prevConfig = (<any>window).__clientSettings;
    });

    beforeEach(() => {
        (<any>window).__clientSettings= config;
        clientConfigService = new ClientConfigService();
    });

    afterAll(()=>{
        (<any>window).__clientSettings = prevConfig;
    });

    it('gets application settings',  async(() => {
        // act
        const result = clientConfigService.value();

        // assert     
        expect(config).toEqual(result);     
    }));  
});