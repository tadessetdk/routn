import { Injectable } from '@angular/core';

@Injectable()
export class XmlHttpRequestService {
    createRequest(){
        return new XMLHttpRequest()
    }
}