export interface IAuthInfo {
    expire: number;
    userName: string;
    familyName: string;
    givenName: string;
    name: string;
    objectId: string;
    tenantId: string;
    groups: string[];
    roles: string[];
}