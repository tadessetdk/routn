import { Inject, Injectable } from '@angular/core';
import { Observable, AsyncSubject } from 'rxjs';

import { Guid } from '../common/guid';
import { ClientConfigService } from './clientConfigService';
import { IAuthInfo } from './authModels';

@Injectable()
export class AuthenticationService {

    public static AUTH_SESSION = 'auth-session';
    public static AUTH_SESSION_ID = 'auth-session-id';
    public static ID_TOKEN = 'id_token';
    public static LOGIN_URL = 'https://login.microsoftonline.com';
    
    private authAction$: AsyncSubject<string>;
    private aadSettings;
    private tokenInfo: IAuthInfo;
    private refreshInProgress: boolean;
    private timeoutHandle: number;
    
    constructor(private configService: ClientConfigService, @Inject('Window') private window: Window){        
        this.aadSettings = this.configService.value().aadSettings;
        this.aadSettings.tenant = this.aadSettings.tenant || 'common';
    }   

    getAuthInfo(): Observable<IAuthInfo>{
        if(!this.tokenInfo) {
            this.authenticate();           
        }

        return Observable.of(this.tokenInfo);
    }

    refreshAuth(): Observable<string>{
        if(this.refreshInProgress) return this.authAction$.asObservable();

        if(!this.tokenInfo) {
            this.tokenInfo = this.parseToken(this.getIdToken());
        }

        this.loadAuthIframe();

        this.refreshInProgress = true;
        this.authAction$ = new AsyncSubject<string>();

        (<any>this.window).__addAuthIdCallback(idToken=> {
            this.refreshInProgress = false;
            this.saveSessionItem(AuthenticationService.AUTH_SESSION, JSON.stringify({ idToken: idToken }));
            this.tokenInfo = this.parseToken(idToken);
            this.scheduleLogout();
            this.authAction$.next(idToken);            
            this.authAction$.complete();
        });

        return this.authAction$;
    }

    login(){      
        const prompt = (/^#\/verify$/i.test(this.window.location.hash)) && '&prompt=admin_consent' || '';    
        this.window.location.replace(this.getAuthIdUri(this.window.location.href) + prompt)
    }

    logout(){
        this.clearLogoutSchedule();
        this.clearSession();
        this.window.location.href = `${AuthenticationService.LOGIN_URL}/${this.aadSettings.tenant}/oauth2/logout?post_logout_redirect_uri=${encodeURIComponent(this.window.location.href)}`;
    }

    getIdToken(){
        const hash = this.window.location.hash.slice(1);
        if(hash){
            var idToken = hash.split('&').filter(v=> v.split('=')[0].toLowerCase() === AuthenticationService.ID_TOKEN).map(id=> id.split('=')[1])[0];
            if(idToken){
                this.window.location.hash = '';
                return decodeURIComponent(idToken);
            }
        }

        var authInfo = this.getSessionItem(AuthenticationService.AUTH_SESSION);
        return authInfo && authInfo.idToken || '';
    }

    private loadAuthIframe(){
        const url = this.getAuthIdUri(`${this.window.location.origin}/noop.html`);
        let ifrm = <HTMLIFrameElement>this.window.document.getElementById('ifrmAuthId');
        ifrm.src = `${url}&response_mode=query${this.getLoginHints()}&uomts=${new Date().getTime()}`;
    }

    private getAuthIdUri(redirectUri: string){
        const nonce = Guid.NewGuid();
        return `${AuthenticationService.LOGIN_URL}/${this.aadSettings.tenant}/oauth2/authorize?response_type=${AuthenticationService.ID_TOKEN}&client_id=${this.aadSettings.clientId}` +
                `&redirect_uri=${encodeURIComponent(redirectUri)}&state=auth_id&nonce=${nonce}`
    }

    private authenticate(){
        let idToken = this.getIdToken();                
        this.tokenInfo = this.parseToken(idToken);
        
        if (this.tokenInfo) {
            if(this.isTokenExpired()){
                this.logout();
            } else {
                this.saveSessionItem(AuthenticationService.AUTH_SESSION, JSON.stringify({ idToken: idToken, tokenInfo: this.tokenInfo }));
                this.saveSessionItem(AuthenticationService.AUTH_SESSION_ID, Guid.NewGuid().toString());
                this.scheduleLogout();
            }
        } else {
            this.clearSession();
            this.login();
        }
    }

    private getLoginHints(){      
        if(!this.tokenInfo) return '';  

        const userName = this.tokenInfo.userName;
        const loginHint = encodeURIComponent(userName);
        const domainHint = encodeURIComponent(userName.split('@').slice(-1)[0]);
        return `&login_hint=${loginHint}&domain_hint=${domainHint}`;
    }

    private scheduleLogout(){
        const sessionTimeout = this.aadSettings.sessionTimeout;
        let interval = this.tokenInfo.expire * 1000 - Date.now();
        interval = Math.min(sessionTimeout, interval) - 60000;
        
        this.clearLogoutSchedule();
        this.timeoutHandle = this.window.setTimeout(()=> this.logout(), interval);
    }

    private clearLogoutSchedule(){
        this.timeoutHandle && this.window.clearTimeout(this.timeoutHandle);
    }

    private saveSessionItem(key: string, value){
        this.window.sessionStorage[key] = value;
    }

    private getSessionItem(key: string){
        const value = this.window.sessionStorage[key];
        return !!value && JSON.parse(value) || '';
    }

    private clearSession(){
        this.window.sessionStorage.removeItem(AuthenticationService.AUTH_SESSION);
    }

    private isTokenExpired(): boolean{
        var expire = new Date(this.tokenInfo.expire * 1000);
        return new Date() > expire;
    } 

    private parseToken(token: string): IAuthInfo {
        if (!token) {
            console.log('Invalid auth token');
            return;
        }

        let parts = token.split('.');
        if (parts.length !== 3) {
           console.log('JWT must have 3 parts');
           return;
        }

        let decoded = this.urlBase64Decode(parts[1]);

        if (!decoded) {
            console.log('Cannot decode the token');
            return;
        }

        try{
            var tokenInfoRaw = JSON.parse(decoded);
            return {
                expire: tokenInfoRaw.exp,
                userName: tokenInfoRaw.upn,
                objectId: tokenInfoRaw.oid,
                tenantId: tokenInfoRaw.tid,
                familyName: tokenInfoRaw.family_name,
                givenName: tokenInfoRaw.given_name,
                name: tokenInfoRaw.name,
                groups: tokenInfoRaw.groups,
                roles: tokenInfoRaw.roles              
            };
        } catch(e){
            console.log(e);
        }
    }

    private urlBase64Decode(str: string) {
        var output = str.replace(/-/g, '+').replace(/_/g, '/');
        switch (output.length % 4) {
            case 0: { break; }
            case 2: { output += '=='; break; }
            case 3: { output += '='; break; }
            default: {
                throw 'Illegal base64url string!';
            }
        }        
        return decodeURIComponent((<any>(this.window)).escape(this.window.atob(output)));
    }
}