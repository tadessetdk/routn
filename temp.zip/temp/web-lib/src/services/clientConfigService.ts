import { Injectable } from '@angular/core';

import { IClientSettings } from '../common/config';
declare var __clientSettings: any;

@Injectable()
export class ClientConfigService {
    value(): IClientSettings {
        return  __clientSettings;
    }
}