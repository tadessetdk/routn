import { Injectable, Inject } from '@angular/core';
import { Http, ConnectionBackend, RequestOptions, Request, RequestOptionsArgs, Headers, Response, ResponseOptions } from '@angular/http';

import { Observable } from 'rxjs';
import { Guid } from '../common/guid';
import { IClientSettings } from '../common/config';
import { ClientConfigService } from './clientConfigService';
import { AuthenticationService } from './authenticationService';
import { AuthorizationService } from './authorizationService';

@Injectable()
export class HttpService extends Http{
    static AUTH_SESSION = 'auth-session';
    static AUTH_SESSION_ID = 'auth-session-id';

    private config: IClientSettings;

    constructor(
        backend: ConnectionBackend, 
        options: RequestOptions,         
        configService: ClientConfigService,
        private authenticationService: AuthenticationService,
        private authorizationService: AuthorizationService,
        @Inject('Window') private window: Window
    ){          
        super(backend, options);
        this.config = configService.value();
    }

    request(url: string | Request, options?: RequestOptionsArgs): Observable<Response>{
        const strUrl: string = (typeof url === 'string') && url || (<Request>url).url;
        let optionsTemp = Object.assign({ headers: new Headers() }, options);
        const timeout = this.setHeaders(strUrl, optionsTemp);   
        const timestamp = new Date().getTime();
        return super.request(strUrl, optionsTemp)
                    .timeout(timeout)
                    .map(response=> {
                       this.setResponseTimestamp(response, optionsTemp, timestamp);
                       return response;
                    })
                    .catch((error, ob) => {
                        return this.getRetry(error, ob)
                    })
    }

    getRetry(error, ob){
        if(error.status === 401){
            let source = (<any>ob).source;
            if(source.retried){
                this.authenticationService.logout();
                return Observable.empty();
            } 

            source.retried = true;
            return Observable.from([
                this.authenticationService.refreshAuth(),
                this.authorizationService.getAuthCode()
            ]).mergeMapTo(ob.retry(1));            
        }

        return Observable.throw(error);
    }

    private setResponseTimestamp(response, optionsTemp, timestamp: number){
        response.request = Object.assign(response.request || {}, optionsTemp);
        response.request.timestamp = timestamp;
    }

    private setHeaders(url: string, options: RequestOptionsArgs): number | Date {        
        var endpoints = this.config.api.endpoints;
        var apiKeys = Object.keys(endpoints).filter(k=> url.toLowerCase().indexOf(endpoints[k].url.toLowerCase()) !== -1);        
        if(apiKeys.length){
            var allowCredentials = endpoints[apiKeys[0]].allowCredentials;
            allowCredentials && (options.withCredentials = allowCredentials);
            const authInfo = this.window.sessionStorage.getItem(HttpService.AUTH_SESSION);
            const idToken = JSON.parse(authInfo).idToken;
            options.headers.append('Authorization', `Bearer ${idToken}`);                   
            options.headers.append('X-App-ID', `${this.config.appId}_${this.config.version}`);
            options.headers.append('X-Session-ID', this.window.sessionStorage[HttpService.AUTH_SESSION_ID]);
            options.headers.append('X-Correlation-ID', Guid.NewGuid().toString());
            options.headers.append('Accept', 'application/json');
            var allowAuthzHeaders = endpoints[apiKeys[0]].allowAuthzHeaders;
            if(allowAuthzHeaders){
                options.headers.append('X-Authorization-Code', this.window.sessionStorage['uom-authz-code']);
                options.headers.append('X-Redirect-Uri', this.window.sessionStorage['uom-authz-redirect-uri']);      
            }
            return this.config.api.timeout;
        }
        return 0;
    }   
}
