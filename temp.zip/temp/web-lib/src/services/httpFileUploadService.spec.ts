/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { HttpFileUploadService, IUploadFile } from './httpFileUploadService';

describe('HttpFileUploadService', () => {
    let httpFileUploadService;

    let xmlHttpRequestServiceObj;
    let configServiceSpyObj;    
    let createObservableSpy;

    let xhrSpyObj;
    let getSessionItemSpy;
    let uploadActionSpyObj;
    
    const authToken = 'authToken', authSession = JSON.stringify({ idToken: authToken }), authSessionId = 'authSessionId', authzCode = 'authzCode', redirectUri = 'authzRedirectUri';
    const url = 'dataIngestionUrl', appId = 'appId', version = 'version';
    const settings: any = { api: { endpoints: { dataIngestion: { url: url } } }, appId: appId, version: version };
    const files: Array<IUploadFile> = [ { name: 'filename', file: <any>{ parts: ['test content'], fileName: 'myfile.txt' } }];
   
    function createXhrSpyObj(forError?: boolean){
        let xhrSpyObj = jasmine.createSpyObj('XMLHttpRequest', ['open', 'send', 'setRequestHeader']) 
        xhrSpyObj.readyState = 4;
        xhrSpyObj.status = forError && 500 || 200;
        xhrSpyObj.statusText = 'error';
        xhrSpyObj.upload = {};
        return xhrSpyObj;         
    }
  
    beforeEach(() => {
        uploadActionSpyObj = jasmine.createSpyObj('Action', ['next', 'error', 'complete'])
        createObservableSpy = spyOn(Observable, 'create');
        configServiceSpyObj = jasmine.createSpyObj('ClientConfigService', ['value']);
        configServiceSpyObj.value.and.returnValue(settings);

        getSessionItemSpy = spyOn(window.sessionStorage, 'getItem');
        getSessionItemSpy.and.callFake(function(arg){
            switch(arg){
                case 'auth-session': return authSession
                case 'auth-session-id': return  authSessionId
                case 'uom-authz-code':  return authzCode
                case 'uom-authz-redirect-uri': return redirectUri 
            }
        })

        xhrSpyObj = createXhrSpyObj()     
        xmlHttpRequestServiceObj = jasmine.createSpyObj('XmlHttpRequestService', ['createRequest'])
        xmlHttpRequestServiceObj.createRequest.and.returnValue(xhrSpyObj);
        
        httpFileUploadService = new HttpFileUploadService(configServiceSpyObj, xmlHttpRequestServiceObj, window)
    })

    it('upload http request has been sent',  async(() => {
        // act
        httpFileUploadService.uploadFiles(url, files)
        createObservableSpy.calls.mostRecent().args[0]()   
          
        // assert
        expect(xmlHttpRequestServiceObj.createRequest).toHaveBeenCalled();
      
        expect(xhrSpyObj.open).toHaveBeenCalledWith('POST', url, true);    
        const formData = new FormData();
        formData.append(files[0].name, files[0].file)
        expect(xhrSpyObj.send).toHaveBeenCalledWith(formData);

        const args = xhrSpyObj.setRequestHeader.calls.all().map(c=> c.args);
        expect(args.some(a=> a[0] === 'Authorization' && a[1] === `Bearer ${authToken}`)).toBe(true);
        expect(args.some(a=> a[0] === 'X-App-ID' && a[1] === `${appId}_${version}`)).toBe(true);
        expect(args.some(a=> a[0] === 'X-Session-ID' && !!a[1])).toBe(true);
        expect(args.some(a=> a[0] === 'X-Correlation-ID' && !!a[1])).toBe(true);

        expect(typeof xhrSpyObj.onreadystatechange).toBe('function');
        expect(typeof xhrSpyObj.upload.onprogress).toBe('function');
        expect(configServiceSpyObj.value).toHaveBeenCalled();
    })); 

    it('upload http request has been sent with no filename',  async(() => {
        // act
        const files1 = [{ file: files[0].file }]
        httpFileUploadService.uploadFiles(url, files)
        createObservableSpy.calls.mostRecent().args[0]()   
          
        // assert
        expect(xmlHttpRequestServiceObj.createRequest).toHaveBeenCalled();
      
        expect(xhrSpyObj.open).toHaveBeenCalledWith('POST', url, true);          
        expect(xhrSpyObj.send).toHaveBeenCalled();    
    })); 

    it('upload http request has progressed', async(() => {
        // arrange
        httpFileUploadService.uploadFiles(url, files)        
        createObservableSpy.calls.mostRecent().args[0](uploadActionSpyObj)   

        // act         
        const evt = { lengthComputable: true, loaded: 25, total: 100 }
        xhrSpyObj.upload.onprogress(evt)

        // assert    
        expect(uploadActionSpyObj.next).toHaveBeenCalledWith({ type: 'progress', data: Math.ceil((evt.loaded/evt.total)*100) })
    })); 

    it('upload http request has succeeded', async(() => {
        // arrange
        httpFileUploadService.uploadFiles(url, files)        
        createObservableSpy.calls.mostRecent().args[0](uploadActionSpyObj)   

        // act 
        xhrSpyObj.onreadystatechange();

        // assert          
        expect(uploadActionSpyObj.next.calls.allArgs()[0][0].data.status).toBe(200)        
        expect(uploadActionSpyObj.complete).toHaveBeenCalled()
    })); 

     it('upload http request has failed', async(() => {
        // arrange
        createXhrSpyObj(true)
        httpFileUploadService.uploadFiles(url, files)        
        createObservableSpy.calls.mostRecent().args[0](uploadActionSpyObj)   

        // act 
        xhrSpyObj.status = 500 
        xhrSpyObj.onreadystatechange();

        // assert          
        expect(uploadActionSpyObj.error.calls.allArgs()[0][0].status).toBe(500)
        expect(uploadActionSpyObj.complete).toHaveBeenCalled()
    })); 

});