/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing'

import { XmlHttpRequestService } from './xmlHttpRequestService'

describe('XmlHttpRequestService', () => {
    
    it('creates HttpUploadService',  async(() => {
        // arrange
        const service = new XmlHttpRequestService()

        // act
        const request = service.createRequest()

        // assert            
        expect(request).not.toBeUndefined();   
        expect(request instanceof XMLHttpRequest).toBeTruthy();   
    }));  

});