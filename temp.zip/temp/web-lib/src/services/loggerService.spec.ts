/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { LoggerService, ILogEvent, EventLevel } from './loggerService';
import { ClientConfigService } from './clientConfigService';

describe('LoggerService', () => {
   
    const evt = {
        sessionId: 'sessionId',
        correlationId: 'correlationId',                
        message: 'message',
        requestUri: 'requestUri',
        statusCode: 200,
        latency: 2000,
        url: 'url',
        timestamp: '3234334'
    };
    
    const window1 = { 
        location : { origin: 'origin', href: 'href', onbeforeunload: ()=>{} },
    };

    describe('Disabled logging', ()=>{
        let configService1, loggerService, httpMock;   
        
        beforeEach(() => {
            configService1 = new ClientConfigService();           
            let config1 = { loggingConfig: { enabled: false } };           
            spyOn(configService1, 'value').and.returnValue(config1);            
            httpMock = jasmine.createSpyObj('http', ['post']);
            httpMock.post.and.returnValue({ catch: ()=> {  return { subscribe: ()=> {} } } });
            loggerService = new LoggerService(httpMock, <any>window1, configService1);
        });

        it('should not log event',  async(() => {            
            // act
            loggerService.trace(evt);
        
            // assert     
            window.setTimeout(()=> expect(httpMock.post).not.toHaveBeenCalled(), 600);
        }));

    });

    describe('Log settings with batchSize = 1', ()=>{
        let configService2, loggerService, httpMock;   
        
        beforeEach(() => {
            configService2 = new ClientConfigService();           
            let config1 = { loggingConfig: { enabled: true, batchSize: 1 } };           
            spyOn(configService2, 'value').and.returnValue(config1);            
            httpMock = jasmine.createSpyObj('http', ['post']);
            httpMock.post.and.returnValue({ catch: ()=> {  return { subscribe: ()=> {} } } });
            loggerService = new LoggerService(httpMock, <any>window1, configService2);
        });

        it('should log event immediately',  async(() => {
            // act
            loggerService.warn(evt);
        
            // assert     
            expect(httpMock.post).toHaveBeenCalledTimes(1);
        }));

    });

    describe('Log settings with batchSize > 1', ()=>{
        let loggerService, httpMock;   
        const config = { loggingConfig: { enabled: true, defaultLevel: EventLevel.INFO, batchSize: 3, timeInterval: 500 } }; 

        beforeEach(() => {
            const configService = new ClientConfigService();
            spyOn(configService, 'value').and.returnValue(config);
            httpMock = jasmine.createSpyObj('http', ['post']);
            httpMock.post.and.returnValue({ catch: ()=> {  return { subscribe: ()=> {} } } });
            loggerService = new LoggerService(httpMock, <any>window1, configService);
        });

        it('should not log TRACE when defaultLevel is INFO',  (done => {
            // act
            loggerService.trace(evt);
        
            // assert     
            window.setTimeout(()=>{
                expect(httpMock.post).not.toHaveBeenCalled()
                done();
            }, 600);
        }));

        it('should not log DEBUG when defaultLevel is INFO',  (done => {
            // act
            loggerService.debug(evt);
        
            // assert     
            window.setTimeout(()=>{
                expect(httpMock.post).not.toHaveBeenCalled()
                done()
            }, 600);
        }));

        it('should log INFO since timeInterval elapsed',  (done => {
            // act
            loggerService.info(evt);
        
            // assert                 
            window.setTimeout(()=>{
                expect(httpMock.post).toHaveBeenCalled()
                done()
            }, 600);
        }));

        it('should log WARN since timeInterval elapsedO',  (done => {
            // act
            loggerService.warn(evt);
        
            // assert     
            window.setTimeout(()=>{
                expect(httpMock.post).toHaveBeenCalled()
                done()
            }, 600);
        }));

        it('should log ERROR since timeInterval elapsed',  (done => {
            // act
            loggerService.error(evt);
        
            // assert     
             window.setTimeout(()=>{
                expect(httpMock.post).toHaveBeenCalled()
                done()
            }, 600);
        }));

        it('should log mulitple events at once as longs the batchSize is greater or equal to settings',  async(() => {
            // act
            loggerService.error(evt);
            loggerService.error(evt);
            loggerService.error(evt);
        
            // assert     
            expect(httpMock.post).toHaveBeenCalledTimes(1);
            expect(httpMock.post).toHaveBeenCalledWith(`${window1.location.origin}/log`, jasmine.any(Array), jasmine.any(Object));
        }));

    });

});