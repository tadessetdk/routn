/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { AuthenticationService } from './authenticationService';
import { ClientConfigService } from './clientConfigService';

declare var window: any;

describe('AuthenticationService', () => {
    
    let authenticationService;
    const idToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Il9VZ3FYR190TUxkdVNKMVQ4Y2FIeFU3Y090YyIsImtpZCI6Il9VZ3FYR190TUxkdVNKMVQ4Y2FIeFU3Y090YyJ9.eyJhdWQiOiIxNTIzYzQ4NC1jMjQwLTRkNDgtOTMzMi03MjZkOTQ0NWYxOGMiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC82OTcwYjJhNS1lMjIwLTRkNjgtOGZjMC0yOTkyYTFiOGJkYjcvIiwiaWF0IjoxNDg5MTczODE0LCJuYmYiOjE0ODkxNzM4MTQsImV4cCI6MTQ4OTE3NzcxNCwiYW1yIjpbInB3ZCJdLCJmYW1pbHlfbmFtZSI6IkRpY2FwcmlvIiwiZ2l2ZW5fbmFtZSI6Ikxlb25hcmRvIiwiZ3JvdXBzIjpbImEzNWRkZDgzLTcyNGItNDc1Mi1iNzJiLWNhNTUxY2I2NzI2NiIsIjkwNjRmYTI1LWIzNzItNDVlNi05NWNhLTIwMGViNDdhYWMzOCJdLCJpcGFkZHIiOiIxMDQuMTI5LjE5Ni43OSIsIm5hbWUiOiJEaWNhcHJpbywgTGVvbmFyZG8iLCJub25jZSI6IjdhMGRhZDMyLTAxNDQtMGRlZi0xOGFjLThhYjAzMGEyNzMyZCIsIm9pZCI6IjUzYTFmYzEyLTc2ODEtNDYxOC1hOTI3LWI4MmZlMjZkMTE1NyIsInBsYXRmIjoiMyIsInB3ZF9leHAiOiI5NjAwOTgiLCJwd2RfdXJsIjoiaHR0cHM6Ly9wb3J0YWwubWljcm9zb2Z0b25saW5lLmNvbS9DaGFuZ2VQYXNzd29yZC5hc3B4Iiwicm9sZXMiOlsiRGFzaGJvYXJkQXNzaWduIl0sInN1YiI6Im9PYTBzWXpsOWxham9kd0NsNWhPaUpWdlBJbzUtUjgxQ3BsUkRNZjhUbWsiLCJ0aWQiOiI2OTcwYjJhNS1lMjIwLTRkNjgtOGZjMC0yOTkyYTFiOGJkYjciLCJ1bmlxdWVfbmFtZSI6Imxlb25hcmRvLmRpY2FwcmlvQEhDQURlbW8ub25taWNyb3NvZnQuY29tIiwidXBuIjoibGVvbmFyZG8uZGljYXByaW9ASENBRGVtby5vbm1pY3Jvc29mdC5jb20iLCJ2ZXIiOiIxLjAifQ.hcD4SdeGE3aAbAZTxqvBp7lJq8uYcQL_8dS6iCCVdnfAPBuL11YKI46ZHiecYN8jhOEmcqigf7Nz1cc6b-UxbaiBaaxkG91Wr4RWmMjPi1384WEXuiUsdYXyX7XJDggqWXhaMsqrcq8jYNdmwjkDTfyqCouhgcl8o3SvQqxauBDgZTVP0wOQqoYqZCDa1Y9Y4xzryOgX2OiVv6PbER_HRnZ33iRIzX529XmFJ6fhBoylILvGSLKcLCGt1xlQsfHgevwDUUidLcPJhl9qch-QY6a3TXBEDxayStd_vXDYVqsm0LF74u57E-5X6QrjgKcRbJ92Y1uRD_jaRoh824b0oA';
    const idTokenHash = '#' + AuthenticationService.ID_TOKEN + '=' + idToken;
    const clientId = 'clientId', tenantId = 'tenantId', sessionTimeout = 300000;
    const config = { aadSettings: { clientId : clientId, tenant: tenantId, sessionTimeout: sessionTimeout } }; 
    const ifrm = { src: '' };
    let replaceSpy, setTimeoutSpy, clearTimeoutSpy, escapeSpy, atobSpy;
    let removeItemSpy;
    let jsonParseSpy;
    let addAuthIdCallbackSpy, getElementByIdSpy;
   
    let windowObj = { 
        sessionStorage : { removeItem: ()=> {} },
        location : { origin: 'origin', hash: idTokenHash, href: 'href', replace: ()=>{} },
        __addAuthIdCallback: ()=>{},
        document: { getElementById: ()=>{} },
        setTimeout: ()=> {},
        clearTimeout: ()=> {},
        escape: ()=> {},
        atob: ()=> {}
    };
     
    const jsonParse = JSON.parse.bind(null);  

    function setupParser(expire?: boolean){
        JSON.parse = jsonParse;                    
        jsonParseSpy = spyOn(JSON, 'parse');
        jsonParseSpy.and.callFake(arg=> {
            let result =  jsonParse(arg);
            result.exp && (result.exp = (Date.now()/1000) + (expire && -1000000 || 1000000));
            return result;
        })
    }

    beforeEach(() => {
        setupParser();
        windowObj.location.hash = idTokenHash;

        addAuthIdCallbackSpy = spyOn(windowObj, '__addAuthIdCallback');
        getElementByIdSpy = spyOn(windowObj.document, 'getElementById').and.returnValue(ifrm);
        replaceSpy = spyOn(windowObj.location, 'replace');
        setTimeoutSpy = spyOn(windowObj, 'setTimeout');
        clearTimeoutSpy = spyOn(windowObj, 'clearTimeout');
        escapeSpy = spyOn(windowObj, 'escape').and.callFake(arg=> window.escape(arg));
        atobSpy = spyOn(windowObj, 'atob').and.callFake(arg=> window.atob(arg));
        removeItemSpy = spyOn(windowObj.sessionStorage, 'removeItem');

        const configService = new ClientConfigService();
        spyOn(configService, 'value').and.returnValue(config);
        authenticationService = new AuthenticationService(configService, <any>windowObj);
    });  

    function assertToken(){
        expect(authenticationService.tokenInfo.userName).toBeTruthy();
        expect(authenticationService.tokenInfo.tenantId).toBeTruthy();
        expect(authenticationService.tokenInfo.groups.length).toBeTruthy();
        expect(authenticationService.tokenInfo.roles.length).toBeTruthy();        
    }

    function assertRefresh(ob, inProgress?: boolean){
        ob.subscribe(t=> expect(t).toBeTruthy());
        expect(windowObj.location.hash).toBeFalsy();                
        expect(authenticationService.refreshInProgress).toBe(!inProgress);
        assertToken();
        expect(addAuthIdCallbackSpy).toHaveBeenCalledWith(jasmine.any(Function));
        expect(getElementByIdSpy).toHaveBeenCalledWith('ifrmAuthId');
        expect(ifrm.src).toBeTruthy();
        expect(escapeSpy).toHaveBeenCalledWith(jasmine.any(String));
        expect(atobSpy).toHaveBeenCalledWith(jasmine.any(String));
    }

    it('initialize auth token from location.hash on refresh',  async(() => {
        // arrange       
        authenticationService.refreshInProgress = false;
        authenticationService.tokenInfo = null;
        windowObj.sessionStorage[AuthenticationService.AUTH_SESSION] = '';

        // act
        const ob = authenticationService.refreshAuth();
       
        // assert   
        assertRefresh(ob);
    }));

    it('initialize auth token from session on refresh if no location.hash',  async(() => {
        // arrange       
        authenticationService.refreshInProgress = false;
        authenticationService.tokenInfo = null;
        windowObj.location.hash = '';    
        windowObj.sessionStorage[AuthenticationService.AUTH_SESSION] = JSON.stringify({ idToken: idToken,"tokenInfo": { tokenInfo: { tenantId: tenantId } }});
        
        // act
        const ob = authenticationService.refreshAuth();

        // assert   
        assertRefresh(ob);
        expect(windowObj.sessionStorage[AuthenticationService.AUTH_SESSION]).toBeTruthy();
    }));

    it('refresh token from aad',  async(() => {
        // arrange       
        authenticationService.refreshInProgress = false;
        authenticationService.tokenInfo = null;
        windowObj.sessionStorage[AuthenticationService.AUTH_SESSION] = '';

        // act
        const ob = authenticationService.refreshAuth();        
        const nextSpy = spyOn(ob, 'next');
        const completeSpy = spyOn(ob, 'complete');
        addAuthIdCallbackSpy.calls.mostRecent().args[0](idToken);

        // assert   
        assertRefresh(ob, true);        
        expect(setTimeoutSpy).toHaveBeenCalled();
        expect(nextSpy).toHaveBeenCalledWith(idToken);
        expect(completeSpy).toHaveBeenCalled();
    }));

    it('allow only one auth refresh at a time',  async(() => {
        // arrange       
        authenticationService.tokenInfo = null;      

        // act
        authenticationService.refreshAuth();
        authenticationService.refreshAuth();

        // assert     
        expect(addAuthIdCallbackSpy).toHaveBeenCalledTimes(1);
    }));  
    
    it('get auth info on login for valid token',  async(() => {
        // arrange       
        authenticationService.tokenInfo = null;
        authenticationService.timeoutHandle = 123;
        windowObj.sessionStorage[AuthenticationService.AUTH_SESSION] = '';

        // act
        authenticationService.getAuthInfo();

        // assert         
        assertToken();
        expect(windowObj.sessionStorage[AuthenticationService.AUTH_SESSION]).toBeTruthy();
        expect(setTimeoutSpy).toHaveBeenCalled();
        expect(clearTimeoutSpy).toHaveBeenCalled();        
    }));

    it('logs out if the token is expired',  async(() => {
        // arrange       
        setupParser(true);
        authenticationService.tokenInfo = null;
        authenticationService.timeoutHandle = 123;

        // act
        authenticationService.getAuthInfo();

        // assert         
        expect(windowObj.location.href.indexOf('oauth2/logout')).not.toBe(-1);
        expect(clearTimeoutSpy).toHaveBeenCalled();
        expect(removeItemSpy).toHaveBeenCalled();
    }));
     
    it('redirect to login if no token found',  async(() => {
        // arrange   
        windowObj.location.hash = '';    
        windowObj.sessionStorage[AuthenticationService.AUTH_SESSION] = '';
        authenticationService.refreshInProgress = false;
        authenticationService.tokenInfo = null;

        // act
        authenticationService.getAuthInfo();

        // assert         
        expect(replaceSpy).toHaveBeenCalled();
        expect(removeItemSpy).toHaveBeenCalled();
    })); 

    it('logs in user',  async(() => {
        // arrange   
        windowObj.location.hash = 'hash';

        // act
        authenticationService.login();

        // assert         
        expect(replaceSpy).toHaveBeenCalled();
    }));  

    it('logs in user for admin consent',  async(() => {
        // arrange   
        windowObj.location.hash = '#/verify';

        // act
        authenticationService.login();

        // assert         
        expect(replaceSpy.calls.mostRecent().args[0].indexOf('prompt=admin_consent')).not.toBe(-1)
    }));   

    it('logout user',  async(() => {
        // arrange   
        windowObj.location.href = '';
        authenticationService.timeoutHandle = 123;

        // act
        authenticationService.logout();

        // assert       
        expect(windowObj.location.href).toBeTruthy();
        expect(clearTimeoutSpy).toHaveBeenCalled();
        expect(removeItemSpy).toHaveBeenCalled();
    }));

});