import { Inject, Injectable } from '@angular/core';
import { Observable, AsyncSubject } from 'rxjs';

import { ClientConfigService } from './clientConfigService';
declare var __addAuthCodeCallback;

@Injectable()
export class AuthorizationService{
    private static AUTH_SESSION = 'auth-session';
    private refreshInProgress = false;
    private authAction$: AsyncSubject<string>;
  
    constructor(private configService: ClientConfigService, @Inject('Window') private window: Window){ }

    getAuthCode(): Observable<string>{
        if(!this.getAuthSessionItem()) return Observable.of('');
        
        if(this.refreshInProgress) return this.authAction$.asObservable();

        this.loadAuthIframe(`${this.window.location.origin}/noop.html`);

        this.refreshInProgress = true;
        this.authAction$ = new AsyncSubject<string>();

        (<any>this.window).__addAuthCodeCallback(code=> {
            this.refreshInProgress = false;
            this.window.sessionStorage['uom-authz-code'] = code;
            this.authAction$.next(code);            
            this.authAction$.complete();
        });

        return this.authAction$;
    }

    private getAuthSessionItem(){
        const authInfo = this.window.sessionStorage[AuthorizationService.AUTH_SESSION];
        return authInfo && JSON.parse(authInfo);
    }

    private loadAuthIframe(redirectUri){
        const url = this.getAuthCodeUri(redirectUri);
        this.window.sessionStorage['uom-authz-redirect-uri'] = redirectUri;
        let ifrm = <HTMLIFrameElement>this.window.document.getElementById('ifrmAuthCode');
        ifrm.src = `${url}&uomts=${new Date().getTime()}`;     
    }

    private getAuthCodeUri(redirectUri){
        const clientId = this.configService.value().aadSettings.clientId;
        const authInfo: any = this.getAuthSessionItem();
        const tenantId = authInfo.tokenInfo.tenantId;
        return `https://login.microsoftonline.com/${tenantId}/oauth2/authorize?client_id=${clientId}&` +
               `response_type=code&response_mode=query&state=auth_code&redirect_uri=${encodeURIComponent(redirectUri)}`;
    }
}