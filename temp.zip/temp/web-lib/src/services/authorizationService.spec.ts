/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { AuthorizationService } from './authorizationService';
import { ClientConfigService } from './clientConfigService';

describe('AuthorizationService', () => {
    
    let authorizationService;
    const authCode = 'authCode', clientId = 'clientId', tenantId = 'tenantId';
    const config = { aadSettings: { clientId : clientId } }; 
    const ifrm = { src: '' };

    const window = { 
        sessionStorage : {},
        location : { origin: 'origin' },
        __addAuthCodeCallback: ()=>{},
        document: { getElementById: ()=>{}}
    };

    beforeEach(() => {
        spyOn(window, '__addAuthCodeCallback').and.returnValue(authCode);
        spyOn(window.document, 'getElementById').and.returnValue(ifrm);
        window.sessionStorage['user-tenant-id'] = '';
        window.sessionStorage['auth-session'] = JSON.stringify({ tokenInfo: { tenantId: tenantId } });
        const configService = new ClientConfigService();
        spyOn(configService, 'value').and.returnValue(config);
        authorizationService = new AuthorizationService(configService, <any>window);
    });

    it('gets auth code',  async(() => {
        // arrange       
        window.sessionStorage['uom-authz-code'] = '';
        window.sessionStorage['uom-authz-redirect-uri'] = '';

        // act
        authorizationService.getAuthCode();
        (<any>(window.__addAuthCodeCallback)).calls.mostRecent().args[0](authCode);

        // assert     
        expect(window.sessionStorage['uom-authz-redirect-uri']).toBeTruthy();
        expect(window.sessionStorage['uom-authz-code']).toBe(authCode);
        expect(window.__addAuthCodeCallback).toHaveBeenCalledWith(jasmine.any(Function));
        expect(window.document.getElementById).toHaveBeenCalledWith('ifrmAuthCode');
        expect(ifrm.src).toBeTruthy();
    }));

    it('only one authorization request made for concurrent requests',  async(() => {
        // arrange       
        window.sessionStorage['uom-authz-code'] = '';
        window.sessionStorage['uom-authz-redirect-uri'] = '';

        // act
        authorizationService.getAuthCode(authCode);
        authorizationService.getAuthCode(authCode);
        authorizationService.getAuthCode(authCode);
        
        // assert
        expect((<any>(window.__addAuthCodeCallback)).calls.count()).toBe(1);
    }));

});