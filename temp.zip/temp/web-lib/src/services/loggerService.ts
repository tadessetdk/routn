import { Injectable, Inject } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';

import { ClientConfigService } from './clientConfigService';

export enum EventLevel{
    TRACE = 1, 
    DEBUG = 2, 
    INFO = 4, 
    WARN = 8, 
    ERROR = 16
}

export interface ILogEvent {
    appId: string;
    sessionId: string; 
    correlationId: string;                
    message: string;    
    requestUri?: string;
    statusCode?: string | number;
    latency?: number;
    url?: string;
    level?: EventLevel;
    timestamp?: string;
}        

export interface ILoggerOption{
    url: string;
    enabled: boolean;
    defaultLevel?: EventLevel;    
    batchSize?: number;
    timeInterval?: number;
}

@Injectable()
export class LoggerService {        
        enabled: boolean;
        defaultLevel: EventLevel = EventLevel.INFO;
        url: string;
        batchSize: number;
        timeInterval: number;
        events: Array<ILogEvent> = [];
        
        constructor(private http: Http, @Inject('Window') private window: Window, config: ClientConfigService){
            this.init(config.value().loggingConfig);
        }        
      
        trace(event: ILogEvent){
            this.log(EventLevel.TRACE, event);
        }

        debug(event: ILogEvent){
            this.log(EventLevel.DEBUG, event);
        }

        info(event: ILogEvent){
            this.log(EventLevel.INFO, event);
        }

        warn(event: ILogEvent){
            this.log(EventLevel.WARN, event);
        }

        error(event: ILogEvent){
            this.log(EventLevel.ERROR, event);
        }   

        private init(options: ILoggerOption){	
            this.url = `${this.window.location.origin}/log`;
            this.enabled = options.enabled;
            this.defaultLevel = options.defaultLevel || EventLevel.INFO;                    
            this.batchSize = options.batchSize || 1;
            this.timeInterval = options.timeInterval || 5000;
            
            !this.url && (console.error('logger url cannot be empty'));    

            let source = Observable.interval(this.timeInterval);
            source.subscribe(v=> this.flush());
            this.window.onbeforeunload = ()=> this.flush(true, true);
        }

        private log(level: EventLevel, event: ILogEvent){
            if(!this.enabled) return;
            if(level < this.defaultLevel) return;

            let url = this.window.location.href; 
            let timestamp = new Date().toISOString();
            let evt: any = Object.assign({}, event);
            evt.url = url;
            evt.timestamp = timestamp;
            evt.level = EventLevel[level];
            this.events.push(evt);
            
            (this.events.length >= this.batchSize) && this.flush();      
        }

        private flush(all?: boolean, sync?: boolean){
            var evts = (all && this.events) || this.events.splice(-this.batchSize);
            if(!evts || !evts.length) return;

            let headers = new Headers({ 'Content-Type': 'application/json' });
            let options = new RequestOptions({ headers: headers });
            this.http.post(this.url, evts, options)
                        .catch((error: Response)=>{
                            console.error(error);
                            return Observable.empty()
                        })
                        .subscribe();
        }   
             
}