/* tslint:disable:no-unused-variable */
import { Observable } from 'rxjs';
import { TestBed, async, inject, fakeAsync, tick} from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { HttpModule, Http, RequestOptions, XHRBackend, Response, ResponseOptions, RequestMethod, BaseRequestOptions, Headers } from '@angular/http';

import { ClientConfigService } from './clientConfigService';
import { AuthenticationService } from './authenticationService';
import { AuthorizationService } from './authorizationService';
import { HttpService } from './httpService';

describe('HttpService', () => {

    const uomUrl = 'https://uomws.com';
    const managerUrl = 'https://uommgr.com';
    const responseData = { body: '[{"name": "app1"}, {"name": "app2"}]' };

    const sessionId = 'session-id';
    const idToken = 'idToken';
    const sessionAuthValue = JSON.stringify({ idToken: idToken });
    const authzCode = 'uom-authz-code-value';
    const authRedirectUrl = 'uom-authz-redirect-uri'; 
    const apiTimeout = 300000;  
    
    beforeAll(()=>{
        (<any>window).__clientSettings = {
            version: '0.1.',
            appId: 'UOM-Admin',
            api: {
                endpoints: {
                    uom: {
                        url: uomUrl,
                        allowCredentials: true,
                        allowAuthzHeaders: true
                    },
                    manager: {
                        url: managerUrl
                    }
                },
                timeout: apiTimeout
            },
            aadSettings: {
                clientId: 'clientId', 
                tenant: 'tenantId' 
            }
        };

        window.sessionStorage[HttpService.AUTH_SESSION_ID] = sessionId;
        window.sessionStorage[HttpService.AUTH_SESSION] = sessionAuthValue;
        window.sessionStorage['uom-authz-code'] = authzCode;
        window.sessionStorage['uom-authz-redirect-uri'] = authRedirectUrl;   
    });

    afterAll(()=>{
        (<any>window).__clientSettings = {};
    });

    beforeEach(() => {    
        TestBed.configureTestingModule({
            imports: [ HttpModule ],
            providers: [
                MockBackend,
                BaseRequestOptions,
                {
                    provide: HttpService,
                    useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
                        const configService = new ClientConfigService();
                        return new HttpService(
                            backend, options, configService, 
                            new AuthenticationService(configService, window), 
                            new AuthorizationService(configService, window), 
                            window
                        );
                    },
                    deps: [MockBackend, BaseRequestOptions]
                }
            ]
        });
    });

    let verifyHeaders = (response, withCredentials: boolean = true, allowAuthzHeaders: boolean = false)=>{
        const request = response.request;
        expect(request.timestamp).toBeGreaterThan(0);
        withCredentials ? expect(request.withCredentials).toBe(true) : expect(request.withCredentials).toBeFalsy();
        //expect(...).toBe(this.config.api.timeout);
       
        const headers = request.headers;
        expect(headers.get('Authorization')).toBe(`Bearer ${idToken}`);
        expect(headers.get('X-App-ID')).toBeTruthy();
        expect(headers.get('X-Session-ID')).toBe(sessionId);
        expect(headers.get('X-Correlation-ID')).toBeTruthy();
        if(allowAuthzHeaders){
            expect(headers.get('X-Authorization-Code')).toBe(authzCode);
            expect(headers.get('X-Redirect-Uri')).toBe(authRedirectUrl);
        }
    };

    const fakeAsync1 = fa=> {
        return fakeAsync((httpService: HttpService, mockBackend: MockBackend) => {
            fa(httpService, mockBackend);
            tick(apiTimeout); 
        });
    }
    
    it('should make get request', inject([HttpService, MockBackend], fakeAsync1((httpService: HttpService, mockBackend: MockBackend) => {
        
        mockBackend.connections.subscribe(c => {
            expect(c.request.url).toBe(uomUrl);
            let response = new ResponseOptions(responseData);
            c.mockRespond(new Response(response));
        });
       
        const requestOptions = new RequestOptions({ method: RequestMethod.Get, headers: new Headers() });
        httpService.request(uomUrl, requestOptions).subscribe((response) => {
            expect(response.text()).toBe(responseData.body);                     
        }); 

    })));

    it('should make post request with body', inject([HttpService, MockBackend], fakeAsync1((httpService: HttpService, mockBackend: MockBackend) => {
        const requestBody = { id: 1, name: 'name'};
        
        mockBackend.connections.subscribe(c => {
            expect(c.request.url).toBe(uomUrl);
            expect(c.request.method).toBe(RequestMethod.Post);
            let response = new ResponseOptions(responseData);
            c.mockRespond(new Response(response));
        });       
       
        const requestOptions = new RequestOptions({ method: RequestMethod.Post, headers: new Headers(), body: requestBody });
        httpService.request(uomUrl, requestOptions).subscribe((response) => {
             expect(response.text()).toBe(responseData.body);
        });
       
    })));

    it('should make a request with correct headers', inject([HttpService, MockBackend], fakeAsync1((httpService: HttpService, mockBackend: MockBackend) => {
        
        mockBackend.connections.subscribe(c => {
            expect(c.request.url).toBe(uomUrl);
            let response = new ResponseOptions(responseData);
            c.mockRespond(new Response(response));
        });
       
        const requestOptions = new RequestOptions({ method: RequestMethod.Get, headers: new Headers() });
        httpService.request(uomUrl, requestOptions).subscribe((response) => {
            expect(response.text()).toBe(responseData.body);
            verifyHeaders(response);
        });
       
    })));

    it('should make a request with no credentials', inject([HttpService, MockBackend], fakeAsync1((httpService: HttpService, mockBackend: MockBackend) => {
        
        mockBackend.connections.subscribe(c => {
            expect(c.request.url).toBe(managerUrl);
            let response = new ResponseOptions(responseData);
            c.mockRespond(new Response(response));
        });
       
        const requestOptions = new RequestOptions({ method: RequestMethod.Get, headers: new Headers() });
        httpService.request(managerUrl, requestOptions).subscribe((response) => {
            expect(response.text()).toBe(responseData.body);
            verifyHeaders(response, false);
        });
       
    })));

    it('should make a request with additional authorization headers', inject([HttpService, MockBackend], fakeAsync1((httpService: HttpService, mockBackend: MockBackend) => {
        
        mockBackend.connections.subscribe(c => {
            expect(c.request.url).toBe(uomUrl);
            let response = new ResponseOptions(responseData);
            c.mockRespond(new Response(response));
        });
       
        const requestOptions = new RequestOptions({ method: RequestMethod.Get, headers: new Headers() });
        httpService.request(uomUrl, requestOptions).subscribe((response) => {
            expect(response.text()).toBe(responseData.body);
            verifyHeaders(response, true, true);
        });
       
    })));
    
    let error, source, ob, authenticationServiceSpy, authorizationServiceSpy;    
    function initializeRetry(){
      error = { status: 401 }
      source = { }
      ob = Observable.of(true);
      (<any>ob).source = source;
      authenticationServiceSpy = jasmine.createSpyObj('AuthenticationService', ['logout', 'refreshAuth']);
      authorizationServiceSpy = jasmine.createSpyObj('AuthorizationService', ['getAuthCode']);

      return new HttpService(
        jasmine.createSpyObj('ConnectionBackend', ['dummy']), 
        jasmine.createSpyObj('RequestOptions', ['dummy']),         
        jasmine.createSpyObj('ClientConfigService', ['value']),
        authenticationServiceSpy,
        authorizationServiceSpy,
        jasmine.createSpyObj('Window', ['dummy'])
      )      
   }

   it('should retry if status is 401 and not retried', async(() => { 
      // arrange 
      const httpService = initializeRetry()

      // act
      httpService.getRetry(error, ob)
    
      // assert 
      expect(source.retried).toBe(true)
      expect(authenticationServiceSpy.refreshAuth).toHaveBeenCalled()
      expect(authorizationServiceSpy.getAuthCode).toHaveBeenCalled()
    }));

    it('should not retry if status is 401 and already retried', async(() => { 
      // arrange 
      const httpService = initializeRetry()
      source.retried = true

      // act
      const result = httpService.getRetry(error, ob)
    
      // assert 
      expect(result).toEqual(Observable.empty())
      expect(authenticationServiceSpy.logout).toHaveBeenCalled()
    }));

    it('should not retry if status is not 401', async(() => { 
      // arrange
      const httpService = initializeRetry()
      error.status = 403;

      // act
      const result = httpService.getRetry(error, ob)
    
      // assert 
      expect(result).toEqual(Observable.throw(error))
    }));

});