import { Component, Input, Output, EventEmitter, OnInit, Directive } from '@angular/core';
import { html } from './modal.component.html';

declare var $: any;

@Component({
    selector: 'modal-comp',
    template: html
})
export class ModalComponent implements OnInit{
    @Input() title: string;
    @Input() message: string;
    @Output() close: EventEmitter<boolean> = new EventEmitter<boolean>();

    private static MODAL_ID = '#appModal';

    constructor(){ }

    ngOnInit(){
        $(ModalComponent.MODAL_ID).modal({ show: false})
    }

    show(){
        $(ModalComponent.MODAL_ID).modal('show')
    }

    closeModal(deactivate: boolean){
        $(ModalComponent.MODAL_ID).modal('hide')
        this.close.emit(deactivate)
    }
}