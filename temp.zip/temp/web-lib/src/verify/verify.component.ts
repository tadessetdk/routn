import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'verify',
    template: '<div class="spinner-container"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i></div>'
})
export class VerifyComponent implements OnInit{   
      
    constructor(private router: Router) {}

    ngOnInit(){
         this.router.navigate(['/']);
    }  
}