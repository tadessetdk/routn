/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterLinkStubDirective, RouterOutletStubComponent } from '../test-stubs';

import { VerifyComponent } from './verify.component';

describe('VerifyComponent', () => {
  let routerMock;

  beforeEach(() => {
    routerMock = jasmine.createSpyObj('Router', ['navigate']);
 
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      declarations: [ VerifyComponent, RouterLinkStubDirective, RouterOutletStubComponent ],    
      providers: [ 
        { provide: Router, useValue: routerMock }
      ],
    });
    TestBed.compileComponents();
  });

  it('should create the app', async(() => { 
    // act 
    const fixture = TestBed.createComponent(VerifyComponent);
    const app = fixture.debugElement.componentInstance;

    // assert 
    expect(app).toBeTruthy();
  }));

 it('should navigate to root', async(() => { 
    // act 
    const fixture = TestBed.createComponent(VerifyComponent);
    const app = fixture.debugElement.componentInstance;
    app.ngOnInit();

    // assert 
    expect(routerMock.navigate).toHaveBeenCalledWith(['/']);
  }));

});
