/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { CanDeactivateGuard, CanComponentDeactivate } from './canDeactivateGuard';

describe('CanDeactivateGuard', () => {
   
    it('creates CanDeactivateGuard object', async(() => {
        const guard = new CanDeactivateGuard();
        expect(guard).toBeTruthy();
    }));

    it('can deactivate component', async(() => {
        const guard = new CanDeactivateGuard();
        const compMock = jasmine.createSpyObj('CanDeactivateGuard', ['canDeactivate']);
        compMock.canDeactivate.and.returnValue(true);    
        const result = guard.canDeactivate(compMock);
        expect(result).toBe(true); 
        expect(compMock.canDeactivate).toHaveBeenCalled(); 
    }));

});
