/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { Observable } from 'rxjs';

import { AuthGuard } from './authGuard';
import { GET_AUTH_TOKEN, GET_AUTHZ_TOKEN } from '../store/auth/auth.actions';

describe('AuthGuard', () => {
    let hasUserAccess$: Observable<boolean> = Observable.of(true);

    beforeEach(() => {
        TestBed.configureTestingModule({
        declarations: [
        
        ],
        });
        TestBed.compileComponents();
    });

    it('creates AuthGuard object', async(() => {
        let storeMock = jasmine.createSpyObj('Store', ['select', 'dispatch']);
        const routerMock = jasmine.createSpyObj('Router', ['navigate'])
        const guard = new AuthGuard(storeMock, routerMock);
        guard.hasUserAccess$ = hasUserAccess$;
        expect(guard).toBeTruthy();
    }));

    it('dispatch auth actions when user is not authenticated', async(() => {
        let storeMock = jasmine.createSpyObj('Store', ['select', 'dispatch']);
        const isAuthenticated$ = Observable.of(false);
        storeMock.select.and.returnValue(isAuthenticated$);    
        const routerMock = jasmine.createSpyObj('Router', ['navigate'])
        const guard = new AuthGuard(storeMock, routerMock);
        guard.hasUserAccess$ = hasUserAccess$;
        guard.canActivate().subscribe(can=> {
            expect(can).toBe(false);            
            expect(storeMock.dispatch.calls.mostRecent().args[0]).toEqual({ type: GET_AUTH_TOKEN })
        });       
    }));

    it('redirect user to error page when no access', async(() => {
        let storeMock = jasmine.createSpyObj('Store', ['select', 'dispatch']);
        storeMock.select.and.returnValue(Observable.of(true))
        const routerMock = jasmine.createSpyObj('Router', ['navigate'])
        const guard = new AuthGuard(storeMock, routerMock);
        guard.hasUserAccess$ =  Observable.of(false);
        guard.canActivate().subscribe(can=> {
            expect(can).toBe(false);
            expect(routerMock.navigate).toHaveBeenCalledWith(['/error/norole']);
        });   
    }));

});
