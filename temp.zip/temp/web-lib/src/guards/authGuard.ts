import { Router, CanActivate } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import * as fromRoot from '../store';
import { GET_AUTH_TOKEN, GET_AUTHZ_TOKEN } from '../store/auth/auth.actions';
import { IAuthZ } from '../store/auth/auth.models';

export class AuthGuard implements CanActivate{
    private isAuthenticated$: Observable<boolean>;    
    private authCode$: Observable<IAuthZ>;
    public hasUserAccess$: Observable<boolean>;

    constructor(protected store: Store<fromRoot.IAppState>, protected router: Router){
        this.isAuthenticated$ = store.select(fromRoot.isAuthenticated);
        this.authCode$ = store.select(fromRoot.getAuthCode);
    }

    canActivate(): Observable<boolean> {
        return this.isAuthenticated$.switchMap(isAuthenticated=> {
            if(!isAuthenticated){
                this.store.dispatch({ type: GET_AUTH_TOKEN });             
                return Observable.of(false);
            } else {
                return this.hasUserAccess$.switchMap(hasAccess=> {
                    if(!hasAccess) {
                        this.router.navigate(['/error/norole']);
                        return Observable.of(false);
                    } else {                        
                        return this.authCode$.switchMap(authz=>{
                            if(!authz.code){
                                this.store.dispatch({ type: GET_AUTHZ_TOKEN })
                            }                            
                            return Observable.of(true)
                        });
                    }
                });
            }
        });
    }

}