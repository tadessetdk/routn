/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { Guid } from './guid';

describe('Guid', () => {
   
    it('creates a Guid from a String', async(() => {
        const strGuid = "f50b14e0-10a1-48d6-8635-e36158b96e81"
        const guid = new Guid(strGuid);
        expect(guid).toBeTruthy();
        expect(guid.toString()).toBe(strGuid);
    }));

    it('creates a Guid from a String', async(() => {
        const guidRegex = /^[0-9a-f]{8}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{12}$/i
        const guid = Guid.NewGuid();
        expect(guid).toBeTruthy();
        expect(guidRegex.test(guid.toString())).toBe(true);
    }));

});