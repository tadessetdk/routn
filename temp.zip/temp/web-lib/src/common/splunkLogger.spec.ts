/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { splunkLogger } from './splunkLogger';

describe('splunkLogger', () => {
   
    let settings = { logSource: 'logSource', token: 'token', serverUri: 'serverUri' };
    let splunkLoggerObj;
    let sendSpy, flushSpy;
    
    beforeEach(() => {        
        splunkLoggerObj = new splunkLogger(settings);
        sendSpy = spyOn(splunkLoggerObj.logger, 'send');
        flushSpy = spyOn(splunkLoggerObj.logger, 'flush');
    });

    it('should create a splunkLogger', async(() => {
        expect(splunkLoggerObj.logMetadata).toEqual({ source: settings.logSource, sourcetype: "browser:event" })
        expect(splunkLoggerObj.logger).toBeDefined();
        expect(typeof(splunkLoggerObj.logger.error)).toBe('function');
    }));

    it('should send and flush messages', async(() => {
        // arrange 
        const messages = [{ level: 1, msg: 'test1' }, { level: 2, msg: 'test2' }]

        // act         
        splunkLoggerObj.batchLog(messages)

        // assert 
        expect(sendSpy).toHaveBeenCalledTimes(2);
        expect(flushSpy).toHaveBeenCalledWith(jasmine.any(Function));
    }));

    it('should not send or flush if there are no messages', async(() => {
        // act         
        splunkLoggerObj.batchLog([])

        // assert 
        expect(sendSpy).not.toHaveBeenCalled();
        expect(flushSpy).not.toHaveBeenCalled();
    }));

});