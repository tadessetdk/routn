import { ISplunkSettings } from './config';
var SplunkLogger = require('splunk-logging').Logger;

export class splunkLogger {  
    logMetadata: { source: string; sourcetype: string };
    logger: any;

    constructor(config: ISplunkSettings){      
        this.logMetadata = {
            source: config.logSource,
            sourcetype: "browser:event"
        };

        this.logger = new SplunkLogger({
            token: config.token,
            url: config.serverUri,
            maxBatchCount: 0,
            maxRetries: 1
        });

        this.logger.error = function(err, context){
            console.log("Splunk error", err);
        }
    }

    batchLog(messages: Array<any>){
        if(!messages.length) {
            console.log('No log messages');
            return;
        }
      
        messages.forEach(m => { 
            this.logger.send({
                message: m,
                severity: m.level,
                metadata: this.logMetadata
            });            
        });

        this.logger.flush(function(err, resp, body){
            err && console.log('Splunk error', body);
        });
    } 
}