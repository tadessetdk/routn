
export interface ISplunkSettings{
    token: string;
    serverUri: string;
    logSource: string;
}

export interface IClientSettings{
    version: string;
    appId: string;
    api: {
        endpoints: any;
        timeout: number | Date;
    };    
    aadSettings: {
        clientId: string;
        anonymousEndpoints: Array<any>;
        endpoints: any;
        tenant: string;
        sessionTimeout: number;
    };
    loggingConfig: any;
}

export interface IConfigSettings{
    splunkSettings: ISplunkSettings;
    clientSettings: IClientSettings;
    cdnUrl: string;
}