import { ActionReducer, Action } from '@ngrx/store';

import * as fromModels from './auth.models';
import { IAuthInfo } from '../../services/authModels';
import { GET_AUTH_TOKEN_SUCCESS, GetAuthTokenCompleteAction } from './auth.actions';

export interface State{
    auth: fromModels.IAuth;
}

const defaultValue: State = {
    auth: {
        userInfo: null
    }
};

export const reducer : ActionReducer<State> = 
(state: State = defaultValue, action: GetAuthTokenCompleteAction)=>{
    switch(action.type){
        case GET_AUTH_TOKEN_SUCCESS:
            return { 
                auth: Object.assign({}, action.payload)
            };

        default:
            return state;
    }
}

export const isAuthenticated = (state: State)=> !!state.auth.userInfo;
export const getUserInfo = (state: State)=> state.auth.userInfo;
