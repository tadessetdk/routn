import { IAuthInfo } from '../../services/authModels';

export interface IAuth{
    userInfo?: IAuthInfo;
}

export interface IAuthZ{
    code: string;
}