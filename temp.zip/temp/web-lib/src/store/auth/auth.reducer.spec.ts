/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { Action } from '@ngrx/store';

import { IAuth } from './auth.models';
import { GET_AUTH_TOKEN_SUCCESS } from './auth.actions';
import { State, reducer, getUserInfo, isAuthenticated } from './auth.reducer';

describe('auth.reducers', () => {
    
    const UPDATER = 'UPDATER'

    const auth: IAuth = {
        userInfo: { 
                userName: 'userName',  name: 'name1', givenName: 'givenName', familyName: 'familyName', expire: 33434, objectId: 'objectId', tenantId: 'tenantId',
                groups: [ 'group1', 'group2' ],
                roles: [ UPDATER ],
        }
    };  
    
    const state: State = { auth: null }

    it('get auth token success action returns an auth state with Updater role',  async(() => {
        // act  
        const payload = Object.assign({}, auth)       
        const newState: State = reducer(state, { type: GET_AUTH_TOKEN_SUCCESS, payload: payload });

        // assert            
        expect(newState).toEqual({ auth: payload });
        expect(isAuthenticated(newState)).toBe(true, 'user is authenticated');
        expect(getUserInfo(newState)).toEqual(auth.userInfo);
    }));  

});