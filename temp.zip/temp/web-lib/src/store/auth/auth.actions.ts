import { Action } from '@ngrx/store';

import { IAuth, IAuthZ } from './auth.models';

export const GET_AUTH_TOKEN = 'GET_AUTH_TOKEN';
export const GET_AUTHZ_TOKEN = 'GET_AUTHZ_TOKEN';
export const GET_AUTH_TOKEN_SUCCESS = 'GET_AUTH_TOKEN_SUCCESS';
export const GET_AUTH_TOKEN_FAIL = 'GET_AUTH_TOKEN_FAIL';
export const GET_AUTHZ_TOKEN_SUCCESS = 'GET_AUTHZ_TOKEN_SUCCESS';
export const GET_AUTHZ_TOKEN_FAIL = 'GET_AUTHZ_TOKEN_FAIL';

export class GetAuthTokenAction implements Action {
    type = GET_AUTH_TOKEN;
    constructor(public payload: IAuth) { }
}

export class GetAuthTokenCompleteAction implements Action {
    type = GET_AUTH_TOKEN_SUCCESS;
    constructor(public payload: IAuth) { }
}

export class GetAuthTokenFailAction implements Action {
    type = GET_AUTH_TOKEN_FAIL;
    constructor(public payload: string) { }
}

export class GetAuthZTokenAction implements Action {
    type = GET_AUTHZ_TOKEN;
    constructor(public payload: IAuthZ) { }
}

export class GetAuthZTokenCompleteAction implements Action {
    type = GET_AUTHZ_TOKEN_SUCCESS;
    constructor(public payload: IAuthZ) { }
}

export class GetAuthZTokenFailAction implements Action {
    type = GET_AUTHZ_TOKEN_FAIL;
    constructor(public payload: string) { }
}