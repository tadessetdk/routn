/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { IAuth, IAuthZ } from './auth.models';
import { 
       GET_AUTH_TOKEN, GET_AUTH_TOKEN_SUCCESS, GET_AUTH_TOKEN_FAIL, GET_AUTHZ_TOKEN, GET_AUTHZ_TOKEN_SUCCESS, GET_AUTHZ_TOKEN_FAIL,
       GetAuthTokenAction, GetAuthTokenCompleteAction, GetAuthTokenFailAction, GetAuthZTokenAction, GetAuthZTokenCompleteAction, GetAuthZTokenFailAction
     } from './auth.actions';

describe('auth.actions', () => {
    const auth: IAuth = {
        userInfo: { 
                userName: 'userName',  name: 'name1', givenName: 'givenName', familyName: 'familyName', expire: 33434, objectId: 'objectId', tenantId: 'tenantId',
                groups: [ 'group1', 'group2' ],
                roles: [ 'role1', 'role2', 'role3' ],
        }
    };

    const authz: IAuthZ = {
        code: 'code1'
    };

    it('creates GetAuthTokenAction',  async(() => {
        // act
        const action = new GetAuthTokenAction(auth);

        // assert            
        expect(action.payload).toEqual(auth);   
        expect(action.type).toEqual(GET_AUTH_TOKEN);   
    }));  

    it('creates GetAuthTokenCompleteAction',  async(() => {
        // arrange
        const payload = { auth: auth }

        // act
        const action = new GetAuthTokenCompleteAction(payload);

        // assert            
        expect(action.payload).toEqual(payload);   
        expect(action.type).toEqual(GET_AUTH_TOKEN_SUCCESS);   
    }));  

    it('creates GetAuthTokenFailAction',  async(() => {
        // arrange
        const payload = 'error message';

        // act
        const action = new GetAuthTokenFailAction(payload);

        // assert            
        expect(action.payload).toEqual(payload);   
        expect(action.type).toEqual(GET_AUTH_TOKEN_FAIL);   
    }));  

    it('creates GetAuthZTokenAction',  async(() => {
        // act
        const action = new GetAuthZTokenAction(authz);

        // assert            
        expect(action.payload).toEqual(authz);   
        expect(action.type).toEqual(GET_AUTHZ_TOKEN);   
    }));  

    it('creates GetAuthZTokenCompleteAction',  async(() => {
        // act
        const action = new GetAuthZTokenCompleteAction(authz);

        // assert            
        expect(action.payload).toEqual(authz);   
        expect(action.type).toEqual(GET_AUTHZ_TOKEN_SUCCESS);   
    }));  

    it('creates GetAuthZTokenFailAction',  async(() => {
        // arrange
        const payload = 'error message';

        // act
        const action = new GetAuthZTokenFailAction(payload);

        // assert            
        expect(action.payload).toEqual(payload);   
        expect(action.type).toEqual(GET_AUTHZ_TOKEN_FAIL);   
    }));  

});