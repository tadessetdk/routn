import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Http, Response } from '@angular/http';
import { Effect, Actions } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { IAuth } from './auth.models';
import { GET_AUTH_TOKEN, GET_AUTHZ_TOKEN, GetAuthTokenCompleteAction, GetAuthZTokenCompleteAction, GetAuthTokenFailAction, GetAuthZTokenFailAction } from './auth.actions';

import { ClientConfigService } from '../../services/clientConfigService';
import { AuthenticationService } from '../../services/authenticationService';
import { AuthorizationService } from '../../services/authorizationService';
import { IAuthInfo } from '../../services/authModels';

@Injectable()
export class AuthEffects{
    constructor(
        private actions$: Actions, 
        private authenticationService: AuthenticationService, 
        private authorizationService: AuthorizationService
    ){ }

    @Effect() getAuth$ = this.actions$
        .ofType(GET_AUTH_TOKEN)
        .switchMap((action: Action) => {
            return this.authenticationService.getAuthInfo()
                .switchMap((auth: IAuthInfo)=> {
                    return Observable.of(new GetAuthTokenCompleteAction({ userInfo: auth }))
                })
                .catch((error: Response)=> 
                     Observable.of(new GetAuthTokenFailAction(error.statusText))
                );
        });

    @Effect() getAuthZ$ = this.actions$
        .ofType(GET_AUTHZ_TOKEN)
        .switchMap((action: Action) => {
            return this.authorizationService.getAuthCode()
                .switchMap((code: string)=>
                    Observable.of(new GetAuthZTokenCompleteAction({ code: code }))
                )
                .catch((error: Response)=> 
                     Observable.of(new GetAuthZTokenFailAction(error.statusText))
                );
        });
}