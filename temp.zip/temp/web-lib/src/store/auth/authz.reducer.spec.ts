/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { Action } from '@ngrx/store';

import { IAuthZ } from './auth.models';
import { GET_AUTHZ_TOKEN_SUCCESS } from './auth.actions';
import { State, reducer, getAuth } from './authz.reducer';

describe('auth.reducers', () => {
    
    const authz: IAuthZ = { code: 'code' };

    const state: State = { auth: null }

    it('get authorization token succsess action returns an auth code',  async(() => {
        // act
        const newState: State = reducer(state, { type: GET_AUTHZ_TOKEN_SUCCESS, payload: authz });

        // assert            
        expect(newState).toEqual({ auth: authz });
        expect(getAuth(newState)).toEqual(authz);
    })); 

});