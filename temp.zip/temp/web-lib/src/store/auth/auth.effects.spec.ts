/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { Effect, Actions } from '@ngrx/effects';
import { Observable } from 'rxjs';

import { LogCompleteAction, LogFailAction } from '../logging/logging.actions';
import { GET_AUTH_TOKEN, GET_AUTHZ_TOKEN, GetAuthTokenCompleteAction, GetAuthTokenFailAction, GetAuthZTokenCompleteAction, GetAuthZTokenFailAction } from './auth.actions';
import { AuthEffects } from './auth.effects';

describe('auth.effects', () => {
    let effect: AuthEffects;
    
    let switchMapSpyAuthOuter;
    let switchMapSpyAuthzOuter;
    let actionsSpyObj;

    let switchMapSpyAuth;
    let catchSpyAuth;    
    let authenticationServiceSpyObj;

    let switchMapSpyAuthz;
    let catchSpyAuthz;    
    let authorizationServiceSpyObj;
 
    const action = { }

    beforeEach(() => {
        actionsSpyObj = jasmine.createSpyObj('Actions', ['ofType']);
        switchMapSpyAuthOuter = jasmine.createSpy('switchMap');
        switchMapSpyAuthzOuter = jasmine.createSpy('switchMap');
        actionsSpyObj.ofType.and.callFake(arg=> {
            return { switchMap: ((arg === GET_AUTH_TOKEN) && switchMapSpyAuthOuter) || switchMapSpyAuthzOuter }
        });

        switchMapSpyAuth = jasmine.createSpy('switchMap');
        catchSpyAuth = jasmine.createSpy('catch');
        switchMapSpyAuth.and.returnValue({ catch: catchSpyAuth });
        authenticationServiceSpyObj = jasmine.createSpyObj('AuthenticationService', ['getAuthInfo'])
        authenticationServiceSpyObj.getAuthInfo.and.returnValue({ switchMap: switchMapSpyAuth });          

        switchMapSpyAuthz = jasmine.createSpy('switchMap');
        catchSpyAuthz = jasmine.createSpy('catch');
        switchMapSpyAuthz.and.returnValue({ catch: catchSpyAuthz });
        authorizationServiceSpyObj = jasmine.createSpyObj('authorizationService', ['getAuthCode'])
        authorizationServiceSpyObj.getAuthCode.and.returnValue({ switchMap: switchMapSpyAuthz });             

        effect = new AuthEffects(actionsSpyObj, authenticationServiceSpyObj, authorizationServiceSpyObj)
    })

    it('get auth action initialized',  async(() => {
        // assert          
        expect(actionsSpyObj.ofType.calls.allArgs()).toEqual([[GET_AUTH_TOKEN],[GET_AUTHZ_TOKEN]]);
        expect(switchMapSpyAuthOuter).toHaveBeenCalledWith(jasmine.any(Function));  
    })); 

    it('get auth request has been made',  async(() => {
        // act 
        switchMapSpyAuthOuter.calls.mostRecent().args[0](action)

        // assert          
        expect(authenticationServiceSpyObj.getAuthInfo).toHaveBeenCalled();  
        expect(switchMapSpyAuth).toHaveBeenCalledWith(jasmine.any(Function));  
        expect(catchSpyAuth).toHaveBeenCalledWith(jasmine.any(Function));          
    })); 

     it('get authz request has been made',  async(() => {
        // act 
        switchMapSpyAuthzOuter.calls.mostRecent().args[0](action)

        // assert          
        expect(authorizationServiceSpyObj.getAuthCode).toHaveBeenCalled();  
        expect(switchMapSpyAuthz).toHaveBeenCalledWith(jasmine.any(Function));  
        expect(catchSpyAuthz).toHaveBeenCalledWith(jasmine.any(Function));  
    })); 

     it('get auth http request has succeeded',  async(() => {
        // arrange
        const auth = { }

        // act 
        switchMapSpyAuthOuter.calls.mostRecent().args[0](action)
        const result = switchMapSpyAuth.calls.mostRecent().args[0](auth)

        // assert     
        expect(result.value.constructor.name).toBe(GetAuthTokenCompleteAction.name)
    })); 

     it('get auth http request has failed',  async(() => {
        // arrange
        const response = { statusText: 'failed' }

        // act 
        switchMapSpyAuthOuter.calls.mostRecent().args[0](action)
        const result = catchSpyAuth.calls.mostRecent().args[0](response)

        // assert          
        expect(result.value.constructor.name).toBe(GetAuthTokenFailAction.name)
    })); 

     it('get authz http request has succeeded',  async(() => {
        // arrange
        const auth = { }

        // act 
        switchMapSpyAuthzOuter.calls.mostRecent().args[0](action)
        const result = switchMapSpyAuthz.calls.mostRecent().args[0](auth)

        // assert     
        expect(result.value.constructor.name).toBe(GetAuthZTokenCompleteAction.name)
    })); 

     it('get authz http request has failed',  async(() => {
        // arrange
        const response = { statusText: 'failed' }

        // act 
        switchMapSpyAuthzOuter.calls.mostRecent().args[0](action)
        const result = catchSpyAuthz.calls.mostRecent().args[0](response)

        // assert          
        expect(result.value.constructor.name).toBe(GetAuthZTokenFailAction.name)
    })); 

});