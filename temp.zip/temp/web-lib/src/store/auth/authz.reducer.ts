import { ActionReducer, Action } from '@ngrx/store';

import { IAuthZ } from './auth.models';
import { GET_AUTHZ_TOKEN_SUCCESS, GetAuthZTokenCompleteAction } from './auth.actions';

export interface State{
    auth: IAuthZ;
}

const defaultValue: State = {
    auth: {
        code: ''
    }
};

export const reducer : ActionReducer<State> = 
(state: State = defaultValue, action: GetAuthZTokenCompleteAction)=>{
    switch(action.type){
        case GET_AUTHZ_TOKEN_SUCCESS:
            return { 
                auth: Object.assign({}, action.payload) 
            };

        default:
            return state;
    }
}

export const getAuth = (state: State)=> state.auth;