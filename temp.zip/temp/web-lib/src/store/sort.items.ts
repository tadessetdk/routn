import {SortInfo} from './shared.models';

export function getSortedItems<T>(state: { sortInfo: SortInfo }, listName: string, field: string, newSortInfo: SortInfo): T[]{ 
    var asc = field === state.sortInfo.field ? !state.sortInfo.asc : true;     
    newSortInfo.field = field;
    newSortInfo.asc = asc;

    return state[listName].slice().sort((o1, o2)=> {
        const normalize = o=> (o[field] || '').toLowerCase();
        const v1 = normalize(o1), v2 = normalize(o2);
        return asc && ((v1 < v2 && -1) ||(v1 > v2 && 1) || 0) || ((v2 < v1 && -1) ||(v2 > v1 && 1) || 0);
    });
}