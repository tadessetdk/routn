/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { LOGGING_SUCCESS, LOGGING_FAIL, LogCompleteAction, LogFailAction } from './logging.actions';

describe('logging.actions', () => {
    const response: any = {  };

    it('creates LogCompleteAction',  async(() => {
        // act
        const action = new LogCompleteAction(response);

        // assert            
        expect(action.payload).toEqual(response);   
        expect(action.type).toEqual(LOGGING_SUCCESS);   
    }));  

    it('creates LogFailAction',  async(() => {
        // act
        const action = new LogFailAction(response);

        // assert            
        expect(action.payload).toEqual(response);   
        expect(action.type).toEqual(LOGGING_FAIL);   
    }));  

});