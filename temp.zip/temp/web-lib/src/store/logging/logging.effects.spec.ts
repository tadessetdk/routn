/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { Effect, Actions } from '@ngrx/effects';
import { Observable } from 'rxjs';

import { LOGGING_SUCCESS, LOGGING_FAIL, LogCompleteAction, LogFailAction } from './logging.actions';
import { LoggingEffects } from './logging.effects';

describe('logging.effects', () => {
    let effect: LoggingEffects;
    
    let actionsSpyObj;
    let mapSpySuccess;
    let mapSpyError;
    let switchMapSpySuccess;
    let switchMapSpyError;    

    let loggerServiceSpyObj;
 
    const appId = 'appId';
    const sessionId = 'sessionId';
    const correlationId = 'correlationId';
    let response;

    function initResponse(){
        response = {
            request: {
                headers: {
                    get: jasmine.createSpy('get')
                },
                timestamp: 1233
            },
            statusText: 'status',
            url: 'url',          
            status: 200,
        }

        response.request.headers.get.and.callFake(arg=> ((arg === 'X-App-ID') && appId) || ((arg === 'X-Session-ID') && sessionId) || correlationId)           
    }

    beforeEach(() => {
        initResponse();

        actionsSpyObj = jasmine.createSpyObj('Actions', ['ofType']);
        mapSpySuccess = jasmine.createSpy('map');
        mapSpyError = jasmine.createSpy('map');
        switchMapSpySuccess = jasmine.createSpy('switchMap');
        switchMapSpyError = jasmine.createSpy('switchMap');

        actionsSpyObj.ofType.and.callFake(arg=> {
            return { map: ((arg === LOGGING_SUCCESS) && mapSpySuccess) || mapSpyError }
        });

        mapSpySuccess.and.returnValue({ switchMap: switchMapSpySuccess });
        mapSpyError.and.returnValue({ switchMap: switchMapSpyError });
    
        loggerServiceSpyObj = jasmine.createSpyObj('LoggerService', ['info', 'error']);
        loggerServiceSpyObj.info.and.returnValue({ switchMap: switchMapSpySuccess });     
        loggerServiceSpyObj.error.and.returnValue({ switchMap: switchMapSpyError });   
     
        effect = new LoggingEffects(actionsSpyObj, loggerServiceSpyObj)
    })

    it('logging action initialized',  async(() => {
        // assert          
        expect(actionsSpyObj.ofType.calls.allArgs()).toEqual([[LOGGING_SUCCESS],[LOGGING_FAIL]]);
        expect(mapSpySuccess).toHaveBeenCalledWith(jasmine.any(Function));  
        expect(mapSpyError).toHaveBeenCalledWith(jasmine.any(Function));  
        expect(switchMapSpySuccess).toHaveBeenCalledWith(jasmine.any(Function));  
        expect(switchMapSpyError).toHaveBeenCalledWith(jasmine.any(Function));  
    })); 

    it('success log has been made',  async(() => {        
        // act 
        const result = switchMapSpySuccess.calls.mostRecent().args[0](response)

        // assert              
        expect(loggerServiceSpyObj.info).toHaveBeenCalledWith(jasmine.objectContaining({
            appId: appId,
            sessionId: sessionId,
            correlationId: correlationId,
            message: response.statusText,
            requestUri: response.url,          
            statusCode: response.status
        }));          
        expect(response.request.headers.get).toHaveBeenCalledTimes(3);
        expect(result.constructor.name).toBe('EmptyObservable');
    })); 

    it('error log has been made',  async(() => {        
        // act 
        const result = switchMapSpyError.calls.mostRecent().args[0](response)

        // assert              
        expect(loggerServiceSpyObj.error).toHaveBeenCalledWith(jasmine.objectContaining({
            appId: appId,
            sessionId: sessionId,
            correlationId: correlationId,
            message: response.statusText,
            requestUri: response.url,          
            statusCode: response.status
        }));          
        expect(response.request.headers.get).toHaveBeenCalledTimes(3);
        expect(result.constructor.name).toBe('EmptyObservable');
    })); 
});