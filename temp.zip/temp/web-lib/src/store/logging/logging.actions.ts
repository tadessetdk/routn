import { Action } from '@ngrx/store';
import { Response } from '@angular/http';

export const LOGGING_SUCCESS = 'LOGGING_SUCCESS';
export const LOGGING_FAIL = 'LOGGING_FAIL';

export class LogCompleteAction implements Action {
    type = LOGGING_SUCCESS;
    constructor(public payload: Response = null) { }
}

export class LogFailAction implements Action {
    type = LOGGING_FAIL;
    constructor(public payload: Response | string) { }
}