import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Http, Request, Response, RequestOptionsArgs } from '@angular/http';
import { Effect, Actions } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { LoggerService, ILogEvent } from '../../services/loggerService';
import { LOGGING_SUCCESS, LOGGING_FAIL } from './logging.actions';

@Injectable()
export class LoggingEffects {
    constructor(private actions$: Actions, private loggerService: LoggerService){ }

    @Effect() success$ = this.actions$
        .ofType(LOGGING_SUCCESS)
        .map(action=> action.payload)
        .switchMap((response: Response) => {            
            this.loggerService.info(this.getLogEvent(response));
            return Observable.empty();
        });

    @Effect() errors$ = this.actions$
        .ofType(LOGGING_FAIL)
        .map(action=> action.payload)
        .switchMap((error: Response) => {            
            this.loggerService.error(this.getLogEvent(error));
            return Observable.empty();
        });
  
    private getLogEvent(response: Response): ILogEvent{
        const request = <RequestOptionsArgs>(<any>response).request;
        const headers = request && request.headers;
        const latency = (request && (<any>request).timestamp) && (new Date().getTime() - (<any>request).timestamp) || -1;
        return {
            appId: headers && headers.get('X-App-ID') || '',
            sessionId: headers && headers.get('X-Session-ID') || '',
            correlationId: headers && headers.get('X-Correlation-ID') || '',
            message: response.statusText,
            requestUri: response.url,          
            statusCode: response.status,
            latency: latency
        }
    }
}