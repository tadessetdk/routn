import { ActionReducer } from '@ngrx/store';

import { IAuth, IAuthZ } from './auth/auth.models';
import { IAuthInfo } from '../services/authModels';

import * as fromAuth from './auth/auth.reducer';
import * as fromAuthZ from './auth/authz.reducer';

export { LoggingEffects } from './logging/logging.effects';
export { AuthEffects } from './auth/auth.effects';
export { LogCompleteAction, LogFailAction  } from './logging/logging.actions'

// app state
export interface IAppState{
    auth: fromAuth.State;
    authz: fromAuthZ.State;
}

// auth selectors
export const isAuthenticated = (state: IAppState)=> fromAuth.isAuthenticated(state.auth);
export const getUserInfo = (state: IAppState)=> fromAuth.getUserInfo(state.auth);
export const getAuthCode = (state: IAppState)=> fromAuthZ.getAuth(state.authz);

export const authReducer = fromAuth.reducer
export const authzReducer = fromAuthZ.reducer

export { IAuth, IAuthZ }
export { IAuthInfo }
export { SortInfo } from './shared.models'
export { getSortedItems } from './sort.items'