/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';

import { getSortedItems } from './sort.items';
import { SortInfo } from './shared.models';

describe('sort.items', () => {
    
    const state = { 
        sortInfo: { field: name, asc: true },
        organizations: [
            {
                id: 1, 
                name: 'name1',
                location: 'location1'
            },
            {
                id: 0, 
                name: 'name0',
                location: 'location0'
            },
            {
                id: 2, 
                name: 'name2',
                location: 'location2'
            }
        ]
    };
    
    it('sorts items by field ascending (default sort direction)',  async(() => {
        // arrange
        let newSortInfo: SortInfo = { field: '', asc: false };

        // act
        const results: any = getSortedItems(<any>state, 'organizations', 'name', newSortInfo);

        // assert     
        expect(results[0].name).toBe('name0');     
        expect(results[1].name).toBe('name1');     
        expect(results[2].name).toBe('name2');  
        expect(newSortInfo).toEqual({ field: 'name', asc: true });   
    }));  

    it('sorts items by inverting ascending order if sorted again by same field',  async(() => {
        // arrange
        let newSortInfo: SortInfo = { field: '', asc: false };

        // act
        const results1: any = getSortedItems(<any>state, 'organizations', 'name', newSortInfo);
        const results2: any = getSortedItems(<any>{ organizations: results1, sortInfo: newSortInfo}, 'organizations', 'name', newSortInfo);

        // assert     
        expect(results2[0].name).toBe('name2');     
        expect(results2[1].name).toBe('name1');     
        expect(results2[2].name).toBe('name0');  
        expect(newSortInfo).toEqual({ field: 'name', asc: false });      
    }));  

    it('sorts case-insensitive',  async(() => {
        // arrange
        let newSortInfo: SortInfo = { field: '', asc: false };
        state.organizations[0].name = 'NaMe1';
        state.organizations[2].name = 'NaME2';

        // act
        const results: any = getSortedItems(<any>state, 'organizations', 'name', newSortInfo);

        // assert     
        expect(results[0].name).toBe('name0');     
        expect(results[1].name).toBe('NaMe1');     
        expect(results[2].name).toBe('NaME2');  
        expect(newSortInfo).toEqual({ field: 'name', asc: true });   
    }));  

});