export interface SortInfo{
    field: string;
    asc: boolean;
}