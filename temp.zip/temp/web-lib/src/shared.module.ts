import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpModule, RequestOptions, XHRBackend } from '@angular/http';
import { HeaderComponent, HeaderDirectives } from './header/header.component';
import { ModalComponent } from './modal/modal.component';
import { ClientConfigService } from './services/clientConfigService';
import { LoggerService } from './services/loggerService';
import { AuthenticationService } from './services/authenticationService';
import { AuthorizationService } from './services/authorizationService';
import { HttpService } from './services/httpService';
import { CanDeactivateGuard } from './guards/canDeactivateGuard';

@NgModule({
    declarations: [ HeaderComponent, HeaderDirectives, ModalComponent ],
    imports: [ CommonModule, RouterModule, HttpModule ],
    exports: [ HeaderComponent, HeaderDirectives, ModalComponent ],
    providers: [ 
        ClientConfigService, 
        LoggerService,
        HttpService,
        AuthenticationService,
        AuthorizationService,
        CanDeactivateGuard,
        {
            provide: HttpService,
            useFactory: (backend: XHRBackend, options: RequestOptions) => {
                const configService = new ClientConfigService();
                return new HttpService(
                    backend, options, configService, 
                    new AuthenticationService(configService, window), 
                    new AuthorizationService(configService, window), 
                    window
                );
            },
            deps: [XHRBackend, RequestOptions]
        },
        { provide: 'Window', useValue: window }
  ],
})
export class SharedModule {}