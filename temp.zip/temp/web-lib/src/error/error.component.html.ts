export const html = `<div class="container">
    <div class="alert alert-error">Unauthorized access.</div>
</div>`