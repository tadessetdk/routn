import { Component, ChangeDetectionStrategy } from '@angular/core';

import { html } from './error.component.html';

@Component({
    selector: 'error',
    template: html,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ErrorComponent {
 
}


