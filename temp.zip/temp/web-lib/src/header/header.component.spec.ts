/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterLinkStubDirective, RouterOutletStubComponent } from '../test-stubs';
import { Store } from '@ngrx/store';

import { AuthenticationService } from '../services/authenticationService';
import { HeaderComponent } from './header.component';

let authenticationServiceMock;

describe('HeaderComponent', () => {    
  beforeEach(() => {  
    authenticationServiceMock = jasmine.createSpyObj('AuthenticationService', ['logout'])

    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      declarations: [ HeaderComponent, RouterLinkStubDirective, RouterOutletStubComponent ],
      providers: [ 
        { provide: AuthenticationService, useValue: authenticationServiceMock }
      ],
    });
    TestBed.compileComponents();   
  });

  it('should create the component', async(() => { 
    // act 
    const fixture = TestBed.createComponent(HeaderComponent);
    const app = fixture.debugElement.componentInstance;

    // assert 
    expect(app).toBeTruthy();
  }));

 it('should logout the user', async(() => { 
    // act 
    const fixture = TestBed.createComponent(HeaderComponent);
    const app = fixture.debugElement.componentInstance;
    app.logout();

    // assert 
    expect(authenticationServiceMock.logout).toHaveBeenCalled();
  }));

});