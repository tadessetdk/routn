import { Component, Input, Directive } from '@angular/core';

import { AuthenticationService } from '../services/authenticationService';
import { html } from './header.component.html';

@Component({
    selector: 'header-comp',
    template: html
})
export class HeaderComponent{
    @Input() userInfo: any;
    
    constructor(private authenticationService: AuthenticationService){}

    logout() {
        this.authenticationService.logout();
    }
}

@Directive({
  selector: 'header-title'
})
export class HeaderDirectives {}