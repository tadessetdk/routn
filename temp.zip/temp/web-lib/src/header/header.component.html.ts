export const html = `<div class="navbar navbar-static-top">
    <div class="masthead navbar-inner">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" [routerLink]="['/']">
                    <span class="ge-logo">General Electric</span>
                    <span>
                        <ng-content select="header-title"></ng-content>
                    </span>
                </a>
            </div>
            <div *ngIf="userInfo" class="pull-right">
                <div class="user-utilities btn-group pull-left btn-toolbar">
                    <button class="btn dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <span class="user-name">
                            {{userInfo.givenName}}
                        </span>
                        <i class="icon-chevron-down"></i>
                    </button>
                    <ul class="dropdown-menu pull-right profile-menu">
                        <li><a (click)="logout()">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>`