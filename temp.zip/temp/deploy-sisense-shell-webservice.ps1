Param(
    [Parameter(Mandatory = $true)]
    [string] $storageAccountResourceGroup, # e.g. "gehc-healthcareinsights-bi-artifacts",
    [Parameter(Mandatory = $true)]
    [string] $storageAccountName, # e.g. "gehcbiartifactsdev",
    [Parameter(Mandatory = $true)]
    [string] $appVersion, # e.g. "0.1.44",
    [Parameter(Mandatory = $true)]
    [string] $vmHostname, # e.g. "analytics-int-cd7.westus.cloudapp.azure.com",
    [Parameter(Mandatory = $true)]
    [string] $networkSecurityGroupName, # e.g. "SisenseNSG",
    [Parameter(Mandatory = $true)]
    [string] $networkResourceGroupName, # e.g. "GEHC-HealthcareInsights-BI-Network-Dev",
    [Parameter(Mandatory = $true)]
    [string] $winRmHttpNsgRulePriority, # e.g. 100,
    [Parameter(Mandatory = $true)]
    [string] $winRmHttpsNsgRulePriority # e.g. 101
)

./azureRm-login.ps1

# Fail the runbook on any error
$ErrorActionPreference = "Stop"

$securityGroup = Get-AzureRmNetworkSecurityGroup -Name $networkSecurityGroupName -ResourceGroupName $networkResourceGroupName
$rules = Get-AzureRmNetworkSecurityRuleConfig -NetworkSecurityGroup $securityGroup 

# Add Azure security group rules
function addNsgRules($ruleName, $port, $priority) {
    $ruleExists = $false
    foreach ($rule in $rules){
        if ($rule.name -like $ruleName){
            Echo "`n$ruleName rule already exists." 
            $ruleExists = $true
            break
        } 
    }

    if(!$ruleExists) {
        Echo "`nadding security rule $ruleName ..." 
        Get-AzureRmNetworkSecurityGroup -Name $networkSecurityGroupName -ResourceGroupName $networkResourceGroupName | `
        Add-AzureRmNetworkSecurityRuleConfig -Name $ruleName -Direction Inbound -Priority $priority -Access Allow -SourceAddressPrefix '*' `
            -SourcePortRange '*' -DestinationAddressPrefix '*' -DestinationPortRange $port -Protocol 'TCP' | Set-AzureRmNetworkSecurityGroup
    }

}

addNsgRules -ruleName WinRM_HTTP -port 5985 -priority $winRmHttpNsgRulePriority
addNsgRules -ruleName WinRM_HTTPS -port 5986 -priority $winRmHttpsNsgRulePriority
Echo "`n=== Completed Adding NSG Rules ===`n"


# configure VM
$allStorageAccountKeys = Get-AzureRmStorageAccountKey -ResourceGroup $storageAccountResourceGroup -AccountName $storageAccountName
$storageAccountKey = $allStorageAccountKeys.Value[0]

function Get-PSCredential($User, $Password) {
      $SecPass = convertto-securestring -asplaintext -string $Password -force
      $Creds = new-object System.Management.Automation.PSCredential -argumentlist $User,$SecPass
      Return $Creds
}

$sisenseVMCredentialName = 'SisenseVMCredential'
$sisenseVMCredential = Get-AutomationPSCredential -Name $sisenseVMCredentialName
$vmUsername = $sisenseVMCredential.UserName
$vmPassword = $sisenseVMCredential.GetNetworkCredential().Password

$credential = Get-PSCredential -User $vmUsername -Password $vmPassword
$session = New-PSSession -ConnectionUri "https://$vmHostname`:5986" -Credential $credential -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck)

$remoteScript = {
    Param($accountName, $accountKey, $version)

    Set-ExecutionPolicy RemoteSigned

    Import-Module Servermanager
    Import-Module WebAdministration
   
    $storageContext = New-AzureStorageContext -StorageAccountName $accountName -StorageAccountKey $accountKey

    function downloadBlob($container, $blob, $destination) {
        Get-AzureStorageBlobContent -Container $container `
                                    -Blob $blob `
                                    -Context $storageContext `
                                    -Destination $destination
    }

    $wsFolder = ".\sisenseShell"
    if(Test-Path $wsFolder) { 
        Remove-Item $wsFolder -Recurse -Force 
    }
    New-Item $wsFolder -type directory

    downloadBlob -container "applications" -blob "sisense-shell-webservice/$version/sisense-shell-webservice-$version.zip" -destination $wsFolder
    downloadBlob -container "third-party-bins" -blob "node-v7.0.0-x64.msi" -destination $wsFolder
    downloadBlob -container "third-party-bins" -blob "iisnode-full-v0.2.21-x64.msi" -destination $wsFolder
    downloadBlob -container "third-party-bins" -blob "rewrite_amd64.msi" -destination $wsFolder

    $nodeJsMsiPath = Convert-Path "$wsFolder\node-v7.0.0-x64.msi"
    $iisNodeMsiPath = Convert-Path "$wsFolder\iisnode-full-v0.2.21-x64.msi"
    $rewriteMsiPath =  Convert-Path "$wsFolder\rewrite_amd64.msi"
    $zipfilePath =  Convert-Path "$wsFolder\sisense-shell-webservice\$version\sisense-shell-webservice-$version.zip"

    function installFeature($feature){
   
        $featureCheck = Get-WindowsFeature | Where-Object {$_.Name -eq $feature}

        if (($featureCheck.Installed)) {
              Echo "`n$feature already installed"
        } else {
              Echo "`nAdding $feature"
              Install-WindowsFeature $feature -IncludeAllSubFeature
        }

    }

    installFeature -feature "NET-Framework-Core"
    installFeature -feature "Web-Server"
    installFeature -feature "NET-Framework-Features"
    installFeature -feature "NET-Framework-45-ASPNET"
    installFeature -feature "Web-Asp-Net45"
    installFeature -feature "Application-Server"


    function installMSI($path, $name){
     
        $logPath = "C:\$name-install.log"
        Echo "`nInstalling $path ..."

        $MSIArguments = @(
                "/i"
                $path
                "/qn"
                "/norestart"
                "/L*v"
                $logPath
        )

        Start-Process -FilePath "$env:systemroot\system32\msiexec.exe" -Wait -NoNewWindow -ArgumentList $MSIArguments 
    }

    # install Rewrite module
    installMSI -path $rewriteMsiPath -name "RewriteModule"


    # install NodeJS
    & cmd /c "node -v" 2>&1 | Out-Null
    if($LASTEXITCODE -ne 0){
        Echo "`nNodeJS is not installed. Installing now..."
        installMSI -path $nodeJsMsiPath -name "NodeJS"
    } else {
        Echo "`nNodeJS is already installed."
    }


    # install IIS-Node
    $iisNodePath = "C:\Program Files\iisnode"
    if(Test-Path $iisNodePath) {
        Echo "`nIISNode is already installed."
    } else {
        installMSI -path $iisNodeMsiPath -name "IIS-Node"
    }


    Echo "`nStopping IIS ..."
    Stop-Service -Name W3SVC -PassThru


    # unzip file
    function UnZipMe($zipfilename, $destination){

        if(Test-Path $destination) {
            Echo "`nRemoving files under $destination\site\wwwroot\ ..."
            Get-ChildItem -Path $destination\* -Exclude "logs", "sisenseShellApi*.log" | foreach ($_) {
               Remove-Item $_.fullname -Force -Recurse
            }

        } else {
            Echo "`nCreating folder $destination ..."
            md $destination
        }
    
        $shellApplication = new-object -com shell.application
        $zipPackage = $shellApplication.NameSpace($zipfilename)
        $destinationFolder = $shellApplication.NameSpace($destination)
        $destinationFolder.CopyHere($zipPackage.Items(), 1044)

    }

    Echo "`nUnzipping file $zipfilePath ..."
    $unzipDestination = "$iisNodePath\www\sisense-ws"
    UnZipMe -zipfilename $zipfilePath -destination $unzipDestination

    Echo "`nStarting IIS ..."
    Start-Service -Name W3SVC -PassThru


    # create appdomain 
    $appPool = "sisensews"
    try
    {
        Get-WebAppPoolState $appPool –errorvariable myerrorvariable
        Echo "`nApplication pool $appPool already exists"
        Set-ItemProperty IIS:\AppPools\$appPool -name processModel -value @{identitytype="NetworkService"}
    }
    catch
    {
        Echo "`nCreating application pool $appPool..."
        New-WebAppPool -Name $appPool
        Set-ItemProperty IIS:\AppPools\$appPool managedRuntimeVersion v4.0
        Set-ItemProperty IIS:\AppPools\$appPool -name processModel -value @{identitytype="NetworkService"}
    }


    # create website
    $siteName = "SisenseShellWebSite"
    $site = Get-WebSite | where { $_.Name -eq $siteName }
    $physicalPath = "$unzipDestination\site\wwwroot"

    if($site -ne $null)
    {
          Echo "`nWebsite $siteName already exists"
    } else {
          Echo "`nCreating website $siteName at $physicalPath ..."
      
          New-Website -Name $siteName -ApplicationPool $appPool -Force -PhysicalPath $physicalPath

          $binding  = Get-WebBinding | Where-Object {$_.bindinginformation -eq "*:8080:"}
          if ($null -ne $binding){
             Echo "`nRemoving web bindings ..."
             Remove-WebBinding -Port 8080
          }

          Get-WebBinding -Port 80 -Name $siteName | Remove-WebBinding

          Echo "`nCreating web bindings ..."
          New-WebBinding -Name $siteName -IPAddress "*" -Port 8080
    }


    # set permissions
    Echo "`nSetting directory permissions..."

    $inherit = [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit"
    $propagation = [system.security.accesscontrol.PropagationFlags]"None"  

    #Set directory permission
    $acl = Get-Acl $physicalPath

    $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("NetworkService", "FullControl", $inherit, $propagation, "Allow")
    $acl.AddAccessRule($accessRule)
    Set-Acl -aclobject $acl $physicalPath

    # stop website
    Echo "`nStopping website $siteName ..."
    Stop-Website -Name $siteName

    # start website
    Echo "`nRestarting website $siteName ..."
    Start-Website -Name $siteName

    Echo "`n=== Completed Setting up Sisense Shell API ==="
}

invoke-command -session $session -scriptblock $remoteScript -ArgumentList $storageAccountName, $storageAccountKey, $appVersion

Remove-PSSession $session