import * as child from 'child_process'

import { appSettings, log } from '../common'
import { BuildMode, IBuildInfo, IEditDatabaseConnectionInfo, IEcdataInfo, IEcubeInfo } from './'

export class Prism {
    
    private executeCommand(command: string): Promise<any> {    
        return new Promise((resolve, reject)=> {

            log.info(command)
            child.exec(command, (err: Error, stdout: string, stderr: string)=> {
                stdout && log.debug(stdout);
                stderr && log.error(stderr);
                (err && reject(err)) || resolve();
            })

        })
    }

    private getCommand(commandName: string, commandArguments: string){
        return `psm ecube ${commandName} ${commandArguments}`
    }

    build(bldInfo: IBuildInfo): Promise<any> {
       
        const serverAddress = (bldInfo.serverAddress && `serverAddress="${bldInfo.serverAddress}"`) || ''
        const command = this.getCommand('build', `filename="${bldInfo.ecubeFilePath}" ${serverAddress} mode=restart`)       
        return this.executeCommand(command)

    }

    delete(ecubeInfo: IEcubeInfo): Promise<any> {
     
        const serverAddress = (ecubeInfo.serverAddress && `serverAddress="${ecubeInfo.serverAddress}"`) || ''
        const command = this.getCommand('delete', `name="${ecubeInfo.ecubeName}" ${serverAddress}`)
        return this.executeCommand(command)

    }

    editDatabaseConnection(info: IEditDatabaseConnectionInfo): Promise<any> {

        let command = this.getCommand('edit connection database backup=false', 
                                            `ecube="${info.ecubeFilePath}" server="${info.databaseServerName}" ` +
                                            `newserver="${info.newDatabaseServerName}" newdatabase="${info.newDatabaseName}" ` +
                                            `newusername="${info.newUsername}" newpassword="${info.newPassword}"`)
       
        return this.executeCommand(command)

    }

    exists(ecubeInfo: IEcubeInfo): Promise<any> {
     
        const serverAddress = (ecubeInfo.serverAddress && `serverAddress="${ecubeInfo.serverAddress}"`) || ''
        const command = this.getCommand('info', `name="${ecubeInfo.ecubeName}" ${serverAddress}`)
        return this.executeCommand(command)

    }

    importEcdata(info: IEcdataInfo): Promise<any> {

        const serverAddress = (info.serverAddress && `serverAddress="${info.serverAddress}"`) || ''
        let command = this.getCommand('import', `path="${info.ecdataFilePath}" ${serverAddress}` )       
        return this.executeCommand(command)

    }

    rename(renameInfo: IEcubeInfo): Promise<any> {

        let command = this.getCommand('edit rename backup=false', `ecube="${renameInfo.ecubeFilePath}" name="${renameInfo.ecubeName}"`)     
        return this.executeCommand(command)

    }
}