export interface IEcubeInfo{
    ecubeName: string;
    serverAddress: string;
    ecubeFilePath: string;
}