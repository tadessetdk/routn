export enum BuildMode {
    Restart = 0 //, // Rebuilds the ElastiCube entirely.
    // Full, // Rebuilds the ElastiCube and accumulates data for tables marked as accumulative; should only be used for accumulative builds.
    // Changes, // Rebuilds from scratch tables that have changed in the ElastiCube schema.
    // MetadataOnly // Updates the ElastiCube server with the ElastiCube schema, without building.
}

export interface IBuildInfo{
    ecubeName: string;
    ecubeFilePath: string; 
    mode: BuildMode;
    serverAddress?: string;
}