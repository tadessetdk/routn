import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as child from 'child_process'
import * as path from 'path'

import { appSettings, log } from '../common'
import { BuildMode, IBuildInfo, IEditDatabaseConnectionInfo, IEcubeInfo, IEcdataInfo } from './'
import { Prism } from './prismWrapper'

const sb = sandbox.create()

describe('prismWrapper', () => {
   
    let prism
    let childExecStub
    let logErrorStub

    beforeEach(() => {  
        prism = new Prism()
        childExecStub = sb.stub(child, 'exec')
        logErrorStub = sb.stub(log, 'error')
        sb.stub(log, 'info')
    })

    afterEach(()=> {
        sb.restore()
    })

    describe('build command', ()=> {

        const buildInfo: IBuildInfo = { 
            ecubeName: 'ecubeName',
            ecubeFilePath: 'ecubeFilePath',
            mode: BuildMode.Restart
        }

        function testBuildSuccess(done, bldInfo) {
            // act 
            const buildPromise = prism.build(bldInfo)

            // assert
            const cmdFrag = (bldInfo.serverAddress && `serverAddress="${bldInfo.serverAddress}"`) || ''
            const command = `psm ecube build filename="${bldInfo.ecubeFilePath}" ${cmdFrag} mode=restart`
            assert(childExecStub.withArgs(command).calledOnce)
            
            const error = null
            childExecStub.callArgWith(1, error)
            buildPromise.then(()=> {
                expect(logErrorStub.callCount).to.equal(0)
                done()
            })
        }

        it('executes build prism command with LocalHost', done => { 
            testBuildSuccess(done, buildInfo)
        })

        it('executes build prism command with serverAddress', done => { 
            testBuildSuccess(done, Object.assign({ serverAddress: 'serverAddress' }, buildInfo))
        })

        it('failed to execute build prism command', done => { 
            // act 
            const buildPromise = prism.build(buildInfo)

            // assert
            const error = 'error', stderr = 'stderr'
            childExecStub.callArgWith(1, error, '', stderr)
            buildPromise.catch(err => {
                expect(err).to.equal(error)
                assert(logErrorStub.withArgs(stderr).calledOnce)
                done()
            })
        })

    })

    describe('delete command', ()=> {

        const deleteInfo: IEcubeInfo = { 
            ecubeName: 'ecubeName',
            ecubeFilePath: '',
            serverAddress: 'serverAddress'
        }

        function executeDeleteCommand(done, deleteInfo) {
            // act 
            const deletePromise = prism.delete(deleteInfo)

            // assert
            const serverAddress =  deleteInfo.serverAddress && `serverAddress="${deleteInfo.serverAddress}"` || ''
            const command = `psm ecube delete name="${deleteInfo.ecubeName}" ${serverAddress}`
            assert(childExecStub.withArgs(command).calledOnce)
            
            const error = null
            childExecStub.callArgWith(1, error)
            deletePromise.then(()=> {
                expect(logErrorStub.callCount).to.equal(0)
                done()
            })
        }

        it('executes delete prism command with serverAddress', done => { 
            executeDeleteCommand(done, deleteInfo)
        })

        it('executes delete prism command with LocalHost', done => { 
            executeDeleteCommand(done, { ecubeName: 'ecubeName', ecubeFilePath: '', serverAddress: '' })
        })

        it('failed to execute delete prism command', done => { 
            // act 
            const deletePromise = prism.delete(deleteInfo)

            // assert
            const error = 'error', stderr = 'stderr'
            childExecStub.callArgWith(1, error, '', stderr)
            deletePromise.catch(err => {
                expect(err).to.equal(error)
                assert(logErrorStub.withArgs(stderr).calledOnce)
                done()
            })
        })

    })

    describe('editDatabaseConnection command', ()=> {

        const editDatabaseConnectionInfo: IEditDatabaseConnectionInfo = { 
            ecubeName: 'ecubeName',
            ecubeFilePath: 'ecubeFilePath',
            databaseServerName: 'databaseServerName',
            newDatabaseServerName: 'newDatabaseServerName',
            newDatabaseName: 'newDatabaseName',
            newUsername: 'newUsername',
            newPassword: 'newPassword'
        }

        function getCommand(info) {
            let command = `psm ecube edit connection database backup=false ecube="${info.ecubeFilePath}" server="${info.databaseServerName}" ` +
                            `newserver="${info.newDatabaseServerName}" newdatabase="${info.newDatabaseName}" ` +
                            `newusername="${info.newUsername}" newpassword="${info.newPassword}"`

            return command
        }

        function testEditDatabaseConnectionSuccess(done, dbInfo) {
            // act 
            const editDatabaseConnectionPromise = prism.editDatabaseConnection(dbInfo)

            // assert
            const command = getCommand(dbInfo)
            assert(childExecStub.withArgs(command).calledOnce)
            
            const error = null
            childExecStub.callArgWith(1, error)
            editDatabaseConnectionPromise.then(()=> {
                expect(logErrorStub.callCount).to.equal(0)
                done()
            })
        }

        it('executes editDatabaseConnection prism command with all arguments provided', done => { 
            testEditDatabaseConnectionSuccess(done, editDatabaseConnectionInfo)
        })

        it('failed to execute editDatabaseConnection prism command', done => { 
            // act 
            const editDatabaseConnectionPromise = prism.editDatabaseConnection(editDatabaseConnectionInfo)

            // assert
            const error = 'error', stderr = 'stderr'
            childExecStub.callArgWith(1, error, '', stderr)
            editDatabaseConnectionPromise.catch(err => {
                expect(err).to.equal(error)
                assert(logErrorStub.withArgs(stderr).calledOnce)
                done()
            })
        })

    })

    describe('rename command', ()=> {

        const renameInfo: IEcubeInfo = { 
            ecubeName: 'ecubeName',
            ecubeFilePath: 'ecubeFilePath',
            serverAddress: ''
        }

        it('executes rename prism command', done => { 
            // act 
            const renamePromise = prism.rename(renameInfo)

            // assert
            const command = `psm ecube edit rename backup=false ecube="${renameInfo.ecubeFilePath}" name="${renameInfo.ecubeName}"`
            assert(childExecStub.withArgs(command).calledOnce)
            
            const error = null
            childExecStub.callArgWith(1, error)
            renamePromise.then(()=> {
                expect(logErrorStub.callCount).to.equal(0)
                done()
            })
        })

        it('failed to execute rename prism command', done => { 
            // act 
            const renamePromise = prism.rename(renameInfo)

            // assert
            const error = 'error', stderr = 'stderr'
            childExecStub.callArgWith(1, error, '', stderr)
            renamePromise.catch(err => {
                expect(err).to.equal(error)
                assert(logErrorStub.withArgs(stderr).calledOnce)
                done()
            })
        })

    })

    describe('exists command', ()=> {

        const existsInfo: IEcubeInfo = { 
            ecubeName: 'ecubeName',
            ecubeFilePath: '',
            serverAddress: 'serverAddress'
        }

        function executeExistsCommand(done, existsInfo) {
            // act 
            const existsPromise = prism.exists(existsInfo)

            // assert
            const serverAddress =  existsInfo.serverAddress && `serverAddress="${existsInfo.serverAddress}"` || ''
            const command = `psm ecube info name="${existsInfo.ecubeName}" ${serverAddress}`
            assert(childExecStub.withArgs(command).calledOnce)
            
            const error = null
            childExecStub.callArgWith(1, error)
            existsPromise.then(()=> {
                expect(logErrorStub.callCount).to.equal(0)
                done()
            })
        }

        it('executes exists prism command with serverAddress', done => { 
            executeExistsCommand(done, existsInfo)
        })

        it('executes exists prism command with LocalHost', done => { 
            executeExistsCommand(done, { ecubeName: 'ecubeName', ecubeFilePath: '', serverAddress: '' })
        })

        it('failed to execute exists prism command', done => { 
            // act 
            const existsPromise = prism.exists(existsInfo)

            // assert
            const error = 'error', stderr = 'stderr'
            childExecStub.callArgWith(1, error, '', stderr)
            existsPromise.catch(err => {
                expect(err).to.equal(error)
                assert(logErrorStub.withArgs(stderr).calledOnce)
                done()
            })
        })

    })
   
   describe('import ecdata command', ()=> {

        const ecdataInfo: IEcdataInfo = { 
            ecubeName: 'ecubeName',
            ecdataFilePath: '',
            serverAddress: 'serverAddress'
        }

        function executeImportEcdataCommand(done, info) {
            // act 
            const existsPromise = prism.importEcdata(info)

            // assert
            const serverAddress =  info.serverAddress && `serverAddress="${info.serverAddress}"` || ''
            const command = `psm ecube import path="${info.ecdataFilePath}" ${serverAddress}`
            assert(childExecStub.withArgs(command).calledOnce)
            
            const error = null
            childExecStub.callArgWith(1, error)
            existsPromise.then(()=> {
                expect(logErrorStub.callCount).to.equal(0)
                done()
            })
        }

        it('executes import ecdata prism command with serverAddress', done => { 
            executeImportEcdataCommand(done, ecdataInfo)
        })

        it('executes import ecdata prism command with default server (LocalHost)', done => { 
            executeImportEcdataCommand(done, { ecubeName: 'ecubeName', ecdataFilePath: '', serverAddress: '' })
        })

        it('failed to execute import ecdata prism command', done => { 
            // act 
            const existsPromise = prism.importEcdata(ecdataInfo)

            // assert
            const error = 'error', stderr = 'stderr'
            childExecStub.callArgWith(1, error, '', stderr)
            existsPromise.catch(err => {
                expect(err).to.equal(error)
                assert(logErrorStub.withArgs(stderr).calledOnce)
                done()
            })
        })

    })

})