export interface IEditDatabaseConnectionInfo{
    ecubeName: string;
    ecubeFilePath: string;
    databaseServerName: string;
    newDatabaseServerName: string;
    newDatabaseName: string;
    newUsername: string;
    newPassword: string;
}