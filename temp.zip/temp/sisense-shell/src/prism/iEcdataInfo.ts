export interface IEcdataInfo{
    ecubeName: string;
    ecdataFilePath: string;
    serverAddress?: string;
}