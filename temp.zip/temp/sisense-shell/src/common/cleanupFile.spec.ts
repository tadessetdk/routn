import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as fs from 'fs'
import { log, cleanupFile, HttpError } from './'
import * as cleanupHelper from './cleanupFile' 
const sb = sandbox.create()

describe('cleanupFile', () => {
 
      const req: any = { file: { path: 'path' }}
      const res:any = {}
      let nextStub
      const logMessage = 'logMessage'

      let logErrorStub
      let delFileStub
      let onResponseFinishedStub
      let thenStub

      beforeEach(() => {  
            nextStub = sb.stub()
            delFileStub = sb.stub(cleanupHelper, 'delFile')
            thenStub = sb.stub()
            onResponseFinishedStub = sb.stub(cleanupHelper, 'onResponseFinished').returns({ then: thenStub })
            logErrorStub = sb.stub(log, 'endWithError')
      })

      afterEach(()=> {
            sb.restore()
      })

      it('should succeed deleting file', () => { 
            // act 
            cleanupFile(req, res, nextStub, logMessage)
                  
            // assert 
            assert(nextStub.calledOnce)
            assert(onResponseFinishedStub.withArgs(req, res).calledOnce)

            // act 
            thenStub.callArgWith(0)

            // assert
            assert(delFileStub.withArgs(req).calledOnce)
      })

      it('should fail deleting file', () => { 
            // arrange 
            const req1: any = {}

            // act 
            cleanupFile(req1, res, nextStub, logMessage)
                  
            // assert 
            assert(logErrorStub.withArgs(req1, res, <HttpError>{ statusCode: 400, message: 'Invalid ecube file' }, logMessage).calledOnce)
      })

})