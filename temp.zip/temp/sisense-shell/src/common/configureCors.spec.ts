import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as multer from 'multer'
import * as fs from 'fs'
import * as cors from 'cors'

import { configureCors } from './configureCors'

const sb = sandbox.create()

describe('configureCors', () => {

      const originValue = '*'

      const corsOptions = {
            origin: originValue,
            methods: 'GET,PUT,POST,DELETE',
            preflightContinue: false,
            allowedHeaders: ['Content-Type', 'Authorization', 'X-Session-Id', 'X-Correlation-Id'],
            optionsSuccessStatus: 204
      }

      const optionResult = { }

      let app = { use: ()=> {}, options: ()=> {} }
      let useStub, optionsStub
      
      beforeEach(() => {  
            useStub = sb.stub(app, 'use')
            optionsStub = sb.stub(app, 'options')
      })

      afterEach(()=> {
            sb.restore()
      })

      it('should initialize cors settings', () => { 
            // act 
            configureCors(<any>app)
                  
            // assert 
            assert(useStub.calledOnce)
            assert(optionsStub.withArgs(originValue).calledOnce)
           
      })

})