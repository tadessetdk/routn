import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as parser from 'body-parser'
import * as common from './'
import * as routeHelper from '../routes'

const sb = sandbox.create()

describe('initializeApp', () => {

    const portNumber = '9008'
    process.env.PORT = portNumber

    const jsonResult = { result: 1 }
    const upload = { file: 'test' }
    
    let useStub, listenStub, jsonStub
    let app
    let configureCorsStub, configureUploadStub, initAppSettingsStub, infoLogStub
    let defineAuthenticateRequestRouteStub, defineDeleteEcubeRouteStub
    let defineEditDatabaseConnectionRouteStub, defineImportEcubeRouteStub
    let defineImportEcdataRouteStub, definePingRouteStub

    beforeEach(() => {  
        useStub = sb.stub()
        listenStub = sb.stub()
        app = { use: useStub, listen: listenStub }
        //jsonStub = sb.stub(parser, 'json').returns(jsonResult)

        configureCorsStub = sb.stub(common, 'configureCors')
        configureUploadStub = sb.stub(common, 'configureUpload').returns(upload)
        initAppSettingsStub = sb.stub(common, 'initAppSettings')
        infoLogStub = sb.stub(common.log, 'info')

        defineAuthenticateRequestRouteStub = sb.stub(routeHelper, 'defineAuthenticateRequestRoute')
        defineDeleteEcubeRouteStub = sb.stub(routeHelper, 'defineDeleteEcubeRoute')
        defineEditDatabaseConnectionRouteStub = sb.stub(routeHelper, 'defineEditDatabaseConnectionRoute')
        defineImportEcubeRouteStub = sb.stub(routeHelper, 'defineImportEcubeRoute')
        defineImportEcdataRouteStub = sb.stub(routeHelper, 'defineImportEcdataRoute')
        definePingRouteStub = sb.stub(routeHelper, 'definePingRoute')
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should initialize app settings', () => { 
        // act 
        common.initializeApp(<any>app)

        // assert 
        assert(useStub/*.withArgs(jsonResult)*/.calledOnce)
        assert(listenStub.withArgs(portNumber).calledOnce)
        listenStub.callArgWith(1)
        assert(infoLogStub.withArgs(`Sisense Prism API listening on port ${portNumber}`).calledOnce)
                
        assert(initAppSettingsStub.calledOnce)
        assert(configureUploadStub.withArgs(app).calledOnce)
        assert(configureCorsStub.withArgs(app).calledOnce)
        assert(defineDeleteEcubeRouteStub.withArgs(app).calledOnce)
        assert(defineEditDatabaseConnectionRouteStub.withArgs(app, upload).calledOnce)
        assert(defineImportEcubeRouteStub.withArgs(app, upload).calledOnce)
        assert(defineImportEcdataRouteStub.withArgs(app, upload).calledOnce)
        assert(definePingRouteStub.withArgs(app).calledOnce)
        assert(defineAuthenticateRequestRouteStub.withArgs(app).calledOnce)
    })

});