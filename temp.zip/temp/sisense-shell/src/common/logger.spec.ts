import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as log from './logger'

const sb = sandbox.create()

describe('logger', () => {

    const message = 'log message'
    const InternalServerError = 'Internal Server Error'
    const messagePrefix = 'messagePrefix'
    const correlationId = 'correlationId'
    const sessionId = 'sessionId'
    const logInfo = [{ message: message, status: 200, correlationId: correlationId }]
    const method = 'GET'
    const url = 'http://myhost.com'
    const req: any = {
        method: method,
        url: url,
        headers: {
            'x-correlation-id': correlationId,
            'x-session-id': sessionId
        }
    }
    const statusCode = 200
    const res: any = {
        statusCode: statusCode,
        status: ()=> {},
        end: ()=> {},
        json: ()=> {}
    }
    const responseError = {

    }

    let debugStub, traceStub, warnStub, infoStub, errorStub
    let statusStub, endStub, jsonStub

    beforeEach(() => {  
        debugStub = sb.stub(log.logger, 'debug')
        traceStub = sb.stub(log.logger, 'trace')
        warnStub = sb.stub(log.logger, 'warn')
        infoStub = sb.stub(log.logger, 'info')
        errorStub = sb.stub(log.logger, 'error')

        statusStub = sb.stub(res, 'status')
        endStub = sb.stub(res, 'end')
        jsonStub = sb.stub(res, 'json')
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should write debug logs', () => { 
        // act
        log.debug(logInfo) 

        //assert
        assert(debugStub.withArgs([logInfo]).calledOnce)
    })

    it('should write trace logs', () => { 
        // act
        log.trace(logInfo) 

        //assert
        assert(traceStub.withArgs([logInfo]).calledOnce)
    })

    it('should write info logs', () => { 
        // act
        log.info(logInfo) 

        //assert
        assert(infoStub.withArgs([logInfo]).calledOnce)
    })

    it('should write warn logs', () => { 
        // act
        log.warn(logInfo) 

        //assert
        assert(warnStub.withArgs([logInfo]).calledOnce)
    })

    it('should write error logs', () => { 
        // act
        log.error(logInfo) 

        //assert
        assert(errorStub.withArgs([logInfo]).calledOnce)
    })

    it('should write debug logs with correlation', () => { 
        // act
        log.debugWithCorrelation(req, message) 

        //assert
        assert(debugStub.withArgs([{ correlationId: correlationId }, { message: message }]).calledOnce)
    })

    it('should write trace logs with correlation', () => { 
        // act
        log.traceWithCorrelation(req, message) 

        //assert
        assert(traceStub.withArgs([{ correlationId: correlationId }, { message: message }]).calledOnce)
    })

    it('should write info logs with correlation', () => { 
        // act
        log.infoWithCorrelation(req, message) 

        //assert
        assert(infoStub.withArgs([{ correlationId: correlationId }, { message: message }]).calledOnce)
    })

    it('should write warn logs with correlation', () => { 
        // act
        log.warnWithCorrelation(req, message) 

        //assert
        assert(warnStub.withArgs([{ correlationId: correlationId }, { message: message }]).calledOnce)
    })

    it('should write error logs with correlation', () => { 
        // act
        log.errorWithCorrelation(req, message) 

        //assert
        assert(errorStub.withArgs([{ correlationId: correlationId }, { message: message }]).calledOnce)
    })

    it('should write request logs', () => { 
        // act
        log.request(req, messagePrefix) 

        //assert
        assert(traceStub.withArgs([{ correlationId: correlationId, message: `${messagePrefix} started` }]).calledOnce)
        assert(infoStub.calledOnce)
        let infoArg = infoStub.args[0][0][0]
        delete infoArg.timeStamp
        expect(infoArg).to.deep.equal({ correlationId: correlationId, sessionId: sessionId, url: `${method} ${url}` })
    })

    function assertSuccessResponse(){
        //assert
        assert(traceStub.withArgs([{ correlationId: correlationId, message: `${messagePrefix} succeeded` }]).calledOnce)
        assert(infoStub.calledOnce)
        let infoArg = infoStub.args[0][0][0]
        delete infoArg.timeStamp
        expect(infoArg).to.deep.equal({ status: statusCode, correlationId: correlationId, sessionId: sessionId, url: `${method} ${url}` })
    }

    it('should write success response logs', () => { 
        // act
        log.response(req, res, messagePrefix) 

        // assert
        assertSuccessResponse()
    })

    it('should write error response logs', () => {
        // arrange
        const errorStatusCode = 500
        const res: any = { statusCode: errorStatusCode }
        const errorMessage = 'error message'
        const stackInfo = 'stack details'
        const error: any = { message: errorMessage, stack: stackInfo }

        // act
        log.response(req, res, messagePrefix, error) 

        //assert
        assert(traceStub.withArgs([{ correlationId: correlationId, message: `${messagePrefix} failed` }]).calledOnce)
        assert(errorStub.calledOnce)
        let errorArg = errorStub.args[0][0][0]
        delete errorArg.timeStamp
        expect(errorArg).to.deep.equal({ message: errorMessage, correlationId: correlationId })

        assert(debugStub.calledOnce)
        let debugArg = debugStub.args[0][0][0]
        delete debugArg.timeStamp
        expect(debugArg).to.deep.equal({ message: stackInfo, correlationId: correlationId })

    })

    it('should end request with success with 200', () => { 
        // act 
        log.endWithSuccess(req, res, messagePrefix)

        //assert
        assertSuccessResponse()
        assert(statusStub.withArgs(200).calledOnce)
        assert(endStub.calledOnce)
    })

    it('should end request with success with status code and json response', () => { 
        // arrange 
        const statusCodeCreated = 201
        const json = { data: 'test' }

        // act 
        log.endWithSuccess(req, res, messagePrefix, statusCodeCreated, json)

        //assert
        assert(statusStub.withArgs(statusCodeCreated).calledOnce)
        assert(jsonStub.withArgs(json).calledOnce)
    });

    it('should end request with 500 error', () => { 
        // arrange 
        const statusCodeError = 500
        const error: any = { statusCode: statusCodeError, message: message }

        // act 
        log.endWithError(req, res, error, messagePrefix)

        //assert
        assert(statusStub.withArgs(statusCodeError).calledOnce)
        assert(endStub.withArgs(InternalServerError).calledOnce)
    });

    it('should end request with 400 error', () => { 
        // arrange 
        const statusCodeError = 400
        const error: any = { statusCode: statusCodeError, message: message }

        // act 
        log.endWithError(req, res, error, messagePrefix)

        //assert
        assert(statusStub.withArgs(statusCodeError).calledOnce)
        assert(endStub.withArgs(message).calledOnce)
    });

});
