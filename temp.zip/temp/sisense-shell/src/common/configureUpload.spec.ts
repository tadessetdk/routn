import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as multer from 'multer'
import * as fs from 'fs'
import { configureUpload, getUploadedFile, log } from './'

const sb = sandbox.create()

describe('configureUpload', () => {

      const fileParameterName = 'fileParameterName'
      const logMessagePrefix = 'Message Prefix'
      const req: any = { }
      const res: any = { }
      const upload: any = { single: n=> {} }

      let diskStorageStub, mkdirStub, uploadSingleStub, uploadSingleResultStub, nextStub, endWithErrorStub
      
      beforeEach(() => {  
            diskStorageStub = sb.stub(multer, 'diskStorage')
            mkdirStub = sb.stub(fs, 'mkdir')
            uploadSingleResultStub = sb.stub()
            uploadSingleStub = sb.stub(upload, 'single').returns(uploadSingleResultStub)
            nextStub = sb.stub()
            endWithErrorStub = sb.stub(log, 'endWithError')
      })

      afterEach(()=> {
            sb.restore()
      })

      it('should initialize multer upload', () => { 
            // act 
            const result = configureUpload(null)
                  
            // assert 
            expect(result).to.be.defined
            assert(diskStorageStub.calledOnce)
            expect(mkdirStub.callCount).to.equal(0)
      })

      it('should set destination', () => { 
            // arrange 
            configureUpload(null)
            const diskStorageArgs = diskStorageStub.args[0][0]
            const cbStub = sb.stub()

            // act
            diskStorageArgs.destination(0, 0, cbStub)

            // assert
            assert(mkdirStub.calledOnce)
            const folder = mkdirStub.args[0][0]
            const uploadFolderRegex = /^\.\/uploads\/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\/$/i
            expect(uploadFolderRegex.test(folder)).to.be.true

            // act
            const cbArg = mkdirStub.args[0][1]
            cbArg()

            // assert
            assert(cbStub.calledOnce)
            expect(uploadFolderRegex.test(cbStub.args[0][1])).to.be.true
      })

      it('should set filename', () => { 
            // act 
            configureUpload(null)
            const diskStorageArgs = diskStorageStub.args[0][0]

            // arrange
            const cbStub = sb.stub()

            // act
            const filename = 'filename-3434534_3445'
            diskStorageArgs.filename(0, { originalname: filename }, cbStub)

            // assert
            assert(cbStub.calledOnce)
            const newFilename = cbStub.args[0][1]
            const uploadFolderRegex = new RegExp(`^f\\d+_${filename}$`, 'i')
            expect(uploadFolderRegex.test(newFilename)).to.be.true
      })

      it('should initialize get uploaded file step', () => { 
            // act 
            getUploadedFile(req, res, nextStub, upload, logMessagePrefix, fileParameterName)
           
            // assert
            assert(uploadSingleStub.withArgs(fileParameterName).calledOnce)
            assert(uploadSingleResultStub.withArgs(req, res).calledOnce)
      })

      it('should initialize get uploaded file step with defaul fileParameterName', () => { 
            // act 
            getUploadedFile(req, res, nextStub, upload, logMessagePrefix)
           
            // assert
            assert(uploadSingleStub.withArgs('ecubeFile').calledOnce)
            assert(uploadSingleResultStub.withArgs(req, res).calledOnce)
      })

      it('should successfully get uploaded file', () => { 
            // act 
            getUploadedFile(req, res, nextStub, upload, logMessagePrefix, fileParameterName)
            uploadSingleResultStub.args[0][2]()

            // assert
            assert(nextStub.calledOnce)
      })

       it('should fail to get uploaded file', () => { 
            // arrange 
            const error = { messagae: 'errors' }

            // act 
            getUploadedFile(req, res, nextStub, upload, logMessagePrefix, fileParameterName)
            uploadSingleResultStub.args[0][2](error)

            // assert
            expect(nextStub.callCount).to.equal(0)
            assert(endWithErrorStub.withArgs(req, res, { statusCode: 400, message: 'Invalid file' }, logMessagePrefix).calledOnce)
      })

})