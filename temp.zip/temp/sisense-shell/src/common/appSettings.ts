import * as fs from 'fs'

export interface ISettings{
    concurrentTasksQueueLimit: number;
    sisenseApiUri: string;
    logLevel: string;
}

const uploadFolderName = 'uploads'
const configValue = process.env['SISENSE_SHELL_WEB_SERVICE_SETTINGS']

export const appSettings: ISettings = 
        configValue && JSON.parse(configValue) || 
        {
            concurrentTasksQueueLimit: 10,
            sisenseApiUri: 'http://localhost:8083/api/v1',
            logLevel: 'info'
        }

export function initAppSettings(){
    
    !fs.existsSync(uploadFolderName) && fs.mkdirSync(uploadFolderName)

}