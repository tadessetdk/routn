import * as express from 'express'
import * as log4js from 'log4js'

import { HttpError, appSettings } from '../common'

export const logger = (function(){
    log4js.configure({
        "appenders": [
                {
                    "type": "clustered",
                    "appenders": [
                            {
                                "type": "dateFile",
                                "filename": "logs/sisenseShellApi.log",
                                "pattern": "-yyyy-MM-dd",
                                "category": "sisenseShellApi"
                            },
                            {
                                "type": "console"
                            }
                    ]
                }
        ]
    })
    
    return log4js.getLogger('sisenseShellApi', { level: appSettings.logLevel })
})()

function getLogInfo(req: express.Request, correlationIdObj){
    let info: any = { 
        sessionId: req.headers['x-session-id'],
        url: `${req.method} ${req.url}`,
        timeStamp: new Date().toISOString()
    }

    return Object.assign(info, correlationIdObj)
}

function logError(err: Error, correlationIdObj) {  
    if(err) {
        error(Object.assign({ message: err.message || JSON.stringify(err) }, correlationIdObj))
        err.stack && debug(Object.assign({ message: err.stack }, correlationIdObj))
    }
}

function getCorrelationId(req){
    return { correlationId: req.headers['x-correlation-id'] }
}   

export function debug(...args) {
    logger.debug(args)
}

export function trace(...args) {
    logger.trace(args)
}

export function info(...args) {
    logger.info(args)
}

export function warn(...args) {
    logger.warn(args)
}

export function error(...args) {
    logger.error(args)
}

export function debugWithCorrelation(req, message) {
    debug(getCorrelationId(req), { message: message })
}

export function traceWithCorrelation(req, message) {
    trace(getCorrelationId(req), { message: message })
}

export function infoWithCorrelation(req, message) {
    info(getCorrelationId(req), { message: message })
}

export function warnWithCorrelation(req, message) {
    warn(getCorrelationId(req), { message: message })
}

export function errorWithCorrelation(req, message) {
    error(getCorrelationId(req), { message: message })
}

export function request(req: express.Request, messagePrefix: string){
    const correlationIdObj = getCorrelationId(req)
    trace(Object.assign({ message: `${messagePrefix} started` }, correlationIdObj))  
    info(getLogInfo(req, correlationIdObj))
}

export function response(req: express.Request, res: express.Response, messagePrefix: string, err?: Error){
    const correlationIdObj = getCorrelationId(req)
    trace(Object.assign({ message: `${messagePrefix} ${ err && 'failed' || 'succeeded' }` }, correlationIdObj))  
      
    let logInfo: any = getLogInfo(req, correlationIdObj)
    logInfo.status = res.statusCode;
    
    (!err && info(logInfo));
    logError(err, correlationIdObj);
}

export function endWithSuccess(req, res, logMessagePrefix?: string, statusCode: number = 200, json?: any){
    res.status(statusCode);
    response(req, res, logMessagePrefix);
    (json && res.json(json)) || res.end();
}

export function endWithError(req, res, err: HttpError, logMessagePrefix: string){
    const statusCode = err.statusCode || 500
    res.status(statusCode) 
    response(req, res, logMessagePrefix, err)            
    res.end((statusCode === 500 && 'Internal Server Error') || err.message || '')   
}