import * as express from 'express'
import * as cors from 'cors'

const originValue = '*'
const options: cors.CorsOptions = {
    origin: originValue,
    methods: 'GET,PUT,POST,DELETE',
    preflightContinue: false,
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Session-Id', 'X-Correlation-Id'],
    optionsSuccessStatus: 204
}

export function configureCors(app: express.Application){  

    app.use(cors(options))
    app.options(originValue, cors())

}