import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as fs from 'fs'
import { appSettings, ISettings, initAppSettings } from './appSettings'

const sb = sandbox.create()

describe('appSettings', () => {
    const uploadFolderName = 'uploads'
    let config = {
        concurrentTasksQueueLimit: 10,
        sisenseApiUri: 'http://localhost:8083/api/v1',
        logLevel: 'info'
    }

    let existsSyncStub, mkdirSyncStub

    beforeEach(() => {  
        mkdirSyncStub = sb.stub(fs, 'mkdirSync')
        process.env['SISENSE_SHELL_WEB_SERVICE_SETTINGS'] = JSON.stringify(config)
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should initialize app settings', () => { 
        // arrange
        existsSyncStub = sb.stub(fs, 'existsSync').returns(true)
        
        // act 
        initAppSettings()

        // assert 
        expect(appSettings).to.deep.equal(config)
        assert(existsSyncStub.withArgs(uploadFolderName).calledOnce)
        //expect(mkdirSyncStub.callCount).to.equal(0)
    })

    it('should create upload folder if not exists', () => { 
        // arrange
        sb.stub(fs, 'existsSync').returns(false)

        // act 
        initAppSettings()
        
        // assert 
        assert(mkdirSyncStub.withArgs(uploadFolderName).calledOnce)
    })

});