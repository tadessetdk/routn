import * as express from 'express'
import { json } from 'body-parser'

import { configureCors, configureUpload, initAppSettings, log } from './'
import { defineAuthenticateRequestRoute, defineDeleteEcubeRoute, defineEditDatabaseConnectionRoute, defineImportEcubeRoute, defineImportEcdataRoute, definePingRoute } from '../routes'

export function initializeApp(app: express.Application) {
    // setup app 
    app.use(json())

    // initialize app settings
    initAppSettings()

    // configure file upload
    const upload = configureUpload(app)

    // configure cors
    configureCors(app)

    // define routes
    defineAuthenticateRequestRoute(app)
    defineDeleteEcubeRoute(app)
    defineEditDatabaseConnectionRoute(app, upload)
    defineImportEcubeRoute(app, upload)
    defineImportEcdataRoute(app, upload)
    definePingRoute(app)

    // start app
    const portNumber = process.env.PORT || 9000
    app.listen(portNumber, ()=> {
        log.info(`Sisense Prism API listening on port ${portNumber}`)
    })
}