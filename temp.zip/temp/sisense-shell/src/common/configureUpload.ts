import * as express from 'express'
import * as multer from 'multer'
import * as fs from 'fs'

import { Guid, HttpError, log } from './'

export function configureUpload(app: express.Application) {

    var storage = multer.diskStorage({
        destination: (req, file, cb) => {
            const folder = `./uploads/${Guid.NewGuid()}/`
            fs.mkdir(folder, err=> {
                cb(null, folder)
            })
        },
        filename: (req, file, cb)=> cb(null, `f${Date.now()}_${file.originalname}`)
    })

    const upload = multer({ storage: storage })
    
    return upload

}

export function getUploadedFile(req: express.Request, res: express.Response, next, 
                                upload: multer.Instance, logMessagePrefix: string, fileParameterName: string = 'ecubeFile'){

    upload.single(fileParameterName)(req, res, err=> {
        if (err) {
            log.endWithError(req, res, <HttpError>{ statusCode: 400, message: 'Invalid file' }, logMessagePrefix)
            return
        }
        next()
    })

}