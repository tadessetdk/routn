export class Guid{
    constructor(private guid: string){}
    
    toString(){ return this.guid }

    static NewGuid(): Guid{
        return new Guid(`${this.getId()}${this.getId()}-${this.getId()}-${this.getId()}-${this.getId()}-${this.getId()}${this.getId()}${this.getId()}`);
    }  

    private static getId(){
         return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1) 
    }                   
}