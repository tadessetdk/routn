import { describe, it } from 'mocha'
import { expect } from 'chai'

import { Guid } from './guid'

describe('Guid', () => {

    const guidRegex = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i

    it('should create a valid guid', () => { 
        // act 
        const guid = Guid.NewGuid().toString()

        // assert 
        expect(guidRegex.test(guid)).to.be.true
    })

});