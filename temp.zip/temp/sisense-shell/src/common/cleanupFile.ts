import * as express from 'express'
import * as onFinished from 'on-finished'
import * as path from 'path'
import * as del from 'del'

import { log, HttpError } from '../common'

export const delFile = function(req) : Promise<any> {
    return del([`${path.dirname(req.file.path)}/**`]) .then(paths=> log.debug(`Deleted ecube file ${paths.join()}`))
}

export const onResponseFinished = function(req, res) : Promise<any> {
    return new Promise((resolve, reject)=> {
        onFinished(res, (err, res)=> {
            err && log.warn(err);
            resolve()
        })
    })
}

export const cleanupFile = (req: express.Request, res: express.Response, next, logMessage: string)=> {

    if(req.file) {
        onResponseFinished(req, res).then(()=> delFile(req))
        next()
    } else {
        log.endWithError(req, res, <HttpError>{ statusCode: 400, message: 'Invalid ecube file' }, logMessage)
    }

}