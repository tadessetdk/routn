import * as express from 'express'
import { initializeApp } from './common'

initializeApp(<express.Application>express())