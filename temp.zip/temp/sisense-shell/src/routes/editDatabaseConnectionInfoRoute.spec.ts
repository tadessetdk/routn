import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import * as common from '../common'
import * as routeHelpers from './'
import { IEditDatabaseConnectionInfo } from '../prism'
import * as tasks from '../tasks'
import { defineEditDatabaseConnectionRoute } from './editDatabaseConnectionInfoRoute'

const sb = sandbox.create()

describe('defineEditDatabaseConnectionRoute', () => {

    const databaseServerName = 'databaseServerName'
    const newDatabaseServerName = 'newDatabaseServerName'
    const newDatabaseName = 'newDatabaseName'
    const newUsername = 'newUsername'
    const newPassword = 'newPassword'

    const editDatabaseConnectionInfo: IEditDatabaseConnectionInfo = { 
        ecubeName: 'ecubeName',
        ecubeFilePath: 'ecubeFilePath',
        databaseServerName: databaseServerName,
        newDatabaseServerName: newDatabaseServerName,
        newDatabaseName: newDatabaseName,
        newUsername: newUsername,
        newPassword: newPassword
    }

    const req: any = {
        params: {
            ecubeName: editDatabaseConnectionInfo.ecubeName
        },
        body: {
            databaseServerName: databaseServerName,
            newDatabaseServerName: newDatabaseServerName,
            newDatabaseName: newDatabaseName,
            newUsername: newUsername,
            newPassword: newPassword
        },
        file: { path: 'test.ecube' }
    }

    const filePath = `${path.join(path.dirname(req.file.path), editDatabaseConnectionInfo.ecubeName)}${path.extname(req.file.path)}`

    const ecubeInfo = {
        ecubeName: req.params.ecubeName,
        ecubeFilePath: path.resolve(req.file.path),
        serverAddress: req.body.serverAddress
    }

    const message = `Sisense edit database connection for ${req.params.ecubeName} has`
    let uploadObj
    const res: any = {}

    let getUploadedFileStub, cleanupFileStub, ecubeExistsStub, renameEcubeStub, testDatabaseConnectionStub
    let nextStub, addTaskStub, requestStub, editDatabaseConnectionTaskStub
    let thenStub, catchStub, thenStub2, endWithSuccessStub, endWithErrorStub
    let app, singleStub, putStub

    beforeEach(() => {  
        uploadObj = <any>{ single: singleStub }
        getUploadedFileStub = sb.stub(common, 'getUploadedFile')
        cleanupFileStub = sb.stub(common, 'cleanupFile')
        testDatabaseConnectionStub = sb.stub(routeHelpers, 'testDatabaseConnection')
        ecubeExistsStub = sb.stub(routeHelpers, 'ecubeExists')
        renameEcubeStub = sb.stub(routeHelpers, 'renameEcube')

        editDatabaseConnectionTaskStub = sb.stub(tasks, 'EditDatabaseConnectionTask')
        nextStub = sb.stub()
        requestStub = sb.stub(common.log, 'request')
        endWithSuccessStub = sb.stub(common.log, 'endWithSuccess')
        endWithErrorStub = sb.stub(common.log, 'endWithError')

        thenStub2 = sb.stub()
        catchStub = sb.stub().returns({ then: thenStub2 })
        thenStub = sb.stub().returns({ 'catch': catchStub })
        addTaskStub = sb.stub(tasks.taskManager, 'addTask').returns({ then: thenStub })

        singleStub = sb.stub()
        putStub = sb.stub()
        app = { put: putStub }
    })

    afterEach(()=> {
        sb.restore()
    })
   
    it('should define edit database connection route', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)

        // assert
        assert(putStub.calledOnce)
        
    })

    it('should set log message when getting file uploaded', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(1, req, res, nextStub)

        // assert
        assert(getUploadedFileStub.withArgs(req, res, nextStub, uploadObj, message).calledOnce)
    })  

    it('should set log message when setting up file cleanup', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(2, req, res, nextStub)

        // assert
        assert(cleanupFileStub.withArgs(req, res, nextStub, message).calledOnce)
    })  

    it('should set ecube info for checking ecube not exists', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(3, req, res, nextStub)

        // assert
        assert(ecubeExistsStub.withArgs(ecubeInfo, req, res, nextStub).calledOnce)
    })  

    it('should set ecube info for renaming ecube', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(4, req, res, nextStub)

        // assert
        assert(renameEcubeStub.withArgs(ecubeInfo, req, res, nextStub).calledOnce)
    })  

    it('should test database connection string', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(5, req, res, nextStub)

        // assert
        assert(testDatabaseConnectionStub.withArgs(req.params.ecubeName, req, res).calledOnce)
    })  

    it('should succeed running editDatabaseConnection', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(6, req, res)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof editDatabaseConnectionTaskStub).to.be.true
        assert(editDatabaseConnectionTaskStub.withArgs(ecubeInfo.ecubeName, Object.assign({}, editDatabaseConnectionInfo, { ecubeFilePath: filePath })).calledOnce)

        // act
        thenStub.callArgWith(0)
        
        // assert
        assert(endWithSuccessStub.withArgs(req, res, message).calledOnce)
    })

    it('should succeed running editDatabaseConnection with ecube file with no .ecube extension', () => { 
        // arrange
        const req1 = JSON.parse(JSON.stringify(req))
        req1.file.path = 'test'
        const filePath1 = `${path.join(path.dirname(req1.file.path), editDatabaseConnectionInfo.ecubeName)}${path.extname(req1.file.path)}`

        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(6, req1, res)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof editDatabaseConnectionTaskStub).to.be.true
        assert(editDatabaseConnectionTaskStub.withArgs(ecubeInfo.ecubeName, Object.assign({}, editDatabaseConnectionInfo, { ecubeFilePath: filePath1 })).calledOnce)

        // act
        thenStub.callArgWith(0)
        
        // assert
        assert(endWithSuccessStub.withArgs(req1, res, message).calledOnce)
    })

    it('should fail running editDatabaseConnection', () => { 
        // act 
        defineEditDatabaseConnectionRoute(app, uploadObj)
        putStub.callArgWith(6, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(nextStub.callCount).to.equal(0)
        expect(addTaskStub.args[0][0] instanceof editDatabaseConnectionTaskStub).to.be.true
        assert(editDatabaseConnectionTaskStub.withArgs(ecubeInfo.ecubeName, Object.assign({}, editDatabaseConnectionInfo, { ecubeFilePath: filePath })).calledOnce)

        // act
        const error = 'error occured'
        catchStub.callArgWith(0, error)
        
        // assert
        assert(endWithErrorStub.withArgs(req, res, error).calledOnce)

    })

})