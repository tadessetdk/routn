import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { log } from '../common'
import { definePingRoute } from './pingRoute'

const sb = sandbox.create()

describe('pingRoute', () => {
    
    const app: any = { get: ()=> {} }
    const res: any = { end: ()=> {} }

    let appGetStub, resEndStub, logTraceStub

    beforeEach(() => {  
        appGetStub = sb.stub(app, 'get')
        resEndStub = sb.stub(res, 'end')
        logTraceStub = sb.stub(log, 'trace')
    })

    afterEach(()=> {
        sb.restore()
    })
   
    it('should define ping route', () => { 
        // act 
        definePingRoute(app)

        // assert
        assert(appGetStub.withArgs('/').calledOnce)
    })

    it('should log trace and end', () => { 
        // act 
        definePingRoute(app)
        appGetStub.args[0][1](0, res)

        // assert
        assert(logTraceStub.withArgs('Ping').calledOnce)
        assert(resEndStub.calledOnce)
    })

})