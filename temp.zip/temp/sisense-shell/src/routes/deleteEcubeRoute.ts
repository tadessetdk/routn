import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import { ecubeExists } from './'
import { log, HttpError } from '../common'
import { IEcubeInfo } from '../prism'
import { taskManager, DeleteTask } from '../tasks'
export function defineDeleteEcubeRoute(app: express.Application) {    

    app.delete('/ecube/:ecubeName',
    (req: express.Request, res: express.Response, next)=> ecubeExists(getEcubeInfo(req), req, res, next), 
    (req: express.Request, res: express.Response)=> deleteEcube(req, res))

}

function deleteEcube(req: express.Request, res: express.Response){
    
    const ecubeInfo: IEcubeInfo = req.body
    ecubeInfo.ecubeName = getEcubeName(req)
    const logMessagePrefix = getLogMessagePrefix(req)
    log.request(req, logMessagePrefix)
  
    taskManager.addTask(new DeleteTask(ecubeInfo.ecubeName, ecubeInfo))
        .then(()=> log.endWithSuccess(req, res, logMessagePrefix, 204))
        .catch(err=> log.endWithError(req, res, err, logMessagePrefix))
        
}

function getEcubeInfo(req): any {
    return {
        ecubeName: getEcubeName(req),
        serverAddress: req.body.serverAddress
    }
}

function getEcubeName(req){
    return req.params.ecubeName
}

function getLogMessagePrefix(req){
    return `Sisense delete ecube for ${getEcubeName(req)} has`
}