import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import { ecubeNotExist } from './'
import { cleanupFile, getUploadedFile, log, HttpError } from '../common'
import { IEcdataInfo } from '../prism'
import { taskManager, ImportEcdataTask } from '../tasks'
export function defineImportEcdataRoute(app: express.Application, upload: multer.Instance) {    

    app.post('/ecube/importEcdata',
    (req: express.Request, res: express.Response, next)=> getUploadedFile(req, res, next, upload, getLogMessagePrefix(req), 'ecdataFile'), 
    (req: express.Request, res: express.Response, next)=> cleanupFile(req, res, next, getLogMessagePrefix(req)), 
    (req: express.Request, res: express.Response, next)=> ecubeNotExist(getEcubeInfo(req), req, res, next), 
    (req: express.Request, res: express.Response)=> importEcdata(req, res))

}

function importEcdata(req: express.Request, res: express.Response){
    
    const ecdataInfo: IEcdataInfo = req.body
    const logMessagePrefix = getLogMessagePrefix(req)
    ecdataInfo.ecdataFilePath = path.resolve(req.file.path)
    log.request(req, logMessagePrefix)
  
    taskManager.addTask(new ImportEcdataTask(ecdataInfo.ecubeName, ecdataInfo))
        .then(()=> log.endWithSuccess(req, res, logMessagePrefix, 201))
        .catch(err=> log.endWithError(req, res, err, logMessagePrefix))
}

function getEcubeInfo(req): any {
    return {
        ecubeName: getEcubeName(req),
        serverAddress: req.body.serverAddress
    }
}

function getEcubeName(req){
    return req.body.ecubeName
}

function getLogMessagePrefix(req){
    return `Sisense import ecdata for ${getEcubeName(req)} ecube has`
}