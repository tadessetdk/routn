import * as express from 'express'
import * as mssql from 'mssql'

import { log, HttpError } from '../common'
import { IEditDatabaseConnectionInfo } from '../prism'
import { validateDatabaseConnection } from '../tasks'

export function testDatabaseConnection(ecubeName: string, req: express.Request, res: express.Response, next){

      const dbInfo: IEditDatabaseConnectionInfo = req.body
      dbInfo.ecubeName = ecubeName

      const logMessagePrefix = `Test mssql database connection string for ${dbInfo.ecubeName} has`
      log.request(req, logMessagePrefix)

      const errorMessage = validateDatabaseConnection(dbInfo)
      if(errorMessage) {
            log.endWithError(req, res, <HttpError>{ statusCode: 400, message: errorMessage }, logMessagePrefix)
            return
      }

      const pool = new mssql.ConnectionPool(getDbConfig(dbInfo))
      pool.connect()
            .then(()=> {
                  log.response(req, res, logMessagePrefix)
                  pool.close()
                  next()
            })
            .catch(err=> {
                  pool.close()
                  log.errorWithCorrelation(req, err)
                  log.endWithError(req, res, <HttpError>{ statusCode: 400, message: 'Invalid new database connection string' }, logMessagePrefix)
            })

}

function getDbConfig(dbInfo: IEditDatabaseConnectionInfo) {
      return {
            user: dbInfo.newUsername,
            password: dbInfo.newPassword,
            server: dbInfo.newDatabaseServerName,
            database: dbInfo.newDatabaseName,
            options: {
                  encrypt: true
            }
      }
}