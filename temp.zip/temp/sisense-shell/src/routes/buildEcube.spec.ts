import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import { log } from '../common'
import { BuildMode, IBuildInfo } from '../prism'
import * as tasks from '../tasks'
import { buildEcube } from './buildEcube'

const sb = sandbox.create()

describe('buildEcube', () => {

    const ecubeName = 'ecubeName'
    const logMessagePrefix = 'logMessagePrefix'
    const statusCode = 201

    const buildInfo: IBuildInfo = { 
        ecubeName: ecubeName,
        ecubeFilePath: 'ecubeFilePath',
        mode: BuildMode.Restart
    }

    const req: any = {
        params: {
            ecubeName: buildInfo.ecubeName
        },
        body: {
             mode: BuildMode.Restart
        },
        file: { path: 'test.ecube' }
    }

    const filePath = `${path.join(path.dirname(req.file.path), buildInfo.ecubeName)}${path.extname(req.file.path)}`
    
    const res: any = {}

    let nextStub, addTaskStub, requestStub, buildTaskStub
    let thenStub, catchStub, thenStub2, endWithSuccessStub, endWithErrorStub
  
    beforeEach(() => {  
        buildTaskStub = sb.stub(tasks, 'BuildTask')
        nextStub = sb.stub()
        requestStub = sb.stub(log, 'request')
        endWithSuccessStub = sb.stub(log, 'endWithSuccess')
        endWithErrorStub = sb.stub(log, 'endWithError')

        thenStub2 = sb.stub()
        catchStub = sb.stub().returns({ then: thenStub2 })
        thenStub = sb.stub().returns({ 'catch': catchStub })
        addTaskStub = sb.stub(tasks.taskManager, 'addTask').returns({ then: thenStub })
    })

    afterEach(()=> {
        sb.restore()
    })
    
    function buildSuccess(req1, filePath1, statusCode = 200){
        // act 
        buildEcube(req1, res, ecubeName, logMessagePrefix, statusCode)

        // assert
        assert(requestStub.withArgs(req1, logMessagePrefix).calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof buildTaskStub).to.be.true
        assert(buildTaskStub.withArgs(buildInfo.ecubeName, Object.assign({}, buildInfo, { ecubeFilePath: filePath1 })).calledOnce)

        // act
        thenStub.callArgWith(0)
        
        // assert
        assert(endWithSuccessStub.withArgs(req1, res, logMessagePrefix, statusCode).calledOnce)
    }

    it('should succeed running buildEcube', () => { 
        buildSuccess(req, filePath)
    })

    it('should succeed running buildEcube for import', () => { 
        buildSuccess(req, filePath, 201)
    })

    it('should succeed running buildEcube for import with ecube file with no .ecube extension', () => { 
        // arrange
        const req1 = JSON.parse(JSON.stringify(req))
        req1.file.path = 'test'
        const filePath1 = `${path.join(path.dirname(req1.file.path), buildInfo.ecubeName)}${path.extname(req1.file.path)}`

        // assert
        buildSuccess(req1, filePath1)
    })

    it('should fail running buildEcube', () => { 
        // act 
        buildEcube(req, res, ecubeName, logMessagePrefix)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof buildTaskStub).to.be.true
        assert(buildTaskStub.withArgs(buildInfo.ecubeName, Object.assign({}, buildInfo, { ecubeFilePath: filePath })).calledOnce)

        // act
        const error = 'error occured'
        catchStub.callArgWith(0, error)
        
        // assert
        assert(endWithErrorStub.withArgs(req, res, error).calledOnce)

    })

})