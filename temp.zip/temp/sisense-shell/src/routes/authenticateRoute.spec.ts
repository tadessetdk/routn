import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'

import * as routeHelpers from './validateRequest'
import { defineAuthenticateRequestRoute } from './authenticateRoute'

const sb = sandbox.create()

describe('defineAuthenticateRequestRoute', () => {

    const req: any = {
       path: '/'
    }

    const res: any = {}

    let app, allStub, validateRequestStub, nextStub

    beforeEach(() => {  
        validateRequestStub = sb.stub(routeHelpers, 'validateRequest')
        nextStub = sb.stub()
        allStub = sb.stub()
        app = { all: allStub }
    })

    afterEach(()=> {
        sb.restore()
    })
   
    it('should define authenticateRequest route', () => { 
        // act 
        defineAuthenticateRequestRoute(app)

        // assert
        assert(allStub.withArgs('*').calledOnce)
        
    })

    it('should not authenticate root(ping) route', () => { 
        // act 
        defineAuthenticateRequestRoute(app)
        allStub.callArgWith(1, req, res, nextStub)

        // assert
        assert(nextStub.calledOnce)
    })  

    it('should authenticate all other route (than root)', () => { 
        // act 
        defineAuthenticateRequestRoute(app)
        const req1 = { path: '/ecube/import' }
        allStub.callArgWith(1, req1, res, nextStub)

        // assert
        expect(nextStub.callCount).to.equal(0)
        assert(validateRequestStub.withArgs(req1, res, nextStub).calledOnce)
    })  

})