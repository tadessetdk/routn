import * as express from 'express'
import * as path from 'path'

import { cleanupFile, getUploadedFile, log, HttpError } from '../common'
import { BuildMode, IBuildInfo, IEcubeInfo } from '../prism'
import { BuildTask, taskManager } from '../tasks'

export function buildEcube(req: express.Request, res: express.Response, 
                              ecubeName: string, logMessagePrefix: string, statusCode: number = 200) {
    
    const buildInfo: IBuildInfo = req.body
    buildInfo.ecubeName = ecubeName
    buildInfo.ecubeFilePath = `${path.join(path.dirname(req.file.path), buildInfo.ecubeName)}${path.extname(req.file.path)}`
    log.request(req, logMessagePrefix)
  
    taskManager.addTask(new BuildTask(buildInfo.ecubeName, buildInfo))
        .then(()=> log.endWithSuccess(req, res, logMessagePrefix, statusCode))
        .catch(err=> log.endWithError(req, res, err, logMessagePrefix))

}