import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import * as mssql from 'mssql'

import * as common from '../common'
import { IEditDatabaseConnectionInfo } from '../prism'
import * as tasks from '../tasks'
import * as routeHelpers from './'

const sb = sandbox.create()

describe('testDatabaseConnection', () => {

    const newDatabaseServerName = 'newDatabaseServerName'
    const newDatabaseName = 'newDatabaseName'
    const newUsername = 'newUsername'
    const newPassword = 'newPassword'
    const ecubeName = 'ecubeName'

    const editDatabaseConnectionInfo: IEditDatabaseConnectionInfo = { 
        ecubeName: ecubeName,
        newDatabaseServerName: newDatabaseServerName,
        newDatabaseName: newDatabaseName,
        newUsername: newUsername,
        newPassword: newPassword,
        databaseServerName: '',
        ecubeFilePath: ''
    }

    const req: any = {
        params: {
            ecubeName: ecubeName
        },
        body: {
            newDatabaseServerName: newDatabaseServerName,
            newDatabaseName: newDatabaseName,
            newUsername: newUsername,
            newPassword: newPassword
        }
    }

const res: any = {}

    const config = {
            user: newUsername,
            password: newPassword,
            server: newDatabaseServerName,
            database: newDatabaseName,
            options: {
                  encrypt: true
            }
      }

    const message = `Test mssql database connection string for ${ecubeName} has`

    let nextStub, requestStub, validateDatabaseConnectionStub
    let thenStub, catchStub, responseStub, endWithErrorStub, errorWithCorrelationStub
    let connectStub, connectionPoolStub, closeStub
   
    beforeEach(() => {  
        nextStub = sb.stub()
        requestStub = sb.stub(common.log, 'request')
        responseStub = sb.stub(common.log, 'response')
        errorWithCorrelationStub = sb.stub(common.log, 'errorWithCorrelation')
        endWithErrorStub = sb.stub(common.log, 'endWithError')

        catchStub = sb.stub()
        thenStub = sb.stub().returns({ 'catch': catchStub })
        connectStub = sb.stub().returns({ then: thenStub })
        closeStub = sb.stub()
        connectionPoolStub = sb.stub(mssql, 'ConnectionPool').returns({ connect: connectStub, close: closeStub })
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should succeed testing database connection', () => { 
        // arrange 
        validateDatabaseConnectionStub = sb.stub(tasks, 'validateDatabaseConnection')

        // act 
        routeHelpers.testDatabaseConnection(ecubeName, req, res, nextStub)

        // assert
        assert(requestStub.withArgs(req, message).calledOnce)
        assert(connectionPoolStub.withArgs(config).calledOnce)
        assert(thenStub.calledOnce)
        assert(connectStub.calledOnce)
        
        // act
        thenStub.callArgWith(0)
        
        // assert
        assert(responseStub.withArgs(req, res, message).calledOnce)
        assert(nextStub.calledOnce)
        assert(closeStub.calledOnce)
        
    })

    it('should not test database connection when connection-string is invalid', () => { 
        // arrange
        const error = 'error occured'
        validateDatabaseConnectionStub = sb.stub(tasks, 'validateDatabaseConnection').returns(error)

        // act 
        routeHelpers.testDatabaseConnection(ecubeName, req, res, nextStub)

        // assert
        assert(requestStub.withArgs(req, message).calledOnce)
        expect(connectionPoolStub.callCount).to.equal(0)
        expect(nextStub.callCount).to.equal(0)
        assert(endWithErrorStub.withArgs(req, res, { statusCode: 400, message: error }, message).calledOnce)
        
    })

    it('should fail test connection string', () => { 
        /// arrange 
        validateDatabaseConnectionStub = sb.stub(tasks, 'validateDatabaseConnection')
        const error = { message: 'error occured' }

        // act 
        routeHelpers.testDatabaseConnection(ecubeName, req, res, nextStub)

        // assert
        assert(requestStub.withArgs(req, message).calledOnce)
        assert(connectionPoolStub.withArgs(config).calledOnce)
        assert(connectStub.calledOnce)
        assert(catchStub.calledOnce)
        
        // act
        catchStub.callArgWith(0, error)
        
        // assert
        assert(errorWithCorrelationStub.withArgs(req, error).calledOnce)
        assert(endWithErrorStub.withArgs(req, res, { statusCode: 400, message: 'Invalid new database connection string' }, message).calledOnce)
        assert(closeStub.calledOnce)
    })

})