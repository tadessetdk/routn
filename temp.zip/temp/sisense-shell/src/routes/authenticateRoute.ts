import * as express from 'express'

import { validateRequest } from './validateRequest'

export function defineAuthenticateRequestRoute(app) { 
    app.all('*', (req: express.Request, res: express.Response, next)=> {
        req.path === '/' ? next() : validateRequest(req, res, next)
    })
}