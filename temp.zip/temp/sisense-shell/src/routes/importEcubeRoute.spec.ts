import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import * as common from '../common'
import * as routeHelpers from './'
import { defineImportEcubeRoute } from './importEcubeRoute'

const sb = sandbox.create()

describe('importEcubeRoute', () => {

    const req: any = {
        body: {
            ecubeName: 'ecubeName',
            serverAddress: 'serverAddress'
        },
        file: { path: 'test' }
    }
    const ecubeInfo = {
        ecubeName: req.body.ecubeName,
        ecubeFilePath: path.resolve(req.file.path),
        serverAddress: req.body.serverAddress
    }
    const message = `Sisense import ecube for ${req.body.ecubeName} has`
    const res: any = {}

    let getUploadedFileStub, cleanupFileStub, ecubeNotExistStub, renameEcubeStub, buildEcubeStub, nextStub
    let app, singleStub, postStub
    let uploadObj

    beforeEach(() => {  
        uploadObj = <any>{ single: singleStub }
        nextStub = sb.stub()
        getUploadedFileStub = sb.stub(common, 'getUploadedFile')
        cleanupFileStub = sb.stub(common, 'cleanupFile')
        buildEcubeStub = sb.stub(routeHelpers, 'buildEcube')
        ecubeNotExistStub = sb.stub(routeHelpers, 'ecubeNotExist')
        renameEcubeStub = sb.stub(routeHelpers, 'renameEcube')
        singleStub = sb.stub()
        postStub = sb.stub()
        app = { post: postStub }
    })

    afterEach(()=> {
        sb.restore()
    })
   
    it('should define import ecube route', () => { 
        // act 
        defineImportEcubeRoute(app, uploadObj)

        // assert
        assert(postStub.calledOnce)  
    })

    it('should set log message when getting file uploaded', () => { 
        // act 
        defineImportEcubeRoute(app, uploadObj)
        postStub.callArgWith(1, req, res, nextStub)

        // assert
        assert(getUploadedFileStub.withArgs(req, res, nextStub, uploadObj, message).calledOnce)
    })  

    it('should set log message when setting up file cleanup', () => { 
        // act 
        defineImportEcubeRoute(app, uploadObj)
        postStub.callArgWith(2, req, res, nextStub)

        // assert
        assert(cleanupFileStub.withArgs(req, res, nextStub, message).calledOnce)
    })  

    it('should set ecube info for checking ecube not exists', () => { 
        // act 
        defineImportEcubeRoute(app, uploadObj)
        postStub.callArgWith(3, req, res, nextStub)

        // assert
        assert(ecubeNotExistStub.withArgs(ecubeInfo, req, res, nextStub).calledOnce)
    })  

    it('should set ecube info for renaming ecube', () => { 
        // act 
        defineImportEcubeRoute(app, uploadObj)
        postStub.callArgWith(4, req, res, nextStub)

        // assert
        assert(renameEcubeStub.withArgs(ecubeInfo, req, res, nextStub).calledOnce)
    })  

    it('should set log message when building ecube', () => { 
        // act 
        defineImportEcubeRoute(app, uploadObj)
        postStub.callArgWith(5, req, res, nextStub)

        // assert
        assert(buildEcubeStub.withArgs(req, res, req.body.ecubeName, message, 201).calledOnce)
    })  

})