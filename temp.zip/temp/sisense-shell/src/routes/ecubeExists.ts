import * as express from 'express'

import { log, HttpError } from '../common'
import { EcubeExistsTask, taskManager } from '../tasks'
import { IEcubeInfo } from '../prism'

export function ecubeNotExist(ecubeInfo: IEcubeInfo, req: express.Request, res: express.Response, next) {

    const logMessagePrefix = `Sisense ecube not exist for ${ecubeInfo.ecubeName} has`
    log.request(req, logMessagePrefix)

    taskManager.addTask(new EcubeExistsTask(ecubeInfo.ecubeName, ecubeInfo))
        .then(()=> {
            log.endWithError(req, res, <HttpError>{ statusCode: 409, message: `ecube "${ecubeInfo.ecubeName}" already exists` }, logMessagePrefix)
        })
        .catch(err=> {
            if(err.statusCode === 400){
                log.endWithError(req, res, err, logMessagePrefix)
            } else {
                log.response(req, res, logMessagePrefix)
                next()
            }
        })
            
}

export function ecubeExists(ecubeInfo: IEcubeInfo, req: express.Request, res: express.Response, next) {

    const logMessagePrefix = `Sisense ecube exists for ${ecubeInfo.ecubeName} has`
    log.request(req, logMessagePrefix)

    taskManager.addTask(new EcubeExistsTask(ecubeInfo.ecubeName, ecubeInfo))
        .then(()=>{
             next()
             log.response(req, res, logMessagePrefix)
        })
        .catch(err=> {
            if(err.statusCode === 400){
                log.endWithError(req, res, err, logMessagePrefix)
            } else {
                log.endWithError(req, res, <HttpError>{ statusCode: 404, message: `Ecube ${ecubeInfo.ecubeName} is not found` }, logMessagePrefix)
            }
        })
            
}