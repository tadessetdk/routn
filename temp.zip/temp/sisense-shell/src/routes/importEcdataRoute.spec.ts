import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import * as common from '../common'
import * as routeHelpers from './'
import { IEcdataInfo } from '../prism'
import * as tasks from '../tasks'
import { defineImportEcdataRoute } from './importEcdataRoute'

const sb = sandbox.create()

describe('defineImportEcdataRoute', () => {

    const req: any = {
        body: {
            ecubeName: 'ecubeName',
            serverAddress: 'serverAddress'
        },
        file: { path: 'test' }
    }

    const ecdataInfo: IEcdataInfo = {
        ecubeName: req.body.ecubeName,
        ecdataFilePath: path.resolve(req.file.path),
        serverAddress: req.body.serverAddress
    }

    const body = Object.assign({}, ecdataInfo, { ecubeName: '' })

    const message = `Sisense import ecdata for ${req.body.ecubeName} ecube has`
    let uploadObj
    const res: any = {}

    let getUploadedFileStub, cleanupFileStub, ecubeNotExistStub
    let nextStub, addTaskStub, requestStub, importEcdataTaskStub
    let thenStub, catchStub, thenStub2, endWithSuccessStub, endWithErrorStub
    let app, singleStub, postStub

    beforeEach(() => {  
        importEcdataTaskStub = sb.stub(tasks, 'ImportEcdataTask')
        uploadObj = <any>{ single: singleStub }
        getUploadedFileStub = sb.stub(common, 'getUploadedFile')
        cleanupFileStub = sb.stub(common, 'cleanupFile')
        ecubeNotExistStub = sb.stub(routeHelpers, 'ecubeNotExist')

        nextStub = sb.stub()
        requestStub = sb.stub(common.log, 'request')
        endWithSuccessStub = sb.stub(common.log, 'endWithSuccess')
        endWithErrorStub = sb.stub(common.log, 'endWithError')

        thenStub2 = sb.stub()
        catchStub = sb.stub().returns({ then: thenStub2 })
        thenStub = sb.stub().returns({ 'catch': catchStub })
        addTaskStub = sb.stub(tasks.taskManager, 'addTask').returns({ then: thenStub })

        singleStub = sb.stub()
        postStub = sb.stub()
        app = { post: postStub }
    })

    afterEach(()=> {
        sb.restore()
    })
   
    it('should define import ecdata route', () => { 
        // act 
        defineImportEcdataRoute(app, uploadObj)

        // assert
        assert(postStub.calledOnce)
        
    })

    it('should set log message when getting file uploaded', () => { 
        // act 
        defineImportEcdataRoute(app, uploadObj)
        postStub.callArgWith(1, req, res, nextStub)

        // assert
        assert(getUploadedFileStub.withArgs(req, res, nextStub, uploadObj, message).calledOnce)
    })  

    it('should set log message when setting up file cleanup', () => { 
        // act 
        defineImportEcdataRoute(app, uploadObj)
        postStub.callArgWith(2, req, res, nextStub)

        // assert
        assert(cleanupFileStub.withArgs(req, res, nextStub, message).calledOnce)
    })  

    it('should set ecdata info for checking ecube not exists task', () => { 
        // act 
        defineImportEcdataRoute(app, uploadObj)
        postStub.callArgWith(3, req, res, nextStub)

        // assert
        assert(ecubeNotExistStub.withArgs({ ecubeName: ecdataInfo.ecubeName, serverAddress: ecdataInfo.serverAddress }, 
                                                req, res, nextStub).calledOnce)
    })  

    it('should succeed running importEcdata', () => { 
        // act 
        defineImportEcdataRoute(app, uploadObj)
        postStub.callArgWith(4, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof importEcdataTaskStub).to.be.true
        assert(importEcdataTaskStub.withArgs(ecdataInfo.ecubeName, ecdataInfo).calledOnce)

        // act
        thenStub.callArgWith(0)
        
        // assert
        expect(body.ecdataFilePath).to.equal(ecdataInfo.ecdataFilePath)
        assert(endWithSuccessStub.withArgs(req, res, message, 201).calledOnce) 
    })

    it('should fail running importEcdata', () => { 
        // act 
        defineImportEcdataRoute(app, uploadObj)
        postStub.callArgWith(4, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(nextStub.callCount).to.equal(0)
        expect(addTaskStub.args[0][0] instanceof importEcdataTaskStub).to.be.true
        assert(importEcdataTaskStub.withArgs(ecdataInfo.ecubeName, ecdataInfo).calledOnce)

        // act
        const error = 'error occured'
        catchStub.callArgWith(0, error)
        
        // assert
        assert(endWithErrorStub.withArgs(req, res, error).calledOnce)

    })

})