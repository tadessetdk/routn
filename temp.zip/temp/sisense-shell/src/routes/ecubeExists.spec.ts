import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import { log, HttpError } from '../common'
import * as tasks from '../tasks'
import { IEcubeInfo } from '../prism'
import { ecubeExists, ecubeNotExist } from './ecubeExists'

const sb = sandbox.create()

describe('ecubeNotExist', () => {

    const req: any = {}, res: any = {}
   
    let ecubeInfo: IEcubeInfo = { 
         ecubeName: 'ecubeName',
         ecubeFilePath: 'ecubeFilePath',
         serverAddress: ''
    }

    let nextStub, addTaskStub, requestStub, responseStub, ecubeExistsTaskStub
    let thenStub, catchStub, endWithErrorStub

    beforeEach(() => {  
        ecubeExistsTaskStub = sb.stub(tasks, 'EcubeExistsTask')
        nextStub = sb.stub()
        requestStub = sb.stub(log, 'request')
        endWithErrorStub = sb.stub(log, 'endWithError')
        responseStub = sb.stub(log, 'response')

        catchStub = sb.stub()
        thenStub = sb.stub().returns({ 'catch': catchStub })
        addTaskStub = sb.stub(tasks.taskManager, 'addTask').returns({ then: thenStub })
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should succeed running ecubeNotExist', () => { 
        // act 
        ecubeNotExist(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof ecubeExistsTaskStub).to.be.true
        assert(ecubeExistsTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        thenStub.callArgWith(0)

        // assert
        assert(endWithErrorStub.withArgs(req, res, <HttpError>{ statusCode: 409, message: `ecube "${ecubeInfo.ecubeName}" already exists` })
                                .calledOnce)
    })

    it('should fail running ecubeNotExist on argument validation error', () => { 
        // act 
        ecubeNotExist(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof ecubeExistsTaskStub).to.be.true
        assert(ecubeExistsTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        const error = { statusCode: 400 }
        catchStub.callArgWith(0, error)

        // assert
        assert(endWithErrorStub.withArgs(req, res, error).calledOnce)
    })

    it('should fail running ecubeNotExist if ecube exists', () => { 
        // act 
        ecubeNotExist(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof ecubeExistsTaskStub).to.be.true
        assert(ecubeExistsTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        const error = { statusCode: 409 }
        catchStub.callArgWith(0, error)

        // assert
        assert(responseStub.calledOnce)
        assert(nextStub.calledOnce)
        
    })

})

describe('ecubeExists', () => {

    const req: any = {}, res: any = {}
   
    let ecubeInfo: IEcubeInfo = { 
         ecubeName: 'ecubeName',
         ecubeFilePath: 'ecubeFilePath',
         serverAddress: ''
    }

    let nextStub, addTaskStub, requestStub, responseStub, ecubeExistsTaskStub
    let thenStub, catchStub, endWithErrorStub

    beforeEach(() => {  
        ecubeExistsTaskStub = sb.stub(tasks, 'EcubeExistsTask')
        nextStub = sb.stub()
        requestStub = sb.stub(log, 'request')
        endWithErrorStub = sb.stub(log, 'endWithError')
        responseStub = sb.stub(log, 'response')

        catchStub = sb.stub()
        thenStub = sb.stub().returns({ 'catch': catchStub })
        addTaskStub = sb.stub(tasks.taskManager, 'addTask').returns({ then: thenStub })
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should succeed running existingEcubeRoute', () => { 
        // act 
        ecubeExists(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof ecubeExistsTaskStub).to.be.true
        assert(ecubeExistsTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        thenStub.callArgWith(0)

        // assert
        assert(responseStub.calledOnce)
        assert(nextStub.calledOnce)
    })

    it('should fail running existingEcubeRoute on argument validation error', () => { 
        // act 
        ecubeExists(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof ecubeExistsTaskStub).to.be.true
        assert(ecubeExistsTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        const error = { statusCode: 400 }
        catchStub.callArgWith(0, error)

        // assert
        assert(endWithErrorStub.withArgs(req, res, error).calledOnce)
    })

    it('should fail running existingEcubeRoute if ecube does not exists', () => { 
        // act 
        ecubeExists(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof ecubeExistsTaskStub).to.be.true
        assert(ecubeExistsTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        const error = { statusCode: 404 }
        catchStub.callArgWith(0, error)

        // assert
        assert(endWithErrorStub.withArgs(req, res, <HttpError>{ statusCode: 404, message: `Ecube ${ecubeInfo.ecubeName} is not found` }).calledOnce)    
    })

})