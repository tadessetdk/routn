import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import { log } from '../common'
import * as tasks from '../tasks'
import { IEcubeInfo } from '../prism'
import { renameEcube } from './renameEcube'

const sb = sandbox.create()

describe('renameEcube', () => {

    const req: any = {}, res: any = {}
   
    let ecubeInfo: IEcubeInfo = { 
         ecubeName: 'ecubeName',
         ecubeFilePath: 'ecubeFilePath',
         serverAddress: ''
    }

    let nextStub, addTaskStub, requestStub, renameTaskStub
    let thenStub, catchStub, endWithErrorStub

    beforeEach(() => {  
        renameTaskStub = sb.stub(tasks, 'RenameTask')
        nextStub = sb.stub()
        requestStub = sb.stub(log, 'request')
        endWithErrorStub = sb.stub(log, 'endWithError')

        catchStub = sb.stub()
        thenStub = sb.stub().returns({ 'catch': catchStub })
        addTaskStub = sb.stub(tasks.taskManager, 'addTask').returns({ then: thenStub })
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should succeed running renameEcube', () => { 
        // act 
        renameEcube(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof renameTaskStub).to.be.true
        assert(renameTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        //act
        thenStub.callArgWith(0)
        assert(nextStub.calledOnce)
        
    })

    it('should fail running renameEcube', () => { 
        // act 
        renameEcube(ecubeInfo, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof renameTaskStub).to.be.true
        assert(renameTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        //act
        catchStub.callArgWith(0)
        assert(endWithErrorStub.withArgs(req, res).calledOnce)
    })

})