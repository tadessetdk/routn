import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { log } from '../common'
import { validateRequest } from './validateRequest'

const sb = sandbox.create()

describe('validateRequest', () => {
    
    const validToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjZWMwMjU5ZS02YzllLTRlODQtOGYzYi0yZTgzZWQyNjVlOWMiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9lNTM2YzFlZC00ODIyLTRiODgtOGMwMS05ZjE0YzFjNTgzZTMvIiwiaWF0IjoxNDk1MTMxOTI3LCJuYmYiOjE0OTUxMzE5MjcsImV4cCI6MTQ5ODI0NTQ1MCwiYWNyIjoiMSIsImFpbyI6IlkyWmdZRGo3THRqR29zeGdRVXplcFpvSHg2OHdTTlhYMmVSUFZqOGU5L1Myb0U1cjQxd0EiLCJhbXIiOlsicHdkIl0sImFwcGlkIjoiNjc1YTlmM2UtYzc4YS00OGNjLTkxNTEtNTlkMTRhYzIyMDViIiwiYXBwaWRhY3IiOiIwIiwiZV9leHAiOjI2MjgwMCwiZmFtaWx5X25hbWUiOiJBZG1pbiIsImdpdmVuX25hbWUiOiJVT00gQXBwbGljYXRpb24iLCJpcGFkZHIiOiIxMi4xNjkuNzEuNCIsIm5hbWUiOiJVT01BcHBsaWNhdGlvbkFkbWluIiwib2lkIjoiNmY1ODdiYmUtYjNkYS00YTViLWI0YWQtNDllODhkOGRmZTY2IiwicGxhdGYiOiIxNCIsInJvbGVzIjpbIkRhdGFJc29sYXRpb25Bc3NpZ24iXSwic2NwIjoidXNlcl9pbXBlcnNvbmF0aW9uIiwic3ViIjoibDY4Qk1MSXJIZlRSYTZiUE1wRVR3RUlfSksyNVhRWXZ1WGdsaTkxeE1UYyIsInRpZCI6ImU1MzZjMWVkLTQ4MjItNGI4OC04YzAxLTlmMTRjMWM1ODNlMyIsInVuaXF1ZV9uYW1lIjoiVU9NQXBwbGljYXRpb25BZG1pbkBoZWFsdGhjbG91ZGJpZGV2MDEub25taWNyb3NvZnQuY29tIiwidXBuIjoiVU9NQXBwbGljYXRpb25BZG1pbkBoZWFsdGhjbG91ZGJpZGV2MDEub25taWNyb3NvZnQuY29tIiwidmVyIjoiMS4wIiwianRpIjoiNzc2ZjE4NmEtY2I2Ny00ZDBmLWE1OWQtZGJlODY2ZDFhZTczIn0.uSKulQJcNbt6a-m57Riqel5YV2Xc-PGG1gbARROTQd8'
    const invalidToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjZWMwMjU5ZS02YzllLTRlODQtOGYzYi0yZTgzZWQyNjVlOWMiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9lNTM2YzFlZC00ODIyLTRiODgtOGMwMS05ZjE0YzFjNTgzZTMvIiwiaWF0IjoxNDk1MTMxOTI3LCJuYmYiOjE0OTUxMzE5MjcsImV4cCI6MTQ5NTY1NjE3OSwiYWNyIjoiMSIsImFpbyI6IlkyWmdZRGo3THRqR29zeGdRVXplcFpvSHg2OHdTTlhYMmVSUFZqOGU5L1Myb0U1cjQxd0EiLCJhbXIiOlsicHdkIl0sImFwcGlkIjoiNjc1YTlmM2UtYzc4YS00OGNjLTkxNTEtNTlkMTRhYzIyMDViIiwiYXBwaWRhY3IiOiIwIiwiZV9leHAiOjI2MjgwMCwiZmFtaWx5X25hbWUiOiJBZG1pbiIsImdpdmVuX25hbWUiOiJVT00gQXBwbGljYXRpb24iLCJpcGFkZHIiOiIxMi4xNjkuNzEuNCIsIm5hbWUiOiJSZWdpc3RyYXIiLCJvaWQiOiI2ZjU4N2JiZS1iM2RhLTRhNWItYjRhZC00OWU4OGQ4ZGZlNjYiLCJwbGF0ZiI6IjE0Iiwicm9sZXMiOlsiUmVnaXN0cmFyIl0sInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6Imw2OEJNTElySGZUUmE2YlBNcEVUd0VJX0pLMjVYUVl2dVhnbGk5MXhNVGMiLCJ0aWQiOiJlNTM2YzFlZC00ODIyLTRiODgtOGMwMS05ZjE0YzFjNTgzZTMiLCJ1bmlxdWVfbmFtZSI6IlVPTUFwcGxpY2F0aW9uQWRtaW5AaGVhbHRoY2xvdWRiaWRldjAxLm9ubWljcm9zb2Z0LmNvbSIsInVwbiI6IlVPTUFwcGxpY2F0aW9uQWRtaW5AaGVhbHRoY2xvdWRiaWRldjAxLm9ubWljcm9zb2Z0LmNvbSIsInZlciI6IjEuMCIsImp0aSI6ImE2NDY0MDBjLTljYjEtNGVkMy05NDg3LWM0MDdjNjVjOWRhZSJ9.WxpnrtGZBnZYmpGkPteZBHlTN3mTySzbndQ9Mga3JeY'
    const badToken = 'WETERTRT4354534534RTERT345=='

    const req: any = {  
        headers: {
            authorization: ''
        }
    }

    const res: any = { }

    let nextStub, endWithErrorStub, infoWithCorrelationStub, errorWithCorrelationdStub

    beforeEach(() => {  
        nextStub = sb.stub()
        endWithErrorStub = sb.stub(log, 'endWithError')
        infoWithCorrelationStub = sb.stub(log, 'infoWithCorrelation')
        errorWithCorrelationdStub = sb.stub(log, 'errorWithCorrelation')
    })

    afterEach(()=> {
        sb.restore()
    })

    it('should fail authorization when no token', () => { 
        // arrange 
        req.headers.authorization = ''

        // act 
        validateRequest(req, res, nextStub)
    
        // assert
        assert(endWithErrorStub.withArgs(req, res, { message: 'No valid token', statusCode: 401 }, 'ValidateRequest').calledOnce)
        expect(nextStub.callCount).to.equal(0)
        expect(errorWithCorrelationdStub.callCount).to.equal(0) 
    })

    it('should fail authorization when bad token', () => { 
        // arrange 
        req.headers.authorization = `Bearer ${badToken}`

        // act 
        validateRequest(req, res, nextStub)

        // assert
        assert(endWithErrorStub.withArgs(req, res, { message: 'User is not authorized to make the request', statusCode: 403 }, 'ValidateAadToken').calledOnce)
        expect(nextStub.callCount).to.equal(0)
        expect(errorWithCorrelationdStub.callCount).to.be.at.least(1) 
    })

    it('should fail authorization on valid but unauthorized session', () => { 
        // arrange 
        req.headers.authorization = `Bearer ${invalidToken}`
        
        // act 
        validateRequest(req, res, nextStub)

        // assert
        assert(endWithErrorStub.withArgs(req, res, { message: 'User is not authorized to make the request', statusCode: 403 }, 'ValidateAadToken').calledOnce)
        expect(nextStub.callCount).to.equal(0) 
        expect(errorWithCorrelationdStub.callCount).to.equal(0) 
    })

    it('should succeed authorization', () => { 
        // arrange 
        req.headers.authorization = `Bearer ${validToken}`

        // act 
        validateRequest(req, res, nextStub)

        // assert
        assert(infoWithCorrelationStub.withArgs(req, `User AAD authorization succeeded`).calledOnce)
        expect(errorWithCorrelationdStub.callCount).to.equal(0) 
        assert(nextStub.calledOnce)
    })

})