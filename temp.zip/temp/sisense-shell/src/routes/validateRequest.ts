import * as express from 'express'
import * as atob from 'atob'

import { appSettings, log } from '../common'

export function validateRequest(req: express.Request, res: express.Response, next) {

    const authToken = (req.headers['authorization'] || '').replace('Bearer ', '').trim()

    if(!authToken){   
        log.endWithError(req, res, <any>{ message: 'No valid token', statusCode: 401 }, 'ValidateRequest')    
        return            
    }

    validateAadToken(req, res, authToken, next)
}

function validateAadToken(req: express.Request, res: express.Response, authToken: string, next){
    
    const roles = getRoles(req, authToken) || []

    if(roles.some(r=> r.toUpperCase() === 'DATAISOLATIONASSIGN')){
        log.infoWithCorrelation(req, `User AAD authorization succeeded`)
        next()
    } else {
        log.endWithError(req, res, <any>{ message: 'User is not authorized to make the request', statusCode: 403 }, 'ValidateAadToken')  
    }

}

function getRoles(req, token: string): Array<string> {

    if (!token) {
        log.errorWithCorrelation(req, 'Invalid auth token')
        return
    }

    let parts = token.split('.')
    if (parts.length !== 3) {
        log.errorWithCorrelation(req, 'JWT must have 3 parts')
        return
    }

    let decoded = urlBase64Decode(req, parts[1])

    if (!decoded) {
        log.errorWithCorrelation(req, 'Cannot decode the token')
        return
    }

    try {
        const tokenInfoRaw = JSON.parse(decoded)
        return tokenInfoRaw.roles
    } catch(e) {
        log.errorWithCorrelation(req, e)
    }

}

function urlBase64Decode(req, str: string) {

    let output = str.replace(/-/g, '+').replace(/_/g, '/')
    switch (output.length % 4) {
        case 0: 
            break

        case 2: 
            output += '==' 
            break

        case 3: 
            output += '='
            break

        default:
            log.errorWithCorrelation(req, 'Illegal base64 url string')
            return
    }     
    return atob(output) 

}