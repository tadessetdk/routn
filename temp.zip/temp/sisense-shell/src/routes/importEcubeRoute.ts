import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import { ecubeNotExist, buildEcube, renameEcube } from './'
import { cleanupFile, getUploadedFile, log, HttpError } from '../common'
import { IEcubeInfo } from '../prism'
export function defineImportEcubeRoute(app: express.Application, upload: multer.Instance) {    

    app.post('/ecube/import',
    (req: express.Request, res: express.Response, next)=> getUploadedFile(req, res, next, upload, getLogMessagePrefix(req)), 
    (req: express.Request, res: express.Response, next)=> cleanupFile(req, res, next, getLogMessagePrefix(req)), 
    (req: express.Request, res: express.Response, next)=> ecubeNotExist(getEcubeInfo(req), req, res, next), 
    (req: express.Request, res: express.Response, next)=> renameEcube(getEcubeInfo(req), req, res, next),
    (req: express.Request, res: express.Response)=> buildEcube(req, res, getEcubeName(req), getLogMessagePrefix(req), 201))

}

function getEcubeInfo(req): IEcubeInfo {
    return {
        ecubeName: getEcubeName(req),
        ecubeFilePath: path.resolve(req.file.path),
        serverAddress: req.body.serverAddress
    }
}

function getEcubeName(req){
    return req.body.ecubeName
}

function getLogMessagePrefix(req){
    return `Sisense import ecube for ${getEcubeName(req)} has`
}