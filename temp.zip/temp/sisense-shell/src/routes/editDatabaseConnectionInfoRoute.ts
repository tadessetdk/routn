import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import { cleanupFile, getUploadedFile, log, HttpError } from '../common'
import { ecubeExists, buildEcube, renameEcube, testDatabaseConnection } from './'
import { EditDatabaseConnectionTask, RenameTask, taskManager } from '../tasks'
import { BuildMode, IEcubeInfo, IEditDatabaseConnectionInfo } from '../prism'

export function defineEditDatabaseConnectionRoute(app: express.Application, upload: multer.Instance) {    

    app.put('/ecube/:ecubeName/editDatabaseConnection',
    (req: express.Request, res: express.Response, next)=> getUploadedFile(req, res, next, upload, getLogMessagePrefix(req)),
    (req: express.Request, res: express.Response, next)=> cleanupFile(req, res, next, getLogMessagePrefix(req)), 
    (req: express.Request, res: express.Response, next)=> ecubeExists(getEcubeInfo(req), req, res, next), 
    (req: express.Request, res: express.Response, next)=> renameEcube(getEcubeInfo(req), req, res, next), 
    (req: express.Request, res: express.Response, next)=> testDatabaseConnection(getEcubeName(req), req, res, next), 
    (req: express.Request, res: express.Response)=> editDatabaseConnection(req, res))
    
}

function editDatabaseConnection(req: express.Request, res: express.Response){
    
    const dbInfo: IEditDatabaseConnectionInfo = req.body
    dbInfo.ecubeName = getEcubeName(req)
    const logMessagePrefix = getLogMessagePrefix(req)
    dbInfo.ecubeFilePath = `${path.join(path.dirname(req.file.path), dbInfo.ecubeName)}${path.extname(req.file.path)}`
    
    log.request(req, logMessagePrefix)
  
    taskManager.addTask(new EditDatabaseConnectionTask(dbInfo.ecubeName, dbInfo))
        .then(()=> log.endWithSuccess(req, res, logMessagePrefix))
        .catch(err=> log.endWithError(req, res, err, logMessagePrefix))

}

function getEcubeInfo(req): IEcubeInfo {
    return {
        ecubeName: getEcubeName(req),
        ecubeFilePath: path.resolve(req.file.path),
        serverAddress: req.body.serverAddress
    }
}

function getEcubeName(req){
    return req.params.ecubeName
}

function getLogMessagePrefix(req){
    return `Sisense edit database connection for ${getEcubeName(req)} has`
}