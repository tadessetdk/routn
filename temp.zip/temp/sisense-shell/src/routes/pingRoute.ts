import * as express from 'express'
import { log } from '../common'

export function definePingRoute(app: express.Application) {

    app.get('/', (req, res)=> {
         log.trace('Ping')
         res.end()
    })

}