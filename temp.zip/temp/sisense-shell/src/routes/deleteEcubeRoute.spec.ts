import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as express from 'express'
import * as multer from 'multer'
import * as path from 'path'

import * as common from '../common'
import * as routeHelpers from './'
import { IEcubeInfo } from '../prism'
import * as tasks from '../tasks'
import { defineDeleteEcubeRoute } from './deleteEcubeRoute'

const sb = sandbox.create()

describe('defineDeleteEcubeRoute', () => {

    const serverAddress ='serverAddress' 

    const req: any = {
        params: {
            ecubeName: 'ecubeName'
        },
        body: { serverAddress: serverAddress }
    }

    const ecubeInfo = {
        ecubeName: req.params.ecubeName,
        serverAddress: serverAddress
    }

    const message = `Sisense delete ecube for ${req.params.ecubeName} has`
    const res: any = {}

    let ecubeExistsStub, deleteTaskStub
    let nextStub, addTaskStub, requestStub
    let thenStub, catchStub, thenStub2, endWithSuccessStub, endWithErrorStub
    let app, deleteStub

    beforeEach(() => {  
        deleteTaskStub = sb.stub(tasks, 'DeleteTask')
        ecubeExistsStub = sb.stub(routeHelpers, 'ecubeExists')
       
        nextStub = sb.stub()
        requestStub = sb.stub(common.log, 'request')
        endWithSuccessStub = sb.stub(common.log, 'endWithSuccess')
        endWithErrorStub = sb.stub(common.log, 'endWithError')

        thenStub2 = sb.stub()
        catchStub = sb.stub().returns({ then: thenStub2 })
        thenStub = sb.stub().returns({ 'catch': catchStub })
        addTaskStub = sb.stub(tasks.taskManager, 'addTask').returns({ then: thenStub })

        deleteStub = sb.stub()
        app = { delete: deleteStub }
    })

    afterEach(()=> {
        sb.restore()
    })
   
    it('should define edit database connection route', () => { 
        // act 
        defineDeleteEcubeRoute(app)

        // assert
        assert(deleteStub.calledOnce)
        
    })

    it('should check ecube exists', () => { 
        // act 
        defineDeleteEcubeRoute(app)
        deleteStub.callArgWith(1, req, res, nextStub)

        // assert
        assert(ecubeExistsStub.withArgs(ecubeInfo, req, res, nextStub).calledOnce)
    })  

    it('should succeed running deleteEcube', () => { 
        // act 
        defineDeleteEcubeRoute(app)
        deleteStub.callArgWith(2, req, res)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(addTaskStub.args[0][0] instanceof deleteTaskStub).to.be.true
        assert(deleteTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        thenStub.callArgWith(0)
        
        // assert
        assert(endWithSuccessStub.withArgs(req, res, message, 204).calledOnce) 
    })

    it('should fail running deleteEcube', () => { 
        // act 
        defineDeleteEcubeRoute(app)
        deleteStub.callArgWith(2, req, res, nextStub)

        // assert
        assert(requestStub.calledOnce)
        assert(addTaskStub.calledOnce)
        expect(nextStub.callCount).to.equal(0)
        expect(addTaskStub.args[0][0] instanceof deleteTaskStub).to.be.true
        assert(deleteTaskStub.withArgs(ecubeInfo.ecubeName, ecubeInfo).calledOnce)

        // act
        const error = 'error occured'
        catchStub.callArgWith(0, error)
        
        // assert
        assert(endWithErrorStub.withArgs(req, res, error).calledOnce)

    })

})