import * as express from 'express'

import { log } from '../common'
import { RenameTask, taskManager } from '../tasks'
import { IEcubeInfo } from '../prism'

export function renameEcube(info: IEcubeInfo, req: express.Request, res: express.Response, next){
    
    const logMessagePrefix = `Sisense ecube rename for ${info.ecubeName} has`
    log.request(req, logMessagePrefix)
    
    taskManager.addTask(new RenameTask(info.ecubeName, info))
        .then(()=> next())
        .catch(err=> log.endWithError(req, res, err, logMessagePrefix))
}