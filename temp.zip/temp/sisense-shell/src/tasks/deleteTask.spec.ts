import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { Provides } from 'typescript-ioc'

import { HttpError } from '../common'
import { Prism, IEcubeInfo } from '../prism'
import { BaseTask, DeleteTask } from './'
import { deletePromise } from './testMocks'

const sb = sandbox.create()

describe('deleteTask', () => {
    
    let deleteCalled

    const ecubeInfo: IEcubeInfo = { 
        ecubeName: 'ecubeName',
        ecubeFilePath: '',
        serverAddress: 'serverAddress'
    }

    beforeEach(() => {  
        deleteCalled = false
    })

    afterEach(()=> {
        sb.restore()
    })

    it('creates delete task', () => { 
        // act 
        const task = new DeleteTask(ecubeInfo.ecubeName, ecubeInfo)

        // assert 
        expect(task).to.not.be.undefined
    })

    function testTaskSuccess(ecubeInfo, done){

        // arrange 
        const task = new DeleteTask(ecubeInfo.ecubeName, ecubeInfo)

        deletePromise.then(val=> {
            deleteCalled = val
        })

        // act
        task.execute()
            .then(()=> {
                // assert
                expect(deleteCalled).to.be.true
                done()
            })

    }

    it('execute delete task successfully', (done) => { 
        testTaskSuccess(ecubeInfo, done)
    })

    function testValidationFailures(bInfo, errorMessage, done){
        // arrange 
        const task = new DeleteTask(bInfo && bInfo.ecubeName, bInfo)

        // act
        task.execute()
            .catch(err=> {
                // assert
                expect(err).to.deep.equal({ statusCode: 400, message: errorMessage })
                done()
            })

    }

    it('failed to execute delete task due to invalid ecube info', (done) => { 
       testValidationFailures(0, 'Invalid ecube information', done)
    })
    
    it('failed to execute delete task due to invalid ecubeName', (done) => { 
       testValidationFailures({ ecubeName: '', serverAddress: 'serverAddress' }, 'Invalid ecube name', done)
    })

    it('serverAddress is optional', (done) => { 
       testTaskSuccess({ ecubeName: 'ecubeName', serverAddress: '' }, done)
    })

})