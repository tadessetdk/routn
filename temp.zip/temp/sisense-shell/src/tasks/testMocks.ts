import { Provides } from 'typescript-ioc'

import { Prism, IBuildInfo, IEditDatabaseConnectionInfo, IEcubeInfo, IEcdataInfo } from '../prism'

export const buildPromise: Promise<any> = Promise.resolve(true)
export const deletePromise: Promise<any> = Promise.resolve(true)
export const editDatabaseConnectionPromise: Promise<any> = Promise.resolve(true)
export const existsPromise: Promise<any> = Promise.resolve(true)
export const importEcdataPromise: Promise<any> = Promise.resolve(true)
export const renamePromise: Promise<any> = Promise.resolve(true)

@Provides(Prism)
class MockPrism extends Prism {

      build(info: IBuildInfo): Promise<any> { 
            return buildPromise
      }

      delete(info: IEcubeInfo): Promise<any> { 
            return deletePromise
      }

      editDatabaseConnection(info: IEditDatabaseConnectionInfo): Promise<any> { 
            return editDatabaseConnectionPromise
      }

      exists(info: IEcubeInfo): Promise<any> { 
            return existsPromise
      }

      importEcdata(info: IEcdataInfo): Promise<any> { 
            return importEcdataPromise
      }

      rename(info: IEcubeInfo): Promise<any> { 
            return renamePromise
      }

}