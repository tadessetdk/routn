import { HttpError } from '../common'
import { Prism, IEcdataInfo } from '../prism'
import { BaseTask, ITask } from './'

export class ImportEcdataTask extends BaseTask implements ITask{
    
    constructor(public ecubeName, private importInfo: IEcdataInfo){
       super(ecubeName)
    }

    execute(): Promise<any>{   

        return new Promise((resolve, reject)=> this.validateInput(resolve, reject))
                    .then(()=> this.prism.importEcdata(this.importInfo))

    }

     private validateInput(resolve: ()=> void, reject: (err: HttpError)=> void) {    
        
        let errorMessage; 

        if(!this.importInfo){
            errorMessage = 'Invalid ecdata import information'
        } else {
            if(!this.importInfo.ecubeName || !this.importInfo.ecubeName.trim()){
                errorMessage = 'Invalid ecube name'
            } else if(!this.importInfo.ecdataFilePath){
                errorMessage = 'Invalid ecdata file path'
            }
        }

        super.resolve(resolve, reject, errorMessage)

    }

}