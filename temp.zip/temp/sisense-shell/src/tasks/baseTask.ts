import { Inject } from 'typescript-ioc'

import { HttpError } from '../common'
import { Prism } from '../prism'

export class BaseTask {
    @Inject
    protected prism: Prism
    
    constructor(public ecubeName: string) { }

    protected resolve(resolve: ()=> void, reject: (err: HttpError)=> void, errorMessage: string) {  
        
        if(errorMessage){
            reject(<HttpError>{ statusCode: 400, message: errorMessage })
        } else {
            resolve();
        }

    }  
    
}