import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { Provides } from 'typescript-ioc'

import { HttpError } from '../common'
import { Prism, BuildMode, IBuildInfo } from '../prism'
import { BaseTask, BuildTask } from './'
import { buildPromise } from './testMocks'

const sb = sandbox.create()

describe('buildTask', () => {
    
    let buildCalled

    const buildInfo: IBuildInfo = { 
        ecubeName: 'ecubeName',
        ecubeFilePath: 'ecubeFilePath',
        mode: BuildMode.Restart
    }

    beforeEach(() => {  
        buildCalled = false
    })

    afterEach(()=> {
        sb.restore()
    })

    it('creates build task', () => { 
        // act 
        const task = new BuildTask(buildInfo.ecubeName, buildInfo)

        // assert 
        expect(task).to.not.be.undefined
    })

    it('execute build task successfully', (done) => { 
        // arrange 
        const task = new BuildTask(buildInfo.ecubeName, buildInfo)

        buildPromise.then(val=> {
            buildCalled = val
        })

        // act
        task.execute()
            .then(()=> {
                // assert
                expect(buildCalled).to.be.true
                done()
            })
    })

    function testValidation(bInfo, errorMessage, done){
        // arrange 
        const task = new BuildTask(bInfo && bInfo.ecubeName, bInfo)

        // act
        task.execute()
            .catch(err=> {
                // assert
                expect(err).to.deep.equal({ statusCode: 400, message: errorMessage })
                done()
            })

    }

    it('failed to execute build task due to invalid ecube info', (done) => { 
       testValidation(0, 'Invalid build information', done)
    })
    
    it('failed to execute build task due to invalid ecubeName', (done) => { 
       testValidation({ ecubeName: '', ecubeFilePath: 'ecubeFilePath', mode: BuildMode.Restart }, 'Invalid ecube name', done)
    })

    it('failed to execute build task due to invalid ecube file path', (done) => { 
       testValidation({ ecubeName: 'ecubeName', ecubeFilePath: '', mode: BuildMode.Restart }, 'Invalid ecube file path', done)
    })

    it('failed to execute build task due to invalid build mode', (done) => { 
       testValidation({ ecubeName: 'ecubeName', ecubeFilePath: 'ecubeFilePath', mode: 'TEST' }, 'Invalid build mode', done)
    })

})