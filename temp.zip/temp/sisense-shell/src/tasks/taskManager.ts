import * as async from 'async'
import { appSettings, HttpError, log } from '../common'
import { Prism } from '../prism'

export interface ITask{
    ecubeName: string;
    execute: ()=> Promise<any>;
    promise?: { resolve: ()=> void; reject: (err: Error)=> void };
}

export class TaskManager {
    private concurrency = appSettings.concurrentTasksQueueLimit
    private taskQueue: AsyncQueue<ITask>
    private ecubeList: Array<string> = []

    constructor() {
        this.init()
    }

    init() {
        
        this.taskQueue = async.queue((task: ITask, callback)=> {
            
            task.execute()
                .then(()=> {
                    this.removeTaskFromList(task, callback)
                    task.promise.resolve()
                })
                .catch(err=> {
                    this.removeTaskFromList(task, callback)
                    task.promise.reject(err)
                })

        }, this.concurrency)

        this.taskQueue.drain = this.onDrain
        this.taskQueue.saturated = this.onSaturated

    }

    addTask(task: ITask) {

        return new Promise((resolve, reject)=> {

            if(this.ecubeList.some(n=> n === task.ecubeName)) {
                reject(<HttpError>{ statusCode: 409, message: `Only one command can be processed on an ecube at a time, ecube name = ${task.ecubeName}` })
                return;
            }
            
            task.promise = { resolve: resolve, reject: reject }
            this.ecubeList.push(task.ecubeName)
            this.taskQueue.push(task, err=> {
                (err && log.debug(err));
            })

        })
       
    }

    removeTaskFromList(task: ITask, callback){

        const index = this.ecubeList.indexOf(task.ecubeName)
        if(index !== -1 ) this.ecubeList.splice(index, 1)
        callback()

    }

    onDrain(){
        log.info('all tasks have been processed.')
    }

    onSaturated(){
        log.info('the tasks list has filled up, and queuing new requests.')
    }
}

export const taskManager = new TaskManager()