import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import * as async from 'async'
import { appSettings, HttpError, log } from '../common'
import { Prism } from '../prism'

import { TaskManager, ITask} from './taskManager'

const sb = sandbox.create()

describe('taskManager', () => {
   
    let taskManager
    let asyncQueueStub
    let queueLimitStub
    const queueLimit = 5

    let task: ITask
    let thenStub, catchStub

    let logInfoStub
    let pushStub

    beforeEach(() => {  
        logInfoStub = sb.stub(log, 'info')

        pushStub = sb.stub()
        asyncQueueStub = sb.stub(async, 'queue').returns({ drain: '', push: pushStub, saturated: '' })
       
        catchStub = sb.stub()
        thenStub = sb.stub().returns({ 'catch': catchStub })
       
        task = {  
            ecubeName: 'ecubeName',
            execute: sb.stub().returns({ then: thenStub })
        }

        appSettings.concurrentTasksQueueLimit = queueLimit
        taskManager = new TaskManager()
    })

    afterEach(()=> {
        sb.restore()
    })

    it('add task', () => { 
        // act 
        const prm = taskManager.addTask(task)

        // assert
        expect(task.promise).to.be.defined
        expect(asyncQueueStub.args[0][1]).to.equal(queueLimit)
        expect(pushStub.callCount).to.be.at.least(1)
    })

    it('execute task', done => { 
        // arrange
        let taskCompleted
        const cb = ()=> {
            taskCompleted = true
        }

        // act 
        const prm = taskManager.addTask(task)
        asyncQueueStub.callArgWith(0, task, cb)
        thenStub.callArgWith(0)

        // assert
        prm.then(()=> {
            expect(taskCompleted).to.be.true
            done()
        })
    })
    
    it('fail to execute task', done => { 
        let taskCompleted
        const cb = ()=> {
            taskCompleted = true
        }

        // act 
        const prm = taskManager.addTask(task)
        asyncQueueStub.callArgWith(0, task, cb)
        const error = 'error'
        catchStub.callArgWith(0, error)

        // assert
        prm.catch(err=> {
            expect(err).to.equal(error)
            expect(taskCompleted).to.be.true
            done()
        })
    })

    it('should not add same task at same time', done => { 
        // act 
        const prm = taskManager.addTask(task)
        taskManager.addTask(task)
            .catch(err=> {
                // assert
                expect(err).to.deep.equal({ statusCode: 409, message: `Only one command can be processed on an ecube at a time, ecube name = ${task.ecubeName}` })
                done()
            })
    })

    it('should add different task at same time', () => { 
         // act 
        const prm = taskManager.addTask(task)
        const newTask = Object.assign({}, task, { ecubeName: 'newEcube' })
        taskManager.addTask(newTask)

        expect(newTask.promise).to.be.defined
        expect(pushStub.callCount).to.be.at.least(2)
          
    })

    it('should log drain event', () => { 
        // act 
        taskManager.onDrain()

        // verify
        assert(logInfoStub.withArgs('all tasks have been processed.').calledOnce)   
    })

    it('should log saturation event', () => { 
        // act 
        taskManager.onSaturated()

        // verify
        assert(logInfoStub.withArgs('the tasks list has filled up, and queuing new requests.').calledOnce)  
    })

})