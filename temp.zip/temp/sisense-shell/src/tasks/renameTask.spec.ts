import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { Provides } from 'typescript-ioc'

import { HttpError } from '../common'
import { Prism, IEcubeInfo } from '../prism'
import { BaseTask, RenameTask } from './'
import { renamePromise } from './testMocks'

const sb = sandbox.create()

describe('renameTask', () => {

    let renameCalled

    const ecubeInfo: IEcubeInfo = { 
        ecubeName: 'ecubeName',
        ecubeFilePath: 'ecubeFilePath',
        serverAddress: 'serverAddress'
    }

    beforeEach(() => {  
        renameCalled = false
    })

    afterEach(()=> {
        sb.restore()
    })

    it('creates rename task', () => { 
        // act 
        const task = new RenameTask(ecubeInfo.ecubeName, ecubeInfo)

        // assert 
        expect(task).to.not.be.undefined
    })

    it('execute rename task successfully', (done) => { 
         // arrange 
        const task = new RenameTask(ecubeInfo.ecubeName, ecubeInfo)

        renamePromise.then(val=> {
            renameCalled = val
        })

        // act
        task.execute()
            .then(()=> {
                // assert
                expect(renameCalled).to.be.true
                done()
            })
    })

    function testValidationFailures(bInfo, errorMessage, done){
        // arrange 
        const task = new RenameTask(bInfo && bInfo.ecubeName, bInfo)

        // act
        task.execute()
            .catch(err=> {
                // assert
                expect(err).to.deep.equal({ statusCode: 400, message: errorMessage })
                done()
            })

    }

    it('failed to execute rename task due to invalid ecube info', (done) => { 
       testValidationFailures(0, 'Invalid rename information', done)
    })
    
    it('failed to execute rename task due to invalid ecubeName', (done) => { 
       testValidationFailures({ ecubeName: '', ecubeFilePath: 'ecubeFilePath', serverAddress: 'serverAddress' }, 'Invalid ecube name', done)
    })

    it('failed to execute rename task due to invalid ecube file path', (done) => { 
       testValidationFailures({ ecubeName: 'ecubeName', ecubeFilePath: '', serverAddress: 'serverAddress' }, 'Invalid ecube file path', done)
    })

})