export function validateDatabaseConnection(dbConnectionInfo): string {
      if(!dbConnectionInfo){
            return 'Invalid database connection information'
      } else {
            if(isInvalidString(dbConnectionInfo.ecubeName)) {
                  return 'Invalid ecube name'
            } else if(isInvalidString(dbConnectionInfo.ecubeFilePath)) {
                  return 'Invalid ecube file path'
            } else if(isInvalidString(dbConnectionInfo.databaseServerName)) {
                  return 'Invalid source database server name'
            } else if(isInvalidString(dbConnectionInfo.newDatabaseServerName)) {
                  return 'Invalid new database server name'
            } else if(isInvalidString(dbConnectionInfo.newDatabaseName)) {
                  return 'Invalid new database name'
            } else if(isInvalidString(dbConnectionInfo.newUsername)) {
                  return 'Invalid new username'
            } else if(isInvalidString(dbConnectionInfo.newPassword)) {
                  return 'Invalid new password'
            }
      }

      return ''
}

function isInvalidString(input: string){
      return !input || !input.trim()
}