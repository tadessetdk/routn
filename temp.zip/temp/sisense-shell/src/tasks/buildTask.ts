import { Inject } from 'typescript-ioc'

import { HttpError } from '../common'
import { Prism, BuildMode, IBuildInfo } from '../prism'
import { BaseTask, ITask } from './'

export class BuildTask extends BaseTask implements ITask{
    
    constructor(public ecubeName, private buildInfo: IBuildInfo){
       super(ecubeName)
    }

    execute(): Promise<any> {   

        return new Promise((resolve, reject)=> this.validateInput(resolve, reject))
                        .then(()=> this.prism.build(this.buildInfo))

    }

    private validateInput(resolve: ()=> void, reject: (err: HttpError)=> void) {    
        
        let errorMessage; 

        if(!this.buildInfo){
            errorMessage = 'Invalid build information'
        } else {
            if(!this.buildInfo.ecubeName){
                errorMessage = 'Invalid ecube name'
            } else if(!this.buildInfo.ecubeFilePath){
                errorMessage = 'Invalid ecube file path'
            } else if(!this.isValidBuildMode()){
                errorMessage = 'Invalid build mode'
            }
        }

        super.resolve(resolve, reject, errorMessage)

    }

    private isValidBuildMode(){
        return !this.buildInfo.mode || this.buildInfo.mode === BuildMode.Restart
    }

}