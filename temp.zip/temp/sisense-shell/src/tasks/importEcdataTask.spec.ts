import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { Provides } from 'typescript-ioc'

import { HttpError } from '../common'
import { Prism, IEcdataInfo } from '../prism'
import { BaseTask, ImportEcdataTask } from './'
import { importEcdataPromise } from './testMocks'

const sb = sandbox.create()

describe('importEcdataTask', () => {
    
    let importEcdataCalled

    const ecdataInfo: IEcdataInfo = { 
        ecubeName: 'ecubeName',
        ecdataFilePath: 'ecdataFilePath',
        serverAddress: 'serverAddress'
    }

    beforeEach(() => {  
        importEcdataCalled = false
    })

    afterEach(()=> {
        sb.restore()
    })

    it('creates importEcdata task', () => { 
        // act 
        const task = new ImportEcdataTask(ecdataInfo.ecubeName, ecdataInfo)

        // assert 
        expect(task).to.not.be.undefined
    })

    function testTaskSuccess(ecdataInfo, done){

        // arrange 
        const task = new ImportEcdataTask(ecdataInfo.ecubeName, ecdataInfo)

        importEcdataPromise.then(val=> {
            importEcdataCalled = val
        })

        // act
        task.execute()
            .then(()=> {
                // assert
                expect(importEcdataCalled).to.be.true
                done()
            })

    }

    it('execute importEcdata task successfully', (done) => { 
        testTaskSuccess(ecdataInfo, done)
    })

    function testValidationFailures(info, errorMessage, done){
        // arrange 
        const task = new ImportEcdataTask(info && info.ecubeName, info)

        // act
        task.execute()
            .catch(err=> {
                // assert
                expect(err).to.deep.equal({ statusCode: 400, message: errorMessage })
                done()
            })

    }

    it('failed to execute importEcdata task due to invalid ecdata import info', (done) => { 
       testValidationFailures(0, 'Invalid ecdata import information', done)
    })
    
    it('failed to execute importEcdata task due to invalid ecubeName', (done) => { 
       testValidationFailures({ ecubeName: '', ecdataFilePath: 'ecdataFilePath', serverAddress: 'serverAddress' }, 'Invalid ecube name', done)
    })

    it('failed to execute importEcdata task due to invalid ecdataFilePath', (done) => { 
       testValidationFailures({ ecubeName: 'ecubeName', ecdataFilePath: '', serverAddress: 'serverAddress' }, 'Invalid ecdata file path', done)
    })

    it('serverAddress is optional', (done) => { 
       testTaskSuccess({ ecubeName: 'ecubeName', ecdataFilePath: 'ecdataFilePath', serverAddress: '' }, done)
    })

})