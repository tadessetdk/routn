import { HttpError } from '../common'
import { Prism, IEcubeInfo } from '../prism'
import { BaseTask, ITask } from './'

export class RenameTask extends BaseTask implements ITask{
    
    constructor(public ecubeName, private renameInfo: IEcubeInfo){
       super(ecubeName)
    }

    execute(): Promise<any>{   

        return new Promise((resolve, reject)=> this.validateInput(resolve, reject))
                    .then(()=> this.prism.rename(this.renameInfo))

    }

     private validateInput(resolve: ()=> void, reject: (err: HttpError)=> void) {    
        
        let errorMessage; 

        if(!this.renameInfo){
            errorMessage = 'Invalid rename information'
        } else {
            if(!this.renameInfo.ecubeName || !this.renameInfo.ecubeName.trim()){
                errorMessage = 'Invalid ecube name'
            } else if(!this.renameInfo.ecubeFilePath){
                errorMessage = 'Invalid ecube file path'
            }
        }

        super.resolve(resolve, reject, errorMessage)

    }

}