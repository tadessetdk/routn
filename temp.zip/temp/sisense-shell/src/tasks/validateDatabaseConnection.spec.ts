import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { IEditDatabaseConnectionInfo } from '../prism'
import { validateDatabaseConnection } from './'

const sb = sandbox.create()

describe('validateDatabaseConnection', () => {

    const editDatabaseConnectionInfo: IEditDatabaseConnectionInfo = { 
        ecubeName: 'ecubeName',
        ecubeFilePath: 'ecubeFilePath',
        databaseServerName: 'databaseServerName',
        newDatabaseServerName: 'newDatabaseServerName',
        newDatabaseName: 'newDatabaseName',
        newUsername: 'newUsername',
        newPassword: 'newPassword'
    }

    beforeEach(() => {  
       
    })

    afterEach(()=> {
        sb.restore()
    })

    function testValidation(dbInfo, errorMessage) {
        const err = validateDatabaseConnection(dbInfo)
        expect(err).to.deep.equal(errorMessage)
    }

    it('succeeds validating database connection information', () => { 
       testValidation(editDatabaseConnectionInfo, '')
    })

    it('failed to execute editDatabaseConnection task due to invalid database connection information', () => { 
       testValidation(0, 'Invalid database connection information')
    })
    
    it('failed to execute editDatabaseConnection task due to invalid ecubeName', () => { 
       testValidation(Object.assign({}, editDatabaseConnectionInfo, { ecubeName: '' }), 'Invalid ecube name')
    })

    it('failed to execute editDatabaseConnection task due to invalid ecube file path', () => { 
       testValidation(Object.assign({}, editDatabaseConnectionInfo, { ecubeFilePath: '' }), 'Invalid ecube file path')
    })

    it('failed to execute editDatabaseConnection task due to invalid new database server name', () => { 
       testValidation(Object.assign({}, editDatabaseConnectionInfo, { newDatabaseServerName: '' }), 'Invalid new database server name')
    })

    it('failed to execute editDatabaseConnection task due to invalid source database server name', () => { 
       testValidation(Object.assign({}, editDatabaseConnectionInfo, { databaseServerName: '' }), 'Invalid source database server name')
    })

    it('failed to execute editDatabaseConnection task due to invalid new database name', () => { 
       testValidation(Object.assign({}, editDatabaseConnectionInfo, { newDatabaseName: '' }), 'Invalid new database name')
    })

    it('failed to execute editDatabaseConnection task due to invalid new username', () => { 
       testValidation(Object.assign({}, editDatabaseConnectionInfo, { newUsername: '' }), 'Invalid new username')
    })

    it('failed to execute editDatabaseConnection task due to invalid new password', () => { 
       testValidation(Object.assign({}, editDatabaseConnectionInfo, { newPassword: '' }), 'Invalid new password')
    })

})