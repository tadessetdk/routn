import { HttpError } from '../common'
import { Prism, IEcubeInfo } from '../prism'
import { BaseTask, ITask } from './'

export class EcubeExistsTask extends BaseTask implements ITask{
    
    constructor(public ecubeName, private ecubeInfo: IEcubeInfo){
        super(ecubeName)
    }
  
    execute(): Promise<any> {   

        return new Promise((resolve, reject)=> this.validateInput(resolve, reject))
                        .then(()=> this.prism.exists(this.ecubeInfo))

    }

    private validateInput(resolve: ()=> void, reject: (err: HttpError)=> void) {    
        
        let errorMessage; 

        if(!this.ecubeInfo){
            errorMessage = 'Invalid ecube information'
        } else {
            if(!this.ecubeInfo.ecubeName || !this.ecubeInfo.ecubeName.trim()){
                errorMessage = 'Invalid ecube name'
            }
        }
        
        super.resolve(resolve, reject, errorMessage)

    }

}