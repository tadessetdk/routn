import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { Provides } from 'typescript-ioc'

import { Prism, IEditDatabaseConnectionInfo } from '../prism'
import { BaseTask, EditDatabaseConnectionTask } from './'
import { editDatabaseConnectionPromise } from './testMocks'

const sb = sandbox.create()

describe('editDatabaseConnectionTask', () => {
    
    let editDatabaseConnectionCalled

    const editDatabaseConnectionInfo: IEditDatabaseConnectionInfo = { 
        ecubeName: 'ecubeName',
        ecubeFilePath: 'ecubeFilePath',
        databaseServerName: 'databaseServerName',
        newDatabaseServerName: 'newDatabaseServerName',
        newDatabaseName: 'newDatabaseName',
        newUsername: 'newUsername',
        newPassword: 'newPassword'
    }

    beforeEach(() => {  
        editDatabaseConnectionCalled = false
    })

    afterEach(()=> {
        sb.restore()
    })

    it('creates editDatabaseConnection task', () => { 
        // act 
        const task = new EditDatabaseConnectionTask(editDatabaseConnectionInfo.ecubeName, editDatabaseConnectionInfo)

        // assert 
        expect(task).to.not.be.undefined
    })

    it('execute editDatabaseConnection task successfully', (done) => { 
        // arrange 
        const task = new EditDatabaseConnectionTask(editDatabaseConnectionInfo.ecubeName, editDatabaseConnectionInfo)

        editDatabaseConnectionPromise.then(val=> {
            editDatabaseConnectionCalled = val
        })

        // act
        task.execute()
            .then(()=> {
                // assert
                expect(editDatabaseConnectionCalled).to.be.true
                done()
            })
    })

})