import { describe, it, beforeEach, afterEach } from 'mocha'
import { expect, assert } from 'chai'
import { sandbox } from 'sinon'

import { Provides } from 'typescript-ioc'

import { HttpError } from '../common'
import { Prism, IEcubeInfo } from '../prism'
import { BaseTask, EcubeExistsTask } from './'
import { existsPromise } from './testMocks'

const sb = sandbox.create()

describe('existsTask', () => {
    
    let existsCalled

    const ecubeInfo: IEcubeInfo = { 
        ecubeName: 'ecubeName',
        ecubeFilePath: 'ecubeFilePath',
        serverAddress: 'serverAddress'
    }

    beforeEach(() => {  
        existsCalled = false
    })

    afterEach(()=> {
        sb.restore()
    })

    it('creates exists task', () => { 
        // act 
        const task = new EcubeExistsTask(ecubeInfo.ecubeName, ecubeInfo)

        // assert 
        expect(task).to.not.be.undefined
    })

    function testTaskSuccess(ecubeInfo, done){

        // arrange 
        const task = new EcubeExistsTask(ecubeInfo.ecubeName, ecubeInfo)

        existsPromise.then(val=> {
            existsCalled = val
        })

        // act
        task.execute()
            .then(()=> {
                // assert
                expect(existsCalled).to.be.true
                done()
            })

    }

    it('execute exists task successfully', (done) => { 
        testTaskSuccess(ecubeInfo, done)
    })

    function testValidationFailures(bInfo, errorMessage, done){
        // arrange 
        const task = new EcubeExistsTask(bInfo && bInfo.ecubeName, bInfo)

        // act
        task.execute()
            .catch(err=> {
                // assert
                expect(err).to.deep.equal({ statusCode: 400, message: errorMessage })
                done()
            })

    }

    it('failed to execute exists task due to invalid ecube info', (done) => { 
       testValidationFailures(0, 'Invalid ecube information', done)
    })
    
    it('failed to execute exists task due to invalid ecubeName', (done) => { 
       testValidationFailures({ ecubeName: '', ecubeFilePath: 'ecubeFilePath', serverAddress: 'serverAddress' }, 'Invalid ecube name', done)
    })

    it('serverAddress is optional', (done) => { 
       testTaskSuccess({ ecubeName: 'ecubeName', ecubeFilePath: 'ecubeFilePath', serverAddress: '' }, done)
    })

})