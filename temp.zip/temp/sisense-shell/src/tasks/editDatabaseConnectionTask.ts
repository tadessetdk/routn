import { HttpError } from '../common'
import { Prism, IEditDatabaseConnectionInfo } from '../prism'
import { BaseTask, ITask, validateDatabaseConnection } from './'

export class EditDatabaseConnectionTask extends BaseTask implements ITask {
    
    constructor(public ecubeName, private dbConnectionInfo: IEditDatabaseConnectionInfo){
        super(ecubeName)
    }

    execute(): Promise<any>{   

        return new Promise((resolve, reject)=> this.validateInput(resolve, reject))
                    .then(()=> this.prism.editDatabaseConnection(this.dbConnectionInfo))

    }

    private validateInput(resolve: ()=> void, reject: (err: HttpError)=> void) {    
        
        let errorMessage = validateDatabaseConnection(this.dbConnectionInfo) 
        super.resolve(resolve, reject, errorMessage)

    }
}