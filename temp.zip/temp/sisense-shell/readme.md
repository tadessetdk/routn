# Sisense Prism Shell Web Service

## Steps to Build

1.  install `Nodejs 7.0.0 or higher version` on target machine
2.  `git clone git@github.build.ge.com:evergreen/sisense-shell-webservice.git`
3.  `cd /sisense-shell-webservice`
4.  run `npm install` 
5.  add the environment variable below

## To run the API locally

1.  run `npm start`
2.  The API will run at http://localhost:9000

## To run Unit Tests

1.  run `npm test`

## Environment variables

SISENSE_SHELL_WEB_SERVICE_SETTINGS = {
    concurrentTasksQueueLimit: 10,
    sisenseApiUri: 'http://localhost:8083/api/v1',
    logLevel: 'info'
}