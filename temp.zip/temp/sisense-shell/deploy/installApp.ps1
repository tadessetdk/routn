param (
    [Parameter(Mandatory = $true)]
    [string] $appVersion, # e.g. "0.1.44",

    [Parameter(Mandatory = $true)]
    [string] $vmHostname, # e.g. "analytics-int-cd7.westus.cloudapp.azure.com",

    [Parameter(Mandatory = $false)]
    [string] $storageAccountResourceGroup = "gehc-healthcareinsights-bi-artifacts",

    [Parameter(Mandatory = $false)]
    [string] $storageAccountName = "gehcbiartifactsdev",

    [Parameter(Mandatory = $false)]
    [string] $networkSecurityGroupName = "SisenseNSG",

    [Parameter(Mandatory = $false)]
    [string] $networkResourceGroupName = "GEHC-HealthcareInsights-BI-Network-Dev",

    [Parameter(Mandatory = $false)]
    [string] $winRmHttpNsgRulePriority = 100,

    [Parameter(Mandatory = $false)]
    [string] $winRmHttpsNsgRulePriority = 101,

    [parameter(Mandatory = $false)]
    [string]$AutomationAccountResourceGroup = "GEHC-HealthcareInsights-BI-Automation",

    [parameter(Mandatory = $false)]
    [string]$AutomationAccount = "GEHC-HealthcareInsights-BI-AutomationAccount"
)

$ErrorActionPreference = "Stop"

#***************** Deploy Sisense Shell Web Service to INT VM *****************#

$JobStatus = "Unknown"
try{
    #---- Login to Azure -----#
    ../jenkins-scripts/azure-login.ps1

    #------ Setup Arguments and Execute Runbook ----#
    $RunbookName = "deploy-sisense-shell-webservice"

    $params = @{
        "storageAccountResourceGroup" = $storageAccountResourceGroup
        "storageAccountName" = $storageAccountName
        "appVersion" = $appVersion
        "vmHostname" = $vmHostname
        "networkSecurityGroupName" = $networkSecurityGroupName
        "networkResourceGroupName" = $networkResourceGroupName
        "winRmHttpNsgRulePriority" = $winRmHttpNsgRulePriority
        "winRmHttpsNsgRulePriority" = $winRmHttpsNsgRulePriority
    }

    $DeployAppsJob = Start-AzureRmAutomationRunbook `
        -AutomationAccountName $AutomationAccount `
        -Name $RunbookName `
        -ResourceGroupName $AutomationAccountResourceGroup `
        -Parameters $params

    write-host "Successfully started the runbook $RunbookName"

    # Wait for runbook to complete
    $RunbookJobComplete = $false
    While (!$RunbookJobComplete) {
        #sleep for 20 seconds, and then check job status.
        Start-Sleep -s 20
        $Job = Get-AzureRmAutomationJob `
            -AutomationAccountName $AutomationAccount `
            -Id $DeployAppsJob.JobId `
            -ResourceGroupName $AutomationAccountResourceGroup
        $JobStatus = $Job.Status
        $RunbookJobComplete = (($JobStatus -eq "Completed") -or ($JobStatus -eq "Failed") -or ($JobStatus -eq "Suspended") -or ($JobStatus -eq "Stopped"))
        if (!$RunbookJobComplete) {
            write-host "Runbook $RunbookName is still running."
        } else {
            write-host "Runbook $RunbookName finished with status" $JobStatus
        }
    }
}
catch {
    echo "Caught an exception: " + $_.Exception
    write-host "Caught an exception:" + $_.Exception
    exit 1
}

if ($JobStatus -ne "Completed") {
    $JobOutput = Get-AzureRmAutomationJobOutput `
            -AutomationAccountName $AutomationAccount `
            -Id $DeployAppsJob.JobId `
            -ResourceGroupName $AutomationAccountResourceGroup

    $JobOutput | format-list -force

    throw ("Runbook $RunbookName with job id $DeployAppsJob.JobId failed with status $JobStatus")
}
