# https://github.com/Azure/azure-quickstart-templates/blob/master/201-vm-winrm-windows/ConfigureWinRM.ps1

param
(
    [Parameter( Mandatory = $true)]
    [string] $vmHostname, # e.g. "analytics-int-cd7.westus.cloudapp.azure.com",
    [Parameter( Mandatory = $true)]
    [string] $proxyWsPublicIpAddress # e.g.  "104.129.192.109"
)

function Delete-WinRMListener{
    $config = Winrm enumerate winrm/config/listener
    foreach($conf in $config) {
        if($conf.Contains("HTTPS")) {
            Write-Verbose "HTTPS is already configured. Deleting the exisiting configuration."
            winrm delete winrm/config/Listener?Address=*+Transport=HTTPS
            break
        }
    }
}

function Configure-WinRMHttpsListener {
    param([string] $hostname)

    # Delete the WinRM Https listener if it is already configured
    Delete-WinRMListener

    # Create a test certificate
    $thumbprint = (Get-ChildItem cert:\LocalMachine\My | Where-Object { $_.Subject -eq "CN=" + $hostname } | Select-Object -Last 1).Thumbprint
    if(-not $thumbprint) {
        .\makecert -r -pe -n CN=$hostname -b 01/01/2012 -e 01/01/2022 -eku 1.3.6.1.5.5.7.3.1 -ss my -sr localmachine -sky exchange -sp "Microsoft RSA SChannel Cryptographic Provider" -sy 12
        $thumbprint=(Get-ChildItem cert:\Localmachine\my | Where-Object { $_.Subject -eq "CN=" + $hostname } | Select-Object -Last 1).Thumbprint

        if(-not $thumbprint) {
            throw "Failed to create the test certificate."
        }
    }   

    $createCmd = 'winrm create winrm/config/Listener?Address=*+Transport=HTTPS ' + (@{Hostname="""$hostname""";CertificateThumbprint="""$thumbprint"""} | ConvertTo-Json  | ConvertFrom-Json)
    & cmd /c $createCmd
}

function Add-FirewallException {
    param([string] $name, [string] $port, [string] $sourceIp)

    # Delete an exisitng rule
    netsh advfirewall firewall delete rule name=$name dir=in protocol=TCP localport=$port
    # Add a new firewall rule
    netsh advfirewall firewall add rule name=$name dir=in action=allow protocol=TCP localport=$port remoteip=$sourceIp
}

# The default MaxEnvelopeSizekb on Windows Server is 500 Kb which is very less. It needs to be at 8192 Kb. The small envelop size if not changed
# results in WS-Management service responding with error that the request size exceeded the configured MaxEnvelopeSize quota.
# winrm set winrm/config '@{MaxEnvelopeSizekb = "8192"}'


# Configure https listener
Configure-WinRMHttpsListener -hostname $vmHostname

# Add firewall exception
Add-FirewallException -name "Sisense Shell Web Service" -port 8080 -sourceIp $proxyWsPublicIpAddress
Add-FirewallException -name "Windows Remote Management (HTTPS-In)" -port 5986 -sourceIp any

Enable-PSRemoting -Force

function installMSI($path, $nameIn){
    $name = $nameIn -replace " ", ""
    $logPath = "C:\$name-install.log"
    Write-Host "Installing $path ..."

    $MSIArguments = @(
            "/i"
            $path
            "/qn"
            "/norestart"
            "/L*v"
            $logPath
    )

    Start-Process -FilePath "$env:systemroot\system32\msiexec.exe" -Wait -NoNewWindow -ArgumentList $MSIArguments 
}

if (!(Get-Command "Update-Module" -errorAction SilentlyContinue))
{
    installMSI -path (Convert-Path "PackageManagement_x64.msi") -name "Powershell modules update"
    Install-Module Azure
    Update-Module Azure
}

Echo "`nCompleted Configuration."






